// Move a file
Storage::move('old_location/file.txt', 'new_location/file.txt');

// Copy a file
Storage::copy('file.txt', 'copy_of_file.txt');

// Rename a file
Storage::move('old_name.txt', 'new_name.txt');

