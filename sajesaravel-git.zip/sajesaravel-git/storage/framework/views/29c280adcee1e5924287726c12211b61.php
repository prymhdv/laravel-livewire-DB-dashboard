<?php if(request()->route()->getName() == 'addNumber.operators.employee.adminPanelLivewireRoute'): ?>
    <div class="row p-1">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    افزودن شماره

                    <hr>
                    <div class="container text-center">
                        <div class="row justify-content-center align-content-center">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\employee\operator\addNumber.blade.php ENDPATH**/ ?>