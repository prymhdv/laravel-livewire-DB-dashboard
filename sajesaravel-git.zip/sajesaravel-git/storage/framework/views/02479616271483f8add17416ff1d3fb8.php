
<div id="menu_bottom_container" class="container-fluid fixed-bottom shadow-up  "
    style=" background-color: #ffffff; height: 50px;z-index: 100;  width: 100% !important; max-width:100%!important">
    
    <div class=" row  bg-opacity-100 menuBox position-relative">
        
    </div>
    
</div>
 
 <?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\Menu.blade.php ENDPATH**/ ?>