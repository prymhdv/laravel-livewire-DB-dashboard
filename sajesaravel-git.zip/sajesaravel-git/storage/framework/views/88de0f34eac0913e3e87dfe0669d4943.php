













<nav class="py-2">
    <ul class=" " style="margin: 0px!important;">
        <!-- <li><a href="tarah-basham?pid=1"><i class="fas fa-book"></i>اگر من طراح باشم</a></li> -->
        <!-- <li><a href="ser"><i class="fas fa-receipt"></i>انتخاب رشته</a></li> -->
        <li class="d-none"><a wire:navigate href="<?php echo e(route('finalexams.index.Route')); ?>"><i
                    class="far fa-newspaper"></i>امتحانات نهایی</a></li>
        <li>
            <a wire:navigate href="<?php echo e(route('counsellor.employee.pages.home.Route')); ?>" class="linkMenu  ">
                
                <i class=" fas fa-users-cog  fa-2x"></i>
                استخدام مشاور
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('confrence.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-users fa-2x"></i>
                
                همایش ها
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-laptop fa-2x"></i>
                
                انتخاب رشته
            </a>
        </li>
        <!-- <li><a href="./employment"><i class="fas fa-laptop"></i>فرصت شغلی</a></li> -->
        <li>
            <a wire:navigate href="<?php echo e(route('formulaone.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-car-alt fa-2x"></i>فرمول یک
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('farhangian.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-book-reader fa-2x"></i>
                کنکور 1404 و فرهنگیان
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('dispatch.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-user-graduate fa-2x"></i>
                اعزام دانشجو
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="linkMenu  ">
                <i class="fa fa-rocket fa-2x"></i>امتحانات
            </a>
        </li>
        <li class="d-none">
            <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="linkMenu  ">
                <i class="fa fa-rocket fa-2x"></i>
                امتحانات ترم اول (طرح بوستر)
            </a>
        </li>
    </ul>
    <?php if(request()->route()->getName() == 'farhangian.index.Route'): ?>
        <div class="container p-0  "style="user-select: none;">
            <div class="row">
                <div class="col-12 p-0 user-select-none font-bold fsr-16" style="color:rgba(20, 20, 163, 0.822); ">
                    پرتال کاربری داوطلبان کنکور سراسری و فرهنگیان ۱۴۰۴
                </div>
            </div>
        </div>
    <?php endif; ?>
</nav>
<style>
    .dpt-menu ul li a {
        font-size: 16px;
        font-weight: 400;
        color: var(--color_sanjesh_blue);
        padding: 2px 0px!important;;
        display: block;
    }
    ul {
        margin: 2px!important;
    }

    .fa-counseling::before {
        content: "\f0c0";
    }

    .linkMenu {
        padding: 3px;
    }

    .linkMenu i {
        color: var(--color_sanjesh_green);
        -webkit-transition: all 0.3s ease-out 0s;
        -moz-transition: all 0.3s ease-out 0s;
        -ms-transition: all 0.3s ease-out 0s;
        -o-transition: all 0.3s ease-out 0s;
        transition: all 0.3s ease-out 0s;
    }

    .linkMenu:hover i {
        color: var(--color_sanjesh_blue) !important;
    }

    li a {
        text-decoration: none;
    }

    .dpt-menu ul li a {
        font-size: 16px;
        font-weight: 400;
        color: var(--color_sanjesh_green);
        padding: 23px 0;
        display: block;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\dashboard\partials copy\header_menuDesktop.blade.php ENDPATH**/ ?>