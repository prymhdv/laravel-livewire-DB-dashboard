<nav class=" navbar navbar-expand-xl navbar-dark bg-dark border-body font-iransans shadow1 position-relative  "
    style="
     direction: rtl;
      height: var(--height-nav);
      max-height: var(--height-nav);
      left:0px;
      top:0px;
       position: fixed !important;
       z-index:1010;
       width:100%;
        background:linear-gradient(90deg, #0f0c29 0%, #302b63 50%, #24243e 100%);.
        /*background:linear-gradient(90deg, #e7e7e9 0%, #f6f5f9 50%, #ececed 100%);*/

        /* padding-top:5px; */
        /* padding-bottom:0px; */
        border-bottom-right-radius:7px;
        border-bottom-left-radius:7px;
        border-bottom: 3px double #6e6e6f;
            justify-self: anchor-center;
       
       ">

    <div id="mobileDiv" class="container-fluid d-block d-xl-none " style="">
        <div id="Header_logo0" class=" navbar-brand position-relative">
            <div class="row  justify-content-start align-content-start">
                <a id=" " class="navbar-brand align-content-center m-0 p-0 col-12 position-relative"
                    style="display: flow-root;" href="<?php echo e(route('home.index.Route')); ?>"data-path="main.Route">
                    <img loading="lazy" src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>"
                        alt="sanjeshBonyad.logo" class="   "
                        style="     object-fit: inherit;
                                    width: 160px;
                                    height: 130px;
                                    position: fixed;
                                    top: -37px;
                                    left: 15px;
                                    bottom: 2px;
                                    right: -1px;">
                </a>
            </div>
        </div>

        <button id="btntogg" class=" navbar-toggler " type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarX55" onclick="openNav()" aria-controls="navbarX55" aria-expanded="false"
            aria-label="Toggle navigation"
            style= "        object-fit: none;
                            padding: 0rem;
                            height: 50px;
                            width: 50px;
                            position: fixed;
                            top: 3px;
                            right: 29px;
                            color: #fff;">
            <span class="navbar-toggler-icon" style=" width: 1.8em;"></span>
        </button>
    </div>


    <div id="DesktopDiv" class=" container-fluid container-xl  d-none d-xl-block text-center p-0 mt-2">
        
        <div class="d-flex " style="justify-content: space-between;">
            <div style="position: absolute; bottom:25px; right:15px;  z-index:10;">
                <div class="toggle-container " style="">
                    <div id="toggle-iconUpA" class="toggle-icon align-middle ">▲</div>
                    <div id="toggle-iconDownA" class="toggle-icon align-middle ">▼</div>
                </div>
            </div>
            <div style="position: absolute; bottom:25px; right:45px;  z-index:10;">
                <div class="toggle-container"
                    style=" background-color:#0073ff;    ">
                    <div id="toggle-iconDownB" class="toggle-icon align-middle ">▼</div>
                    <div id="toggle-iconUpB" class="toggle-icon align-middle ">▲</div>
                </div>

            </div>
            <div style="position: absolute; bottom:25px; right:75px;  z-index:10;">
                <div class="toggle-container"
                    style="  background-color:#ff0000;    ">
                    <div id="toggle-iconUpC" class="toggle-icon align-middle ">▲</div>
                    <div id="toggle-iconDownC" class="toggle-icon align-middle ">▼</div>
                  
                </div>

            </div>

            <style>
                .toggle-container {
                    align-content: center; 
                    border-radius: 0px 0px 7px 7px;
                    overflow: hidden;
                    background: #00fd088f;
                    border: 0px solid #eee;
                    color: #fff;
                    cursor: pointer;
                    user-select: none;
                    width: 15px; height:15px; border-radius: 50%;
                } 
                .toggle-container:hover{
                    scale:1.2;
                }
                .toggle-icon {
                    transition: transform 1s ease;
                    font-size:.7rem;
                    color: transparent;
                    /* Smooth rotation */
                } 
                .open {
                    height: auto;
                    /* Allow content to expand */
                    padding: 10px;
                    /* Add padding when open */
                }

                .rotated {
                    transform: rotate(180deg);
                    /* Rotate the arrow */
                }
            </style>

            <a id="Header_logo" class="navbar-brand p-0" href="<?php echo e(route('home.index.Route')); ?>"
                style=" vertical-align: middle; /*width: 19%; position: absolute; top: 8px; right: 39px;*/ ">

                <img loading="lazy" src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>"
                    alt="sanjeshBonyad.logo" class=" mt-1"
                    style="width: 167px; height: 100%;margin-top: -5px !important;">
            </a> 
            <div id=" " class="navbar-brand p-0">
                <div class="d-flex flex-row justify-content-between align-content-center">

                    <div id="navbarX55" class="
                    
                     navbar-collapse">  
                         
                        <style>
                            /* Hide dropdown toggle if no items are in the dropdown */
                            #overflowDropdownToggle:empty {
                                display: none;
                            }
                        </style>
                        
                        <?php echo $__env->make('pages.prymhdv.partials.navItem', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        
                        <div class="col-auto ms-2 justify-content-end ">
                            <?php echo $__env->make('pages.prymhdv.partials.popAdmin', ['idpop' => '1'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                        <style>
                            .headbtn {
                                text-align: center !important;
                                font-family: 'iransans' !important;
                                /* font-weight: 300 !important; */
                                /* font-weight: bolder !important; */
                                text-wrap-mode: nowrap !important;
                                cursor: pointer !important;
                                background-color: transparent !important;
                                color: #eee;
                                word-spacing: normal;
                                /*border-radius: 7px !important;*/
                                /*border: 0px !important;*/
                                color: #fff !important;
                                text-decoration: none !important;
                                transition: ease all 0.3s !important;
                                /*box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px !important;*/
                            }

                            .headbtn i {
                                /* font-size: 0.9rem !important; */
                                transition: ease all 0.3s !important;
                                padding: 2px !important;
                                font-weight: bolder !important;
                                margin: 2px !important;
                                color: #00ff00;
                            }

                            .headbtn:hover {

                                /*background-color: var(--color_violate) !important;*/
                                color: #fff !important;
                                color: #00ff00  !important;
                                transition: ease all 0.3s !important;
                            }

                            .headbtn:hover i {
                                color: #eee !important;
                                transition: ease all 0.3s !important;
                            }

                            .iconeHead {
                                /* color: #892be2a2;    */
                                color: var(--color_violate);
                            }
                        </style>
                    </div>
                </div>

            </div>
             
        </div>
    </div>
    <style>
        @media (max-width: 400px) {
            #Header_logo {
                min-width: 20.0vmin !important;
                max-width: 20.0vmin !important;
                width: 20.0vmin !important;
                /* max-width: 0.1vw!important; */
            }

            #Location_logo {
                min-width: 5.0vmin !important;
                max-width: 5.0vmin !important;
                width: 5.0vmin !important;
                /* max-width: calc(var(--height-nav) * 0.1vw)!important; */
            }
        }
    </style>
</nav>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\nav.blade.php ENDPATH**/ ?>