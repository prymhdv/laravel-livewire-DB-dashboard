 
 <div class="col-12 p-2 <?php if(Auth::check() &&
                 Auth::user()->student &&
                 Auth::user()->student->booster &&
                 Auth::user()->student->booster->Isbooster == '1'): ?> '' <?php else: ?> d-none <?php endif; ?>">
     
     <div id="boosterVideoContainer" class=" ">
         <?php echo $__env->make('livewire.dashboard.student.booster.Video', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>
 </div>



 
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\booster\booster.blade.php ENDPATH**/ ?>