<div id="GetField" class="col-md-10">
    <div class="row my-1">
        <div class="input-group input-group-sm mb-1">
            <label class="col-3 input-group-text px-3" for="field">رشته تحصیلی</label>
            <select id="field-select" name="field" class=" text-center form-control " required
                wire:model="field"style="border:2px solid #ddd; border-radius:7px;">
                <option value="" hidden>رشته تحصیلی</option>
                <option value="انسانی">انسانی</option>
                <option value="ریاضی">ریاضی</option>
                <option value="تجربی">تجربی</option>
            </select>
            <?php echo $__env->make('livewire.error', ['e' => 'field'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>
<?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] != 'farhangianInit'): ?>
    <div id="GetField_Base" class="col-md-10">
        <div class="row my-1">
            <div class="input-group input-group-sm mb-1">
                <label class="col-3 input-group-text px-3" for="field_Base">پایه تحصیلی</label>
                <select id="field_Base-select" name="field_Base" class=" text-center  form-control" required
                    wire:model="field_Base"style="border:2px solid #ddd; border-radius:7px;">
                    <option value="" hidden>پایه تحصیلی</option>
                    
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'fieldSelectionInit'): ?>
                    <option value="دوازدهم">(پشت کنکور)دوازدهم</option>
                    <option value="دوازدهم">فارغ التحصیل</option>
                    <?php else: ?>
                    <option value="نهم">نهم</option>
                    <option value="دهم">دهم</option>
                    <option value="یازدهم">یازدهم</option>
                    <option value="دوازدهم">دوازدهم</option>
                    <?php endif; ?> 
                </select>
                <?php echo $__env->make('livewire.error', ['e' => 'field_Base'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\student.blade.php ENDPATH**/ ?>