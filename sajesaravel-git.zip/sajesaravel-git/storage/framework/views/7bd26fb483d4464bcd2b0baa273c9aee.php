<?php if(request()->route()->getName() == 'main.counsellors.employee.adminPanelLivewireRoute' ||
        request()->route()->getName() == 'addNumber.counsellors.employee.adminPanelLivewireRoute' 
        // || (session()->has('employeeCounsellorAddMobile') && session('employeeCounsellorAddMobile') == '1')
         ): ?>
    <div class="row">
        <div class="col-md-12">

            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-4">
                <a href="<?php echo e(route('addNumber.counsellors.employee.adminPanelLivewireRoute')); ?>" wire:navigate   class="hover4 d-block justify-items-center align-content-center "
                  
                  style=" 
                   <?php if( request()->route()->getName()=='addNumber.counsellors.employee.adminPanelLivewireRoute'): ?> background-color:green; <?php endif; ?> ">
                    افزودن شماره
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    برسی کاربر
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    چاپ گواهی
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    برسی گواهی
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    تغییر شماره
                </a> 
                <a class="hover4 d-block justify-items-center align-content-center" style=" " href="<?php echo e(route('pubResult.counsellors.employee.adminPanelLivewireRoute')); ?>"  >
                    انتشار نتایج
                </a>
            </div>
            <?php echo $__env->make('pages.layouts.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <hr class="m-0">
            <?php echo $__env->make('livewire.dashboard.admin.employee.counsellor.addNumber', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\employee\counsellor\main.blade.php ENDPATH**/ ?>