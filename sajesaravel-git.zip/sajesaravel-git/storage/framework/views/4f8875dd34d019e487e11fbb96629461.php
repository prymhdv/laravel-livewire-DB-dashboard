<button class="col-md-6  button-82-pushable text-center  d-none" role="button"
    
    href="https://formafzar.com/form/hg4s3"
    >
    <div class=" ">
        <span class="button-82-shadow"></span>
        <span class="button-82-edge"></span>
        <span class="button-82-front text fs-5 p-0 px-3 m-0 d-flex flex-nowrap justify-content-center align-content-center" style=" vertical-align: middle;">
            
            <img src="<?php echo e(asset('storage/main/home/services/Icon-04.webp')); ?>" class=" mx-2" loading="lazy"
                style="width: 50px; ">
            <?php if(Auth::check() &&
                    Auth::User() &&
                    Auth::User()->student()->exists() &&
                    Auth::User()->student->fieldSelection()->exists()): ?>
               <span class="justify-content-center align-content-center fs-4"> پنل انتخاب رشته</span>
               <span class="justify-content-center align-content-center"> <?php echo e(Auth::User()->student->fieldSelection->type ?? ''); ?></span>
                
            <?php else: ?>
               <span class="justify-content-center align-content-center fs-4"> ثبت نام و رزرو انتخاب رشته تخصصی بنیاد سنجش</span>
            <?php endif; ?>
        </span>
    </div>
</button>

<a id="entekhabReshteClick" class=" d-flex px-2 rotate-button2 shadow1 align-content-center justify-content-center" 
     
      href="https://formafzar.com/form/hg4s3"
    style="color:white;cruser:pointer;font-weight:600;border-radius:12px;"><img
        src="<?php echo e(asset('storage/main/home/services/Icon-04.webp')); ?>" class=" p-1 px-2 " loading="lazy"style="width: 80px; ">
    <span class="align-content-center text-wrap">
         
             ثبت نام و رزرو انتخاب رشته تخصصی بنیاد سنجش  
      
    </span>
</a><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\regBtn_inside.blade.php ENDPATH**/ ?>