


<div id="getSatisfiedInfo" class="p-0 m-0 boxShadow1_3d">
    <div class="col-12 p-0" style="border:1px solid #ccc; background-color:#eee; border-radius:7px;">
        <div class="col-12 text-center p-0"
            style="border:1px solid #ccc; background-color:#ccc; border-top-left-radius:7px;border-top-right-radius:7px;">
            ویدیو رضایتمندی
            <i class="fa-solid fa-spinner fa-spin-pulse invisible"></i>
        </div>
        <div class="row">

            <div class="col-ms-12 p-0">
                <div class="card" style="border-top-left-radius:0px;border-top-right-radius:0px;">
                    
                    <div class="col-md-8 justify-content-center ">

                        <div class="card col-md-12">
                            <div class="card-body col-md-12 text-center p-0">

                                <div class="row justify-content-center">
                                    <div class="col-md-10 justify-content-between ">
                                        <div class="d-flex justify-content-between  align-content-center">
                                            <div class="p2">
                                                <b>نمونه ویدیو سلفی رضایتمندی از انتخاب رشته </b>
                                                <video id="SatisfiedInfoVideo" style="width: 300px;" controls preload>
                                                    <source
                                                        src="<?php echo e(asset('storage/main/student/fieldSelection/SatisfiedVideos/Satisfied00.mp4')); ?>"
                                                        type="video/mp4">
                                                    Your browser does not support the video tag.
                                                </video>
                                            </div>
                                            <div class=" m-1  justify-content-center  align-content-center">
                                                <div class="input-group input-group-sm  ">
                                                    <label for="personalResume"
                                                        class=" dsdsc34r3 input-group-text p-3 justify-content-between"
                                                        style="width: 300px;height: 75px;  border-radius: 12px; cursor: pointer;">
                                                        <i class="fa fa-upload ps-2 fa-2x " style="color: #06a0a5;">
                                                        </i>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        آپلود ویدیو رضایت مندی
                                                    </label>
                                                    
                                                    <input name="Satisfied" type="file" id="Satisfied"
                                                         accept=".mp4" style="display: none;" />
                                                    <div wire:loading wire:target="Satisfied">Uploading...</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\student\fieldSelection\student\getSatisfiedInfo.blade.php ENDPATH**/ ?>