 <div id=" " class="subHeadGDFGClass p-2 "  >
     <div class="d-flex justify-content-center align-content-center   fs-3 ">
         <a wire:navigate 
         
          href="<?php echo e(route('show.blog.Route')); ?>"
          class="  p-2  mx-1 text-decoration-none "
             style="color: #eee; border-radius: 7px; border:1px solid #ddd;  ;">مجله و وبلاگ
         </a>
         <a wire:navigate href="<?php echo e(route('about.other.pages.Route')); ?>" class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">درباره موسسه
             بنیاد سنجش ایرانیان
         </a>
         <a wire:navigate href="<?php echo e(route('shopProducts.other.pages.Route')); ?>" class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">فروشگاه و
             محصولات
         </a>
         <a wire:navigate href="<?php echo e(route('suggestionsCriticisms.other.pages.Route')); ?>"
             class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">انتقادات و
             پیشنهادات
         </a>
         <a wire:navigate href="<?php echo e(route('colleagueCompetitor.other.pages.Route')); ?>"
             class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">همکاران
         </a>
         <a wire:navigate href="<?php echo e(route('talents.other.pages.Route')); ?>" class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">استعداد درخشان
         </a>
         <a wire:navigate href="<?php echo e(route('support.other.pages.Route')); ?>" class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd; "> پشتیبانی و
             مرکز‌تماس
         </a>
         <a wire:navigate href="<?php echo e(route('humanResources.other.pages.Route')); ?>"
             class="    p-2  mx-1 text-decoration-none"
             style="color:#eee; border-radius: 7px; border:1px solid #ddd;  ;">نیروی انسانی
         </a>
     </div>
 </div>

 <style>
     .subHeadGDFGClass a {
         cursor: pointer !important;
         background-color: red;
     }

     .subHeadGDFGClass a:hover {
          transition: all 0.3s ease-in-out 0s;
         /* color: #fff !important; */
         background-color: rgb(145, 2, 2);
     }

     .subHeadGDFGClass>* {
         /* z-index: 10; */
     }
 </style>
 <script>
     $(document).ready(function() {
         // $('#subHeadGDFG').children().fadeOut();
        //  $("#subHeadGDFG").slideUp();
         $(".subHeadGDFGClass").slideUp();
         
         $("#toggle-iconDownB").on("click", function() {
            if ($(".fgb5brtrtClass").is(":hidden")&& $("#toggle-iconDownC").is(":visible")) {
                // $('#fgb5brtrt').fadeIn(); 
                $(".subHeadGDFGClass").show();
              
                $('.LinkDFDClass').hide();
                $("#loop5R").hide();
                // $("#fgb5brtrt").slideDown(); 
                $('.fgb5brtrtClass').slideDown();
                $('#toggle-iconUpB').show();
                $('#toggle-iconDownB').hide();
                return;
            }
             //  $('#toggle-iconDownB').click(function() {
             //  $("#subHeadGDFG").hide();
             //  $("#subHeadGDFG").fadeIn();
             //---------------
             //  $('#subHeadGDFG').children().fadeIn();
           
             $(".subHeadGDFGClass").slideDown();
             //---------------
             //  $('#subHeadGDFG').fadeIn();
             //  $("#subHeadGDFG").slideDown();
             //  $("#subHeadGDFG").removeClass('d-flex')
             //  $("#subHeadGDFG").addClass('d-flex');
             //  $("#subHeadGDFG").animate({height: 'toggle'});
             //---------------------------
             $('#toggle-iconUpB').show();
             $('#toggle-iconDownB').hide();
         });
         $("#toggle-iconUpB").on("click", function() {
            if ($("#toggle-iconDownA").is(":visible")&& $("#toggle-iconDownC").is(":visible")) {
                // $('#fgb5brtrt').fadeIn(); 
                $(".subHeadGDFGClass").slideUp();
                $("#loop5R").hide();
                // $("#fgb5brtrt").slideUp();
                $('.fgb5brtrtClass').slideUp();
                $('#toggle-iconUpB').hide();
                $('#toggle-iconDownB').show();
                // alert('ggg');
                return;
            }
             //  $("#subHeadGDFG").slideUp();
             //  $("#subHeadGDFG").fadeOut();
             // $("#subHeadGDFG").animate({height: 'toggle'});
             //---------------
             //  $('#subHeadGDFG').children().fadeOut();
            //  $("#subHeadGDFG").slideUp();
             $(".subHeadGDFGClass").slideUp();
             //---------------
             //  $('#subHeadGDFG').fadeOut();
             //--------------------------------
             $('#toggle-iconUpB').hide();
             $('#toggle-iconDownB').show();
         });
     });
 </script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/prymhdv/partials/headSubMenuII.blade.php ENDPATH**/ ?>