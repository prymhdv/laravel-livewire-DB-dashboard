<body class="container-fluid p-0" style="direction: ltr;">
    

    <?php $__env->startSection('header'); ?>
        
        
    <?php echo $__env->yieldSection(); ?>

    <main id="main" class="container-fluid p-0" style=" ">
        <div class="row justify-content-center align-content-center pb-5">
            <div class="col-md-12 p-0">

                <?php $__env->startSection('alert'); ?>
                    <?php echo $__env->make('pages.partials.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldSection(); ?>

                
                <div class="col-md-12 ">
                    
                    <?php echo e($slot); ?>

                </div>
                
                <?php $__env->startSection('footer'); ?>
                    
                <?php echo $__env->yieldSection(); ?>
            </div>

        </div>
    </main>
    
    <?php $__env->startSection('Menu'); ?>
        
    <?php echo $__env->yieldSection(); ?>
    
    
    <?php echo $__env->make('components.layouts.bodyScripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.share', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\layouts\body.blade.php ENDPATH**/ ?>