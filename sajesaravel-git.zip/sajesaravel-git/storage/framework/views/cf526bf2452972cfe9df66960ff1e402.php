<?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'fieldSelectionInit'): ?>
    <div class="col-md-10 ">
        <div class="row my-1">
            <div class="input-group input-group-sm mb-1">
                <label class="col-3 input-group-text px-3" for="provience">نوع انتخاب رشته</label>
                <select name="province" id="province"class="  text-center form-control"
                    style="border:2px solid #ddd; border-radius:7px;" wire:model="selectedFieldSelectionType">
                    <option value="" hidden>
                        &#11206;: نوع انتخاب رشته
                    </option>
                    <option value="CIP(حضوری)">CIP(حضوری)</option>
                    <option value="CIP(آنلاین)">CIP(آنلاین)</option>
                    <option value="VIP(حضوری)">VIP(حضوری)</option>
                    <option value="VIP(آنلاین)">VIP(آنلاین)</option>
                </select>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\studentFieldSelection.blade.php ENDPATH**/ ?>