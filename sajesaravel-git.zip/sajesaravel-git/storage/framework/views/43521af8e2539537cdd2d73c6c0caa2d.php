<style>
    a:hover {
        cursor: pointer;
    }
</style><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\layoutsI\headStyle.blade.php ENDPATH**/ ?>