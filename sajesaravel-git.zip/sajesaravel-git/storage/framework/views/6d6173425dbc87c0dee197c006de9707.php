
<!--[if BLOCK]><![endif]--><?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[0] == 'form'): ?> 
    <!--[if BLOCK]><![endif]--><?php if((session()->has('Sign_form') && session('Sign_form') == 'yes' ) || 0): ?>
        <div class="row justify-content-center py-3">
            <div id="GetFname" class="col-md-10">
                <div class="row my-1">
                    <div class="input-group input-group-sm mb-1">
                        <label class="col-3 input-group-text px-3" for="fname">نام</label>
                        <input class=" text-center form-control" type="text" name="fname" required
                            wire:model="fname"style="border:2px solid #ddd; border-radius:7px;">
                        <?php echo $__env->make('livewire.error', ['e' => 'fname'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
            <div id="GetLname" class="col-md-10">
                <div class="row my-1">
                    <div class="input-group input-group-sm mb-1">
                        <label class="col-3 input-group-text px-3" for="lname">نام خانوادگی</label>
                        <input class=" text-center form-control" type="text" name="lname" required
                            wire:model="lname"style="border:2px solid #ddd; border-radius:7px;">
                        <?php echo $__env->make('livewire.error', ['e' => 'lname'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
            <div id="GetcodeMeli" class="col-md-10">
                <div class="row my-1">
                    <div class="input-group input-group-sm mb-1">
                        <label class="col-3 input-group-text px-3" for="codeMeli">کد ملی</label>
                        <input class=" text-center form-control" type="text" name="codeMeli" required
                            wire:model="codeMeli"style="border:2px solid #ddd; border-radius:7px;">
                        <?php echo $__env->make('livewire.error', ['e' => 'codeMeli'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
            
            <?php if(session()->has('Sign_PageCurrent') &&
                    isset(session('Sign_PageCurrent')[2]) &&
                    session('Sign_PageCurrent')[2] == 'employee'): ?>
                <?php echo $__env->make('livewire.auth.employee', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'counsellorInit'): ?>
                    <?php echo $__env->make('livewire.auth.employeeCounsellor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php else: ?>
                <?php echo $__env->make('livewire.auth.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('livewire.auth.studentBooster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('livewire.auth.studentDispatch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('livewire.auth.studentFarhangian', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('livewire.auth.studentFieldSelection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            
            
            <div class="row  justify-content-center">
                <div class="col-md-10 ">
                    <div class="row my-1">
                        <div class="input-group input-group-sm mb-1">
                            <label class="col-3 input-group-text px-3" for="provience">استان</label>
                            <select name="province" id="province"class="  text-center form-control"
                                style="border:2px solid #ddd; border-radius:7px;" wire:model="selectedProvince"
                                wire:change="onProvinceChange($event.target.value)">
                                <option value="" selected hidden>
                                    &#11206;:استان</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($province['province_id'] == $selectedProvince): ?> selected <?php endif; ?>
                                        value="<?php echo e($province['province_id']); ?>">
                                        <?php echo e($province['provincename']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-10 ">
                    <div class="row my-1">
                        <div class="input-group input-group-sm mb-1">

                            <label class="col-3 input-group-text px-3" for="provience">شهر</label>
                            <select name="city" id="city" class=" text-center form-control"
                                style="border:2px solid #ddd; border-radius:7px;" wire:model="selectedCity"
                                 <?php if(empty($cities)): ?> disabled <?php endif; ?>>
                                <option value="" selected hidden>
                                    &#11206; <?php echo e($selectedCity); ?>:شهر</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($city['id'] == $selectedCity): ?> selected <?php endif; ?>
                                        value="<?php echo e($city['id']); ?>">
                                        <?php echo e($city['cityname']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <div wire:loading wire:target="selectedProvince" class="fs-4 px-3">
                                <i class="fa-solid fa-spinner fa-pulse"></i>
                            </div>
                        </div>
                    </div>

                </div>
                <button id="BTNregisterSmsConfirm"
                    class="col-10 my-3 p-2 btn-Sanjesh1 text-bold bg-sanjesh-green text-white"
                    style="border: 1px solid #eee;"
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'loginRegiserInit'): ?> wire:click="loginRegiserRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'boosterInit'): ?> wire:click="boosterRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'boosterIIInit'): ?> wire:click="boosterIIRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'dispatchInit'): ?> wire:click="dispatchRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'farhangianInit'): ?> wire:click="farhangianRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'counsellorInit'): ?> wire:click="counsellorRegister" <?php endif; ?>
                    <?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'fieldSelectionInit'): ?> wire:click="fieldSelectionRegister" <?php endif; ?> 
                     style="cursor: pointer;">
                    تکمیل درخواست
                </button>

            </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/auth/form.blade.php ENDPATH**/ ?>