


<div id="getPeymentInfo" class="p-0 m-0 boxShadow1_3d">
    <div class="col-12 p-0" style="border:1px solid #ccc; background-color:#eee; border-radius:7px;">
        <div class="col-12 text-center p-0"
            style="border:1px solid #ccc; background-color:#ccc; border-top-left-radius:7px;border-top-right-radius:7px;">
            وضعیت مالی
            <i class="fa-solid fa-spinner fa-spin-pulse invisible"></i>
        </div>
        <div class="row">


            <div id="isCounsellorSelectedNone" class="col-ms-12 p-0 text-center text-danger fs-6">
                <div class="p-3">
                    نوع مشاوره خود را انتخاب نکرده‌اید
                    <i class="	fas fa-exclamation-triangle"></i>
                </div>
            </div>
            <div id="isCounsellorSelected"class="col-ms-12 p-0">
                <div class="card" style="border-top-left-radius:0px;border-top-right-radius:0px;">

                    <div class="d-flex justify-content-center d-none">
                        <a class="menyj  p-2 m-1"
                            style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-check-circle fa-2x "
                                style=" color:#00ff00; "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                بیعانیه 300,000 تومان
                            </b>
                        </a>
                        <a class="menyj  p-2 m-1"
                            style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-check-circle fa-2x " style="  "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                CIP(آنلاین) 3,000,000 تومان
                            </b>
                        </a>
                        <a class="menyj  p-2 m-1"
                            style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-check-circle fa-2x " style="  "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                CIP(حضوری) 5,000,000 تومان
                            </b>
                        </a>
                        <a class="menyj  p-2 m-1"
                            style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-check-circle fa-2x " style="  "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                VIP(آنلاین) 7,000,000 تومان
                            </b>
                        </a>
                        <a class="menyj  p-2 m-1"
                            style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-check-circle fa-2x " style="  "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                VIP(حضوری) 10,000,000 تومان
                            </b>
                        </a>

                    </div>
                    
                    <div class="col-md-8 justify-content-center ">

                        <div class="card col-md-12">
                            <div class="card-body col-md-12 text-center p-0">

                                <div class="row justify-content-center">
                                    <div class="col-md-10 justify-content-between ">
                                        <div class="d-flex justify-content-between">
                                            <div class="col-md-6 text-end">پذیرش دوره</div>
                                            <div class="col-md-6 text-start" id="wantedCounsellorText">CIP(آنلاین)
                                                3,000,000 تومان</div>
                                        </div>
                                    </div>
                                    
                                    <hr>
                                    <div class="col-md-10 justify-content-between">
                                        <div class="d-flex justify-content-between">
                                            <div class="col-md-6 text-end">مبلغ‌کل</div>
                                            <div class="col-md-6 text-start" id="wantedCounsellorPriceAll">3,000,000
                                                تومان</div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="col-md-10 justify-content-between">
                                        <div class="d-flex justify-content-between">
                                            <div class="col-md-6 text-end">تخفیف</div>
                                            <div class="col-md-6 text-start" id="wantedCounsellorPriceOff">300,000 تومان
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="col-md-10 justify-content-between">
                                        <div class="d-flex justify-content-between">
                                            <div class="col-md-6 text-end">پرداختی</div>
                                            <div class="col-md-6 text-start" id="wantedCounsellorPriceCached">800,000
                                                تومان</div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="col-md-10 justify-content-between">
                                        <div class="d-flex justify-content-between">
                                            <div class="col-md-6 text-end">مانده</div>
                                            <div class="col-md-6 text-start" id="wantedCounsellorPriceRemain">1,900,000
                                                تومان</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class=" form-check   ">
                        <label for="confirmRules" class="form-check-label text-nowrap mx-2 text-bold">
                            پذیرش قوانین
                        </label>
                        <input class="form-check-input " type="checkbox" role="switch" name="confirmRules"
                            id="confirmRules" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false"
                            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"
                            style="direction: ltr;">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">پذیرش قوانین</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-end" style="direction:rtl;">
                                        لطفا قبل از اقدام به پرداخت، شرایط زیر را به دقت مطالعه نمایید :
                                        <hr>
                                        <ul class="">
                                            <li>1. مکان انجام انتخاب رشته حضوری صرفا شهر "تبریز" خواهد بود و درصورت
                                                انتخاب گزینه
                                                انتخاب رشته حضوری میبایست در موعد مقرر اعلامی انتخاب رشته خودتان در محل
                                                انجام
                                                انتخاب رشته موسسه بنیان سنجش ایرانیان واقع در شهر "تبریز" حضور بهم
                                                رسانید.</li>
                                             <br>
                                            <li> 2. پس از انتخاب نوع انتخاب رشته، امکان تعویض نوع انتخاب رشته وجود
                                                نخواهد داشت.</li>  <br>
                                            <li> 3. بدلیل اینکه پس از واریز وجه توسط شما (پیش پرداخت یا پرداخت کامل) یک
                                                ظرفیت از
                                                ظرفیت های انتخاب رشته بنیادسنجش به شما اختصاص داده میشود، امکان عودت وجه
                                                پرداختی
                                                وجود نخواهد داشت.</li>  <br>
                                            <li> 4. درصورت اینکه پرداخت شما به صورت "پیش پرداخت" است، تا روز شروع فرآیند
                                                انتخاب
                                                رشته (طبق اعلام سازمان سنجش) مهلت دارید تا پرداخت خودرا تکمیل نمایید.
                                                عدم تکمیل
                                                وجه تا موعد مقرر به منزله انصراف شما از ثبت نام بوده و وجه پیش پرداخت
                                                شما بنا بر
                                                دلیل اعلام شده در بند 3 عودت داده نخواهد شد.</li>  <br>
                                            <li>5. پس از واریز وجه، مشخصات پنل کاربری شما در سایت رسمی بنیان سنجش
                                                ایرانیان برای
                                                شما پیامک خواهد شد و شما می بایست تا روز مقرر انتخاب رشته، پنل کاربری
                                                خودرا در
                                                سایت مذکور تکمیل نمایید.</li>
                                        </ul> 
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger"
                                            data-bs-dismiss="modal">بستن</button>

                                        <a type="button" class="btn btn-success" target="_blank"
                                             
                                            href="<?php echo e(route('pay.payment.Route', [
                                                'case' => 'student.fieldSelection',
                                                'route' => request()->route()->getName(),
                                            ])); ?>">
                                            مورد تایید اینجانب می باشد</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex">
                        <a class="menyj  p-2 m-1 d-none" id="payNotCompleted"
                            style="color:#fff; background-color: #422816; border:1px solid #ccc; border-radius:12px;">
                            <i id="itemHeadXAIcone" class="InfoIcone35 fa fa-minus-circle fa-2x " style="  "></i>
                            <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none "
                                style=" vertical-align: super;">
                                تکمیل پرداخت
                            </b>
                        </a>
                        <a class=" p-2 m-1 d-none" id="payCompleted"
                            style="color:#fff; background-color: #29640d; border:1px solid #ccc; border-radius:12px;">
                            <i id=" " class="InfoIcone35 fa fa-check-circle fa-2x "
                                style="color:#47b415;  "></i>
                            <b id=" " class="Fefc3 p-2  user-select-none " style=" vertical-align: super;">
                                پرداخت تسویه شده
                            </b>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\student\fieldSelection\student\getPeymentInfoII.blade.php ENDPATH**/ ?>