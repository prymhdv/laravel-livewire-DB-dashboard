<div>
    <input type="text" data-picker>
</div>
 
    <?php
        $__assetKey = '372027281-0';

        ob_start();
    ?>
<script src="https://cdn.jsdelivr.net/npm/pikaday/pikaday.js" defer></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/pikaday/css/pikaday.css">
    <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;

            // Check if we're in a Livewire component or not and store the asset accordingly...
            if (isset($this)) {
                \Livewire\store($this)->push('assets', $__output, $__assetKey);
            } else {
                \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$nonLivewireAssets[$__assetKey] = $__output;
            }
        }
    ?>
 
    <?php
        $__scriptKey = '372027281-1';
        ob_start();
    ?>
<script>
    new Pikaday({ field: $wire.$el.querySelector('[data-picker]') });
// //Method	                                            Description
// Livewire.first()	                                    //Get the first Livewire component's JS object on the page
// Livewire.find(componentId)	                            //Get a Livewire component by it's ID
// Livewire.all()	                                        //Get all the Livewire components on a page
// Livewire.directive(directiveName, (el, directive, component) => {})	//Register a new Livewire directive (wire:custom-directive)
// Livewire.hook(hookName, (...) => {})	                //Call a method when JS lifecycle hook is fired. Read more
// Livewire.onLoad(() => {})	                            //Fires when Livewire is first finished loading on a page
// Livewire.onError((message, statusCode) => {})	        //Fires when a Livewire request fails. You can return false from the callback to prevent Livewire's default behavior
// Livewire.onPageExpired((response, message) => {})	    //When the page or session has expired it executes the callback instead of Livewire's page expired dialog
// Livewire.emit(eventName, ...params)	                    //Emit an event to all Livewire components listening on a page
// Livewire.emitTo(componentName, eventName, ...params)	//Emit an event to specific component name
// Livewire.on(eventName, (...params) => {})	            //Listen for an event to be emitted from a component
// Livewire.start()	                                    //Boot Livewire on the page (done for you automatically via  )
// Livewire.stop()	                                        //Tear down Livewire from the page
// Livewire.restart()	                                    //Stop, then start Livewire on the page
// Livewire.rescan()	                                    //Re-scan the DOM for newly added Livewire components
</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>



<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\demo.blade.php ENDPATH**/ ?>