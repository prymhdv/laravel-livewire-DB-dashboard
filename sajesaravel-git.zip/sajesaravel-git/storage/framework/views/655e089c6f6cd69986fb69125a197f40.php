<div class="  p-0  h-100 fs-3  ">
    <!--[if BLOCK]><![endif]--><?php if(!isset(Auth::user()->student->booster->Isbooster)): ?>
        <script>
            document.addEventListener('livewire:navigated', () => {
                Livewire.dispatchTo('sign-info-complete', 'switchModal1');
            });
        </script>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="row align-content-center justify-content-center  h-100  card  p-0">
        <div class="col-12  p-0 align-content-center justify-content-center h-100 card-body ">
            <div class=" p-0 shadow1 text-end h-100 p-2" style="background-color: #ddd0; border-radius:7px; ">
                <img 
               
                <?php if(Auth::user()->personal && Auth::user()->personal->userPhotoPath): ?> 
                src="<?php echo e(asset(Auth::user()->personal->userPhotoPath)); ?>"
                <?php else: ?>
                
                 src="<?php echo e(asset('storage/PrymhdvAssets/Logo/user.webp')); ?>"
                <?php endif; ?> 
                alt="" class=" text-start p-2" style=" width:80px; scale:1.2; border-radius:50%; aspect-ratio:1;">
                پرتال کاربری : ادمین
                <div class="col-12 position-relative" style="height: 20px;">
                    
                    <div style=" left:0;" class=" position-absolute bottom-0  p-0 d-none">
                        <a class=" btn btn-outline-dark  "  
                        
                            onclick="Livewire.dispatchTo('auth.sign-info-complete','switchModal')">تکمیل اطلاعات
                            شخصی</a>
                    </div>
                </div>
                <div class="p-0   " style="background-color: #ddd0; border-radius:7px; ">
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">نام:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->nameFirst); ?></div>
                    </div> <hr class="m-0"> 
                    <div class="d-flex">
                        <div class="col text-end">نام خانوادگی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->nameLast); ?></div>
                    </div> <hr class="m-0"> 
                    <div class="d-flex">
                        <div class="col text-end">کدملی/پرسنلی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->codeMeli ?? ''); ?></div>
                    </div> <hr class="m-0"> 
                    <div class="d-flex">
                        <div class="col text-end">موبایل:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->mobile); ?></div>
                    </div> <hr class="m-0"> 
                    <div class="d-flex">
                        <div class="col text-end">مقطع تحصیلی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->employee->field); ?></div>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/userInfo.blade.php ENDPATH**/ ?>