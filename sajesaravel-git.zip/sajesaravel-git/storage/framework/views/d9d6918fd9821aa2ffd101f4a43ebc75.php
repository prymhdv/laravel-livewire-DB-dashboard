<div class="  px-2 justify-content-between   my-1   fontBold ">
    <div class="card p-1" style="background-color: #ddd; align-items: normal;">
        مرکز تماس
        <a href="<?php echo e(route('callCenter.adminPanelLivewireRoute')); ?>" wire:navigate 
            class="card-userSection card card-body p-1  mt-2
                 
                <?php if(Str::contains(request()->route()->getName(), 'kargah')): ?> card-userSection-active <?php endif; ?>">
                <div class=" position-absolute bandX" style="  "></div>
            <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative">
                
                <span class="col">
                    <i class=" fa fa-gears px-2"></i>
                    مدیریت
                </span>
                <span class="col">
                    <!--[if BLOCK]><![endif]--><?php if(isset(Auth::user()->employee) &&
                    isset(Auth::user()->employee->kargah) &&
                    Auth::user()->employee->kargah->IsKargah == true): ?>
                    <i class="fa fa-check-circle  text-sanjesh-green"></i>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </span>
            </div>
        </a>
    </div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/userSectionCallCenter.blade.php ENDPATH**/ ?>