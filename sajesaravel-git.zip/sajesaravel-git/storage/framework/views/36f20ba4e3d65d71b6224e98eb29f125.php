<!-- resources/views/components/loading-spinner.blade.php -->
<div class="flex justify-center items-center h-64">
    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\solids\loading-spinner.blade.php ENDPATH**/ ?>