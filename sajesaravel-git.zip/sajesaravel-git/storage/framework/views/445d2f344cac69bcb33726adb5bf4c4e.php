
<style>

    /* html {
  font-family: sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.container-alert {
  width: 500px;
  max-width: 100%;
  margin: 0 auto;
  padding: 20px;
  box-sizing: border-box;
} */

</style>
<style>
  .container-alert {
    box-sizing: border-box
}

.container-alert .alert {
    margin-bottom: 10px
}

.container-alert .alert:last-child {
    margin-bottom: 0
}

.alert {
    width: 100%;
    padding: 15px;
    position: relative;
    border-left: 8px solid #bababa;
    background: #ededed;
    color: #a1a1a1;
    border-radius: 4px;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-pack: center;
    justify-content: center;
    -ms-flex-align: center;
    align-items: center;
    text-align: left;
    font-size: 16px
}

.alert .alert--close,.alert .alert--icon {
    height: 100%;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-pack: center;
    justify-content: center;
    -ms-flex-align: center;
    align-items: center;
    font-size: 20px
}

.alert .alert--close_absolute,.alert .alert--icon_absolute {
    position: absolute;
    top: 10px;
    right: 10px;
    -ms-flex-align: start;
    align-items: flex-start;
    height: auto
}

.alert .alert--icon {
    margin-right: 10px
}

.alert .alert--close {
    margin-left: 10px;
    opacity: .7;
    transition: .5s;
    cursor: pointer
}

.alert .alert--close:hover {
    opacity: 1
}

.alert .alert--content {
    width: 100%;
    line-height: 1.5
}

.alert .alert--buttons {
    width: 100%;
    margin-top: 10px
}

.alert_sm {
    padding: 10px;
    font-size: 14px
}

.alert_sm .alert--close,.alert_sm .alert--icon {
    font-size: 16px
}

.alert_lg {
    font-size: 26px
}

.alert_lg .alert--close,.alert_lg .alert--icon {
    font-size: 26px
}

.alert .hr {
    height: 1px;
    width: 100%;
    border: none;
    background: #ddd;
    margin: 10px 0
}

.alert_success {
    border-color: #2ed573;
    background: #c3f3d7;
    color: #23ad5c
}

.alert_success .hr {
    background: #23ad5c
}

.alert_danger {
    border-color: #ff4757;
    background: #ffe0e3;
    color: #ff4757
}

.alert_danger .hr {
    background: #ff4757
}

.alert_warning {
    border-color: #ffa502;
    background: #ffdb9b;
    color: #ce8500
}

.alert_warning .hr {
    background: #ce8500
}

.alert_info {
    border-color: #71c9ff;
    background: #d7f0ff;
    color: #3eb6ff
}

.alert_info .hr {
    background: #3eb6ff
}

.alert_dark {
    border-color: #333;
    background: #4d4d4d;
    color: #ccc
}

.alert_dark .hr {
    background: #1a1a1a
}

.alert {
    transition: .5s ease-in-out;
    visibility: visible;
    opacity: 1;
    height: auto;
    overflow: hidden;
    animation-name: showAlert;
    animation-duration: .5s;
    animation-fill-mode: both
}

@keyframes showAlert {
    from {
        opacity: 0;
        transform: translateY(20px)
    }

    to {
        opacity: 1
    }
}

.alert.alert_none {
    display: none
}

.fixed-alerts {
    box-sizing: border-box;
    position: fixed;
    z-index: 9999999;
    width: calc(100% - 20px);
    max-width: calc(400px - 20px)
}

.fixed-alerts_bottom {
    bottom: 10px
}

.fixed-alerts_top {
    top: 10px
}

.fixed-alerts_right {
    right: 10px
}

.fixed-alerts_left {
    left: 10px
}

.fixed-alerts .alert {
    box-shadow: 0 0 10px 0 rgba(0,0,0,.1);
    margin-bottom: 10px
}

.fixed-alerts .alert:last-child {
    margin-bottom: 0
}

</style><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\assets\alertsIII.blade.php ENDPATH**/ ?>