<div class="container">

    <div class="row  align-content-center justify-content-center">
        
        <!-- Modal -->
        <?php $new = new CRandColor() ?>
        <?php $new0 = new CRandColor() ?>
        <?php $new1 = new CRandColor() ?>
        <?php $new2 = new CRandColor() ?>
        <?php $new3 = new CRandColor() ?>
        <?php $new4 = new CRandColor() ?>
        <?php $new5 = new CRandColor() ?>
        <button id="buyClick" class="text-center  m-4 rotate-button2 shadow1 glowing-outline<?php echo e($new->name); ?> "
             
                onclick="Livewire.dispatchTo('auth.sign','dispatchInit', { Page: 'dispatchInit' })"
            style=" padding:40px; color:<?php echo e($new->colorII); ?>;  cruser:pointer;
                   background-color:<?php echo e($new->colorI); ?>; font-size: xx-large; font-weight:600; border:2px solid <?php echo e($new->colorI); ?>; border-radius:12px;">
            
            جهت اخذ پذیرش ، کلیک کنید
        </button>
        <?php  ?>
        <style>
            #buyClick:hover {
                transform: scale(1.1);
                 transition: all 0.3s ease-in-out 0s;
                cursor: pointer;
                padding: 20px !important;
            }

            #buyClick {
                 transition: all 0.3s ease-in-out 0s;
                cursor: pointer;
                padding: 20px !important;
              
            } 
        @keyframes colorChange<?php echo e($new->name); ?> {
            0% {
                color: <?php echo e($new0->colorII); ?>;
                background-color: <?php echo e($new0->colorI); ?>;
                border: 2px solid <?php echo e($new0->colorI); ?>;
            }

            25% {
                color: <?php echo e($new1->colorII); ?>;
                background-color: <?php echo e($new1->colorI); ?>;
                border: 2px solid <?php echo e($new1->colorI); ?>;
            }

            50% {
                color: <?php echo e($new2->colorII); ?>;
                background-color: <?php echo e($new2->colorI); ?>;
                border: 2px solid <?php echo e($new2->colorI); ?>;
            }

            75% {
                color: <?php echo e($new3->colorII); ?>;
                background-color: <?php echo e($new3->colorI); ?>;
                border: 2px solid <?php echo e($new3->colorI); ?>;
            }

            100% {
                color: <?php echo e($new4->colorII); ?>;
                background-color: <?php echo e($new4->colorI); ?>;
                border: 2px solid <?php echo e($new4->colorI); ?>;
            }
        }

        @keyframes colorChangeT<?php echo e($new->name); ?> {
            0% {
                border: 3px solid <?php echo e($new0->colorI); ?>;
                box-shadow: 0 0 12px <?php echo e($new0->colorI); ?>, 0 0 14px <?php echo e($new0->colorI); ?>, 0 0 16px <?php echo e($new0->colorI); ?>, 0 0 18px <?php echo e($new0->colorI); ?>;
            }

            25% {
                border: 3px solid <?php echo e($new1->colorI); ?>;
                box-shadow: 0 0 12px <?php echo e($new1->colorI); ?>, 0 0 14px <?php echo e($new1->colorI); ?>, 0 0 16px <?php echo e($new1->colorI); ?>, 0 0 18px <?php echo e($new1->colorI); ?>;
            }

            50% {
                border: 3px solid <?php echo e($new2->colorI); ?>;
                box-shadow: 0 0 12px <?php echo e($new2->colorI); ?>, 0 0 14px <?php echo e($new2->colorI); ?>, 0 0 16px <?php echo e($new2->colorI); ?>, 0 0 18px <?php echo e($new2->colorI); ?>;
            }

            75% {
                border: 3px solid <?php echo e($new3->colorI); ?>;
                box-shadow: 0 0 12px <?php echo e($new3->colorI); ?>, 0 0 14px <?php echo e($new3->colorI); ?>, 0 0 16px <?php echo e($new3->colorI); ?>, 0 0 18px <?php echo e($new3->colorI); ?>;
            }

            100% {
                border: 3px solid <?php echo e($new4->colorI); ?>;
                box-shadow: 0 0 12px <?php echo e($new4->colorI); ?>, 0 0 14px <?php echo e($new4->colorI); ?>, 0 0 16px <?php echo e($new4->colorI); ?>, 0 0 18px <?php echo e($new4->colorI); ?>;
            }
        }

        .glowing-outline<?php echo e($new->name); ?> {
            font-size: 24px;
            font-weight: bold;
            color: #ffffff;
            padding: 20px 40px;
            text-align: center;
            border: 3px solid transparent;
            border-radius: 10px;
            position: relative;
            background-color: #2a2a2a;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
            transition: 0.5s;  
            animation: colorChange<?php echo e($new->name); ?> 12s infinite;
        }


        .glowing-outline<?php echo e($new->name); ?>:before,
        .glowing-outline<?php echo e($new->name); ?>:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 7px;
            border: 3px solid <?php echo e($new->colorI); ?>;
            box-shadow: 0 0 12px <?php echo e($new->colorI); ?>, 0 0 14px <?php echo e($new->colorI); ?>, 0 0 16px <?php echo e($new->colorI); ?>, 0 0 18px <?php echo e($new->colorI); ?>;
            opacity: 0;
            transition: 0.5s;
            animation: colorChangeT<?php echo e($new->name); ?> 12s infinite;
        }


        .glowing-outline<?php echo e($new->name); ?>:before {
            filter: blur(10px);
        }


        .glowing-outlin<?php echo e($new->name); ?>:hover:before,
        .glowing-outline<?php echo e($new->name); ?>:hover:after {
            opacity: 1;
        }
    </style>
        
        

        
    </div>
    

</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\dispatch\RegAdd.blade.php ENDPATH**/ ?>