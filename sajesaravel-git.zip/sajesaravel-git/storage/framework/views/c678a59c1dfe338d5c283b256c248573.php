<div id="fired_tr4" class="" style=" margin:0;padding:0;height:60px; width:60px;">
    <div class="fire">
        <div class="flames">
            <div class="flame"></div>
            <div class="flame"></div>
            <div class="flame"></div>
            <div class="flame"></div>
        </div>
        <div class="logs"></div>
    </div>
</div>
<style>
    #fired_tr4 {
        /* background-color: #111217; */
        background-color: inherit;
        position: relative;
    }

    #fired_tr4 .fire {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -25%);
        /* height: 20vw; */
        /* width: 20vw;  */
        height: 100%;
        width: 100%;
    }

    #fired_tr4 .fire .flames {
        position: absolute;
        bottom: 40%;
        left: 50%;
        width: 60%;
        height: 60%;
        transform: translateX(-50%) rotate(45deg);
    }

    #fired_tr4 .fire .flames .flame {
        position: absolute;
        right: 0%;
        bottom: 0%;
        width: 0%;
        height: 0%;
        background-color: #ffdc01;
        border-radius: 1vw;
    }

    #fired_tr4 .fire .flames .flame:nth-child(2n+1) {
        -webkit-animation: flameodd 1.5s ease-in infinite;
        animation: flameodd 1.5s ease-in infinite;
    }

    #fired_tr4 .fire .flames .flame:nth-child(2n) {
        -webkit-animation: flameeven 1.5s ease-in infinite;
        animation: flameeven 1.5s ease-in infinite;
    }

    #fired_tr4 .fire .flames .flame:nth-child(1) {
        -webkit-animation-delay: 0s;
        animation-delay: 0s;
    }

    #fired_tr4 .fire .flames .flame:nth-child(2) {
        -webkit-animation-delay: 0.375s;
        animation-delay: 0.375s;
    }

    #fired_tr4 .fire .flames .flame:nth-child(3) {
        -webkit-animation-delay: 0.75s;
        animation-delay: 0.75s;
    }

    #fired_tr4 .fire .flames .flame:nth-child(4) {
        -webkit-animation-delay: 1.125s;
        animation-delay: 1.125s;
    }

    #fired_tr4 .fire .logs {
        position: absolute;
        bottom: 25%;
        left: 50%;
        transform: translateX(-50%);
        width: 100%;
        height: 15%;
    }

    #fired_tr4 .fire .logs:before,
    #fired_tr4 .fire .logs:after {
        position: absolute;
        content: "";
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(20deg);
        height: 100%;
        width: 100%;
        border-radius: 1vw;
        background-color: #70392f;
    }

    #fired_tr4 .fire .logs:before {
        transform: translate(-50%, -50%) rotate(-20deg);
        background-color: #612e25;
    }

    @-webkit-keyframes flameodd {

        0%,
        100% {
            width: 0%;
            height: 0%;
        }

        25% {
            width: 100%;
            height: 100%;
        }

        0% {
            background-color: #ffdc01;
            z-index: 1000000;
        }

        40% {
            background-color: #fdac01;
            z-index: 1000000;
        }

        100% {
            background-color: #f73b01;
            z-index: -10;
        }

        0% {
            right: 0%;
            bottom: 0%;
        }

        25% {
            right: 1%;
            bottom: 2%;
        }

        100% {
            right: 150%;
            bottom: 170%;
        }
    }

    @keyframes flameodd {

        0%,
        100% {
            width: 0%;
            height: 0%;
        }

        25% {
            width: 100%;
            height: 100%;
        }

        0% {
            background-color: #ffdc01;
            z-index: 1000000;
        }

        40% {
            background-color: #fdac01;
            z-index: 1000000;
        }

        100% {
            background-color: #f73b01;
            z-index: -10;
        }

        0% {
            right: 0%;
            bottom: 0%;
        }

        25% {
            right: 1%;
            bottom: 2%;
        }

        100% {
            right: 150%;
            bottom: 170%;
        }
    }

    @-webkit-keyframes flameeven {

        0%,
        100% {
            width: 0%;
            height: 0%;
        }

        25% {
            width: 100%;
            height: 100%;
        }

        0% {
            background-color: #ffdc01;
            z-index: 1000000;
        }

        40% {
            background-color: #fdac01;
            z-index: 1000000;
        }

        100% {
            background-color: #f73b01;
            z-index: -10;
        }

        0% {
            right: 0%;
            bottom: 0%;
        }

        25% {
            right: 2%;
            bottom: 1%;
        }

        100% {
            right: 170%;
            bottom: 150%;
        }
    }

    @keyframes flameeven {

        0%,
        100% {
            width: 0%;
            height: 0%;
        }

        25% {
            width: 100%;
            height: 100%;
        }

        0% {
            background-color: #ffdc01;
            z-index: 1000000;
        }

        40% {
            background-color: #fdac01;
            z-index: 1000000;
        }

        100% {
            background-color: #f73b01;
            z-index: -10;
        }

        0% {
            right: 0%;
            bottom: 0%;
        }

        25% {
            right: 2%;
            bottom: 1%;
        }

        100% {
            right: 170%;
            bottom: 150%;
        }
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\fire.blade.php ENDPATH**/ ?>