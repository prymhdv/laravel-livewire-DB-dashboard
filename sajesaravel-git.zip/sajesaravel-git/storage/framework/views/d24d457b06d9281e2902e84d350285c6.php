<div id="carouselExampleControlsNoTouching" class="carousel slide  p-3 m-auto " data-bs-touch="false">
    <div class="carousel-inner pry-border1 shadow1">
        <div class="carousel-item active">
            <img loading="lazy"class="d-block w-100"
            src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-01.jpg"
            alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">

        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-02.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-03.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
            src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-04.jpg"
            alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-05.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-06.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching"
        data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching"
        data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\dispatch\banner-bs5.blade.php ENDPATH**/ ?>