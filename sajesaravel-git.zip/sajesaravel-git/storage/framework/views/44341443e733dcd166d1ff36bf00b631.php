<div id="mobile-menu" class=" row justify-content-center   align-content-center">
    
    <div class="main-menu s-main-menu d-inline-block ">
        <ul class="  justify-content-center align-content-center">
            <li class=" mx-lg-2 ">
                <a  href="<?php echo e(route('home.index.Route')); ?>" class="p-0">
                    <i class="fa fa-home ml-3 ml-lg-1  "></i>خانه
                </a>
            </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('formulaone.index.Route')); ?>">
                    <i class="fas fa-car-alt ml-3"></i>فرمول یک
                </a>
            </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('confrence.index.Route')); ?>">
                    <i class="fas fa-users ml-3"></i>همایش ها
                </a>
            </li>
            <li class="d-none d-lg-none"><a wire:navigate href="<?php echo e(route('finalexams.index.Route')); ?>">
                    <i class="far fa-newspaper ml-3 "></i>امتحان نهایی
                </a>
            </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('counsellor.employee.pages.home.Route')); ?>">
                    <i class="fas fa-users-cog ml-3 "></i>استخدام مشاور
                </a>
            </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>">
                    <i class="fas fa-laptop ml-3"></i>انتخاب رشته</a> </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('farhangian.index.Route')); ?>">
                    <i class="fas fa-book-reader ml-3"></i>
                    کنکور 1404 و فرهنگیان
                </a>
            </li>
            <li class="d-block d-lg-none"><a wire:navigate href="<?php echo e(route('dispatch.index.Route')); ?>">
                    <i class="fas fa-user-graduate ml-3"></i>اعزام دانشجو
                </a>
            </li>
            <li class="d-block d-lg-none">
                <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>">
                    <i class="fa fa-rocket ml-3"></i>امتحانات
                </a>
            </li>
            <li class="d-none d-lg-none">
                <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>">
                    <i class="fa fa-rocket ml-3"></i>امتحانات ترم اول (طرح بوستر)
                </a>
            </li>
            
            <?php if(Auth::check()): ?>
                <li>
                    <div class="container text-center text-light p-2 mt-2">
                        <span class="row justify-content-between align-items-center">
                            <div class="col  ">
                                
                                کاربر:
                                <?php switch(Auth::user()->role):
                                    case ('admins'): ?>
                                        <span class="mx-1">ادمین</span>
                                        <span><?php echo e(Auth::user()->admin->afname . '  ' . Auth::user()->admin->alname . '  ' . Auth::user()->admin->ausername); ?></span>
                                    <?php break; ?>

                                    <?php case ('operators'): ?>
                                        <span class="mx-1">اوپراتور</span>
                                        <span><?php echo e(Auth::user()->operator->ofname . '  ' . Auth::user()->operator->olname . '  ' . Auth::user()->operator->ousername); ?></span>
                                    <?php break; ?>

                                    <?php case ('teachers'): ?>
                                        <span class="mx-1">معلم</span>
                                        <span><?php echo e(Auth::user()->teacher->tfname . '  ' . Auth::user()->teacher->tlname . '  ' . Auth::user()->teacher->tcellphone); ?></span>
                                    <?php break; ?>

                                    <?php case ('customers'): ?>
                                        <span class="mx-1">مشتری</span>
                                        <span><?php echo e(Auth::user()->customer->cusername . '  ' . Auth::user()->customer->contactid); ?></span>
                                    <?php break; ?>

                                    <?php case ('counselors'): ?>
                                        <span class="mx-1">مشاور</span>
                                        <span><?php echo e(Auth::user()->counselor->csfname . '  ' . Auth::user()->counselor->cslname . '  ' . Auth::user()->counselor->csusername); ?></span>
                                    <?php break; ?>

                                    <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                                        
                                        <span><?php echo e(Auth::user()->nameFirst . '  ' . Auth::user()->nameLast . '  ' . Auth::user()->mobile); ?></span>
                                    <?php break; ?>

                                    <?php default: ?>
                                        <span><?php dd('با شماره زیر تماس بگیرید.. tell:+989907428464'); ?></span>
                                <?php endswitch; ?>


                            </div>
                            <div class="col">
                                <a class="mb-2 p-2"
                                    <?php switch(Auth::user()->role): 
                                        case ('admins'): ?>
                                            href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
                                        <?php break; ?>

                                        <?php case ('operators'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('teachers'): ?>
                                            href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('customers'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('counselors'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                                  
                                            href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
                                        <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?>
                                    style="border-top: none;">
                                    <i class="fas fa-user-cog ml-1"></i>
                                    پنل کاربری
                                </a>
                            </div>
                            <div class="col"> <a class="  mb-2 p-2" href="<?php echo e(route('sign.logout_confirm.Route')); ?>"
                                    style="border-top: none;">
                                    <i class="fas fa-sign-out-alt ml-1"></i>خروج</a></div>
                        </span>
                    </div>



                </li>
            <?php else: ?>
                <li class="d-none">
                    <a class="mb-2 p-2 mx-lg-2 " href="<?php echo e(route('sign.register_page.Route')); ?>">
                        <i class="fas fa-user-plus ml-3 ml-lg-1"></i>
                        ثبت نام
                    </a>
                </li>

                <li>
                    <a class="mb-2 p-2 mx-lg-2  "  href="javascript:void(0)"
                        onclick="Livewire.dispatchTo('auth.sign','loginRegiser',{Page:'loginRegiser'})">

                        <i class="fas fa-sign-in-alt ml-3 ml-lg-1"></i>
                        ورود
                        <i class="fas fa-user-plus ml-3 ml-lg-1 mr-lg-2"></i>
                        ثبت نام
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<script>
    function addtocart(pid) {
        $.ajax({
            method: 'post',
            url: 'ajax',
            data: {
                pid: pid
            },
            success: function(msg) {
                $('#cart').html(msg);
            }
        }).done(function(result) {
            window.location.replace("cart");
        });
    };
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partials\header_menuMobile.blade.php ENDPATH**/ ?>