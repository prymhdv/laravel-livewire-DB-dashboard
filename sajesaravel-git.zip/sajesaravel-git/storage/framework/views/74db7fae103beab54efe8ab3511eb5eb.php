<!-- header -->
<header class="sticky-menuu shadow1 scrollFade" style=" min-height:1%;">
    
    <div class="main-header-area five-main-header-area pryh1" style="padding: 2px!important; padding-bottom: 0px;">
        <div class="container myLinks">
            <div class="row justify-content-center align-content-center ">
                <div class="col-12 p-0">
                     
                    <div id="mobile" class="  " style="z-index: 1000">
                        <div class="row align-content-center">
                           
                            <div class="col-6 col-lg-3 col-md-4 align-content-center ">
                                <div class="logo ">
                                    <a href="<?php echo e(route('home.index.Route')); ?>">
                                        <img loading="lazy"
                                            src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>"
                                            class="" sizes="max-height:50px;" width="100%" alt="logo"></a>
                                </div>
                            </div>
                            <div class="col-lg-9 text-end d-none d-lg-block p-0 "> 
                            
                                <?php echo $__env->make('pages.partials.header_menuMobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                            
                            <div class="col-12 d-none d-sm-block" style="  min-height:80px;">
                                <div class="mobile-menu" style="border-radius: 3px;"></div>
                            </div>
                            <button class="navbar-toggler" type="button" > <span class="navbar-toggler-icon"></span> </button>
                        </div>
                        <script>
                            function ShowDivMobile() {
                                var x = document.getElementById("myLinks");
                                if (x.style.display === "block") {
                                    x.style.display = "none";

                                } else {
                                    x.style.display = "block";
                                }
                            }
                        </script>
                        <style>
                            /* for browsers larger than 1200px width */
                            @media only screen and (max-width: 1200px) {
                                /* .pryh1{
                                    max-height:70px!importan;
                                    overflow:hidden!importan;
                               } */
                            }

                            @media (min-width: 768px) and (max-width: 991px) {
                                .main-header-area {
                                    padding-top: 10px !important;
                                    padding-bottom: 10px !important;
                                }
                            }
                        </style>
                    </div>

 
                    <div id="desktop" class="dpt-area d-none d-lg-block mt-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="dpt-menu s-dpt-menu text-center shadow1 "
                                    style="margin-top: -15px!important;">
                                    <?php echo $__env->make('pages.partials.header_menuDesktop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="headofset" style=" height:10px;  " class="scrollFade2 mb-3
    
    ">
</div>

<script>
    $(document).ready(function() {
        // Function to update the height of 'headofset'
        //console.log('header:',$('header').height());
        function updateHeight() {
            //console.log('header:',$('header').height(),$('#headofset').height());
            $('#headofset').height($('header').height() + $('header').height() * 0.01);
        }

        // Initial height update
        updateHeight();

        // Update height on window resize
        $(window).resize(function() {

            updateHeight();
        });
    });
</script>





<!-- HockeyTeamListItem.vue -->




<style>
    /* @media (min-width: 1200px) {
        .container {
            max-width: 1170px;
        }
    }

    @media (min-width: 1400px) {
        .container {
            max-width: 1370px;
        }
    } */
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\dashboard\partials copy\header.blade.php ENDPATH**/ ?>