<?php if(request()->route()->getName() !== 'fieldSelection.DashboardStudentLivewireRoute' || Str::contains($this?->pageState??'', 'admin.student.fieldSelection.main.manage')  ): ?>
    <div>
      
        
        <div class="col-md-12 p-1 text-start mb-5">
            <div class="card ">
                <div class="row w-100 justify-content-center align-content-center">
                    <div class="col-md-12 p-0 fs-3 text-center align-content-center">
                        <div class="row w-100 justify-content-center align-content-center">
                            <div class="col-1 p-0 text-nowrap justify-content-center align-content-center">
                                ردیف
                            </div>
                            <div class="col-2 p-0 text-nowrap align-content-center">
                                مشخصات
                            </div>
                            <div class="col  p-0 align-content-center">
                                وضعیت
                            </div>
                            
                            <div class="col  p-0 align-content-center">
                                نوع پذیرش
                            </div>
                            <div class="col-3 p-0 text-nowrap align-content-center">
                                عملیات
                            </div>
                        </div>
                        <hr class="p-0 m-1">
                    </div>
                    <?php
                        $items = [];
                        // dd(isset($id),'list',(isset($id) && ($id!=null|| $id!=0)),(isset($id) && ($id!=0)));
                        if (isset($id) && $id != 0) {
                            $items = [App\Models\UserStudentFieldSelection::find($id)];
                            // dd('1',$items );
                        }
                        if (isset($id) && $id == 'all') {
                            $items = App\Models\UserStudentFieldSelection::with('user')->paginate(10);
                            // dd('2',$items );
                        }
                        if (!isset($id) && $id == 0) {
                            $items = [App\Models\UserStudentFieldSelection::find(Auth::user()->id())];
                            // dd('3',$items );
                        }
                        // $items = \App\Models\UserStudentFieldSelection::paginate(5);
                    ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 p-0 fs-3 text-center align-content-center">
                            <div class="row w-100 justify-content-center align-content-center">
                                <div class="col-1 p-0 text-nowrap justify-content-center align-content-center">
                                    <div
                                        class="d-flex flex-row flex-wrap  justify-content-center align-content-center ">
                                        <?php echo e($item->id); ?>

                                        <i
                                            class="fa fa-check-circle fa-2x mx-2 "style="color:<?php echo $item->status=='active' ? "green" : "red" ?> ;"></i>
                                    </div>
                                </div>
                                <div class="col-md-2 p-0 text-nowrap align-content-center">
                                    <?php echo e($item->user->nameFirst . ' ' . $item->user->nameLast . ' ' . $item->user->mobile); ?>

                                </div>
                                <div class="col  p-0 align-content-center">
                                    <?php echo e($item->status); ?>

                                </div>
                                <div class="col  p-0 align-content-center">
                                    <?php echo e($item->rotbe); ?>

                                </div>
                                <div class="col  p-0 align-content-center">
                                    <?php echo e($item->count); ?>

                                </div>
                                <div class="col  p-0 align-content-center">
                                    <?php echo e(optional($item->wantA)->wantedCounsellor); ?>

                                </div>
                                <div class="col-md-3   p-0 text-nowrap align-content-center">
                                    <div class=" row justify-content-center align-content-center">
                                        
                                        <div class="col p-1 selection: text-nowrap">
                                            <button id="itemDel<?php echo e($item->id); ?>" class="btn btn-danger mt-1 p-1 fs-3"
                                                style="width: 100%;">
                                                حذف
                                            </button>
                                            
                                            <script data-navigate-once>
                                                document.addEventListener('livewire:navigated', () => {
                                                    //    var regSms() = function() { 
                                                    $('#itemDel<?php echo e($item->id); ?>').click(function() {
                                                        // console.log( $('#bodySet')[0],'------------',$('#titleSet')[0].value);
                                                        $.ajax({
                                                            method: 'post',
                                                            url: "<?php echo e(route('del.manage.counsellors.fieldSelection.student.adminPanelLivewireRoute')); ?>",
                                                            data: {
                                                                id: "<?php echo e($item->id); ?>",
                                                                _token: '<?php echo e(csrf_token()); ?>',
                                                            },
                                                            success: function(msg) {},
                                                            error: function(msg) {},
                                                        }).done(function() {
                                                            window.location.reload();
                                                        });
                                                    });
                                                });
                                            </script>
                                            
                                        </div>
                                        
                                        <div class="col p-1 text-nowrap">
                                            <a id="itemEdit<?php echo e($item->id); ?>" 
                                                href="<?php echo e(route('manage.main.student.fieldSelection.student.adminPanelLivewireRoute', ['id' => $item->id, 'state' => 'all'])); ?>"
                                                class="btn btn-warning mt-1 p-1 fs-3" style="width: 100%;">
                                                ویرایش
                                            </a>
                                            <div>

                                                <?php echo $__env->make(
                                                    'livewire.dashboard.admin.student.fieldSelection.student.code',
                                                    ['item' => $item]
                                                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            </div>
                                            
                                        </div>
                                        
                                        <?php if($item->status == 'active'): ?>
                                            <div class="col p-1 text-nowrap">
                                                <button id="itemDeactive<?php echo e($item->id); ?>"
                                                    class="btn btn-secondary mt-1 p-1 fs-3" style="width: 100%;">
                                                    غیر فعالسازی
                                                </button>
                                                
                                                <script data-navigate-once>
                                                    document.addEventListener('livewire:navigated', () => {
                                                        //    var regSms() = function() { 
                                                        $('#itemDeactive<?php echo e($item->id); ?>').click(function() {
                                                            // console.log( $('#bodySet')[0],'------------',$('#titleSet')[0].value);
                                                            $.ajax({
                                                                method: 'post',
                                                                url: "<?php echo e(route('deactive.manage.counsellors.fieldSelection.student.adminPanelLivewireRoute')); ?>",
                                                                data: {
                                                                    id: "<?php echo e($item->id); ?>",
                                                                    _token: '<?php echo e(csrf_token()); ?>',
                                                                },
                                                                success: function(msg) {},
                                                                error: function(msg) {},
                                                            }).done(function() {
                                                                window.location.reload();
                                                            });
                                                        });
                                                    });
                                                </script>
                                                
                                            </div>
                                        <?php endif; ?>
                                        <?php if($item->status != 'active'): ?>
                                            <div class="col p-1  text-nowrap">
                                                <button id="itemActive<?php echo e($item->id); ?>"
                                                    class="btn btn-success mt-1 p-1 fs-3" style="width: 100%;">
                                                    فعالسازی
                                                </button>
                                                
                                                <script data-navigate-once>
                                                    document.addEventListener('livewire:navigated', () => {
                                                        //    var regSms() = function() { 
                                                        $('#itemActive<?php echo e($item->id); ?>').click(function() {
                                                            // console.log( $('#bodySet')[0],'------------',$('#titleSet')[0].value);
                                                            $.ajax({
                                                                method: 'post',
                                                                url: "<?php echo e(route('active.manage.counsellors.fieldSelection.student.adminPanelLivewireRoute')); ?>",
                                                                data: {
                                                                    id: "<?php echo e($item->id); ?>",
                                                                    _token: '<?php echo e(csrf_token()); ?>',
                                                                },
                                                                success: function(msg) {},
                                                                error: function(msg) {},
                                                            }).done(function() {
                                                                window.location.reload();
                                                            });
                                                        });
                                                    });
                                                </script>
                                                
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <hr class="p-0 m-1">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="div" style="direction:ltr">
                        <?php if(isset($items) && $items instanceof Illuminate\Pagination\LengthAwarePaginator && $items->hasPages()): ?>
                            <?php echo e($items->links()); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


<?php if(request()->route()->getName() == 'fieldSelection.DashboardStudentLivewireRoute'): ?>
    <?php echo $__env->make('livewire.dashboard.admin.student.fieldSelection.student.code', [
        'item' => optional(Auth::user()->student)->fieldSelection,
        'isStudent' => true,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\student\fieldSelection\student\list.blade.php ENDPATH**/ ?>