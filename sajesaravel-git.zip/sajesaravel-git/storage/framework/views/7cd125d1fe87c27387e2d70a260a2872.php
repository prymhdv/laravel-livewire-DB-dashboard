<script>
    // //If the cookie was set with the HttpOnly flag, it cannot be accessed or deleted using JavaScript.
    // document.cookie =
    //     "laravel_sanjeshbonyad_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=sanjeshbonyad.org;";
    // window.onload = function() {
    //     document.cookie = "laravel_sanjeshbonyad_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; Secure;";
    // };
    // // document.cookie = `laravel_sanjeshbonyad_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
</script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        const DocNativeEvents = ['click', 'dblclick', 'mouseup', 'mousedown', 'contextmenu', 'mousewheel',
            'DOMMouseScroll', 'mouseover', 'mouseout', 'mousemove', 'selectstart', 'selectend', 'keydown',
            'keypress', 'keyup', 'orientationchange', 'touchstart', 'touchmove', 'touchend', 'touchcancel',
            'pointerdown', 'pointermove', 'pointerup', 'pointerleave', 'pointercancel', 'gesturestart',
            'gesturechange', 'gestureend', 'focus', 'blur', 'change', 'reset', 'select', 'submit',
            'focusin', 'focusout', 'load', 'unload', 'beforeunload', 'resize', 'move', 'DOMContentLoaded',
            'readystatechange', 'error', 'abort', 'scroll'
        ];
        DocNativeEvents.forEach(eventName => {
            document.addEventListener(eventName, (e) => {
                //    console.log(`...........DocNativeEvents: ${eventName}       e.detail: ${e.detail}`,e.detail);
            });
        });
        // List of relevant Livewire events
        const livewireEvents = [
            'livewire:init',
            'livewire:initialized',
            'window.Livewire',
            'livewire:load', // When Livewire components are loaded.
            'livewire:update', // When a component is updated.
            'livewire:dirty',
            'livewire:clear-dirty',
            'livewire:navigate',
            'livewire:navigating',
            'livewire:navigated',
            'livewire:commit',
            'livewire:updated',
            'livewire:element-updated',
            'livewire:message-sent', // When a message/request is sent to the server.
            'livewire:message-received', // When the response is received.
            'livewire:request-failed', // When a request fails.
            'livewire:poll',
            'livewire:destroyed'
        ];
        // Attach event listeners for tracking
        livewireEvents.forEach(eventName => {
            document.addEventListener(eventName, (e) => {
                console.log(
                    `...........livewireEvents: ${eventName}       e.detail: ${e.detail}`, e
                    .detail);
            });
        });
        console.log("Head Tracking Livewire 'sign' Component Events...");
        const alpineEvents = [
            'alpine:init', // Fires when Alpine initializes.
            'alpine:initialized', // Fires when Alpine has finished initialization.
            'alpine:before-start', // Fires before Alpine starts processing the DOM.
            'alpine:started', // Fires after Alpine starts processing the DOM.
            'alpine:before-morph', // Fires before Alpine morphs the DOM for updates.
            'alpine:after-morph', // Fires after Alpine morphs the DOM for updates.
            'alpine:intersect', // Fires when the x-intersect directive is triggered.
            'alpine:transition-start', // Fires when a transition starts.
            'alpine:transition-end', // Fires when a transition ends.
            'alpine:dirty', // Fires when a reactive property changes.
            'alpine:refresh', // Fires when Alpine refreshes its state.
            'alpine:destroy', // Fires when Alpine destroys a component.
            'alpine:nextTick', // Fires when Alpine finishes the nextTick queue.
        ];
        alpineEvents.forEach(eventName => { //alert('alpineEvents:',eventName);
            // document.addEventListener(eventName, function(e) {
            //     console.log(`Event: ${eventName}`, e.detail);
            // });
            document.addEventListener(eventName, (e) => {
                console.log(`...........alpineEvents: ${eventName}     e.detail: ${e.detail}`);
            });
        });
        // //Method	                                            Description
        // Livewire.first()	                                    //Get the first Livewire component's JS object on the page
        // Livewire.find(componentId)	                            //Get a Livewire component by it's ID
        // Livewire.all()	                                        //Get all the Livewire components on a page
        // Livewire.directive(directiveName, (el, directive, component) => {})	//Register a new Livewire directive (wire:custom-directive)
        // Livewire.hook(hookName, (...) => {})	                //Call a method when JS lifecycle hook is fired. Read more
        // Livewire.onLoad(() => {})	                            //Fires when Livewire is first finished loading on a page
        // Livewire.onError((message, statusCode) => {})	        //Fires when a Livewire request fails. You can return false from the callback to prevent Livewire's default behavior
        // Livewire.onPageExpired((response, message) => {})	    //When the page or session has expired it executes the callback instead of Livewire's page expired dialog
        // Livewire.emit(eventName, ...params)	                    //Emit an event to all Livewire components listening on a page
        // Livewire.emitTo(componentName, eventName, ...params)	//Emit an event to specific component name
        // Livewire.on(eventName, (...params) => {})	            //Listen for an event to be emitted from a component
        // Livewire.start()                                         //
        //Boot Livewire on the page (done for you automatically via  )
        // Livewire.stop()	                                        //Tear down Livewire from the page
        // Livewire.restart()	                                    //Stop, then start Livewire on the page
        // Livewire.rescan()	                                    //Re-scan the DOM for newly added Livewire components
    });
</script>

<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/headScript.blade.php ENDPATH**/ ?>