<script language="javascript" src="<?php echo e(asset('storage/assets/js/FarsiType.js')); ?>" type="text/javascript"></script>
<meta name="google-site-verification" content="Rot8OEEJPPzbKkX6y1O_FlRvDrgvaBk_SU9t7MqGocw" />
<!-- JS here -->



<script src="<?php echo e(asset('storage/assets/theme/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/jquery.meanmenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/ajax-form.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/jquery.waypoints.min.js')); ?>"></script>

<script src="<?php echo e(asset('storage/assets/theme/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/theme/js/main.js')); ?>"></script>


<script src="<?php echo e(asset('storage/assets/plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/switcher/js/switcher-rtl.js')); ?>"></script>






<script>
    $(document).ready(function() {

    });
</script>


<script wire:ignore>
     if (document.getElementById("countdown")) {
    // Target date (17 Bahman 1402 = 2024-02-06 20:30:00)
    const targetDate = new Date("2025-02-06T20:30:00");

    // Function to update the countdown
    function updateCountdown() {
        const currentDate = new Date();
        const difference = targetDate - currentDate;

        if (difference > 0) {
            // Calculate days, hours, minutes, seconds
            const days = Math.floor(difference / (1000 * 60 * 60 * 24));
            const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((difference % (1000 * 60)) / 1000);

            // Display the countdown
            document.getElementById("countdown").innerHTML =
                `${days} روز, ${hours} ساعت, ${minutes} دقیقه, و ${seconds} ثانیه باقی‌مانده، لایو بزرگ بنیاد سنجش`;
        } else {
            // If the target date has passed
            //document.getElementById("countdown").innerHTML = "The target date has already passed.";
        }
    }
    // Update the countdown every second
    setInterval(updateCountdown, 1000);
    // Initial call to display the countdown immediately when the page loads
    updateCountdown();
}
</script>

<script>
    var size = screen.width;
    if (size > 770) {
        var link = 'https://web.whatsapp.com/send?phone=989129730474';
    } else {
        var link = 'https://api.whatsapp.com/send?phone=989129730474';
    }
    var a = document.getElementById("whatsapp");
    a.setAttribute('href', link);
</script>
<script>
    // var size = screen.width;
    // $.ajax({
    //     method: 'post',
    //     url: '/include/nheader.php',
    //     data: {
    //         size: size
    //     },
    //     success: function(msg) {
    //         $('#header').html(msg);
    //     }
    // })
</script><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\layoutsII\body_script.blade.php ENDPATH**/ ?>