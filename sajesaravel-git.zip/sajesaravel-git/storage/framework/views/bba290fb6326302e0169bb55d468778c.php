  <div class="row justify-content-center   my-4 p-2 text-center"
      style="border-radius: 7px;      word-spacing: normal;   ">

      <h2 class="O_h2">انواع خدمات انتخاب رشته در بنیاد سنجش</h2>

      بنیاد سنجش با هدف پاسخ‌گویی به نیازهای متنوع داوطلبان و خانواده‌ها، خدمات انتخاب رشته را در پنج سطح طراحی کرده
      است. <br>
      هر سطح با میزان متفاوتی از نظارت، تحلیل، و شخصی‌سازی ارائه می‌شود تا تمامی داوطلبان بتوانند با توجه به شرایط خود،
      بهترین مسیر را انتخاب کنند:
      <div class="  p-2 justify-content-center ">

          <div class="O_card m-2 ">
              <div class="row justify-content-center align-content-center">
                  <div class="col-12 col-sm justify-content-center align-content-center">
                      
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/Product/cip.webp')); ?>"
                          style="width: 90%; border-radius:7px;" class="m-auto" alt="CIP حضوری">
                      <h3>انتخاب رشته حضوری CIP</h3>
                      <div class="O_price">۷ میلیون تومان</div>

                  </div>
                  <div class="O_description col justify-content-center align-content-center">

                      تحلیل کارنامه، تست شخصیت، چیدمان حرفه‌ای و بررسی نهایی توسط ناظران ارشد.
                      <hr>
                      <p class="text-end"> در این سطح، تمامی مراحل انتخاب رشته شامل تحلیل کارنامه، بررسی تیپ شخصیتی،
                          چیدمان
                          لیست رشته‌ها، و نظارت چندمرحله‌ای توسط مشاور ارشد و ناظران کل انجام می‌شود.چیدمان نهایی در این
                          نوع
                          انتخاب توسط ناظران ارشد مجموعه بررسی و نهایی می‌شود. </p>
                  </div>
              </div>
          </div>
           <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <div class="O_card m-2 ">
              <div class="row justify-content-center align-content-center">
                  <div class="col-12 col-sm  justify-content-center align-content-center">
                      
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/Product/vip.webp')); ?>"
                          style="width: 90%; border-radius:7px;" class="m-auto" alt="VIP حضوری">
                      <h3>انتخاب رشته حضوری VIP</h3>
                      <div class="O_price">۱۵ میلیون تومان</div>
                  </div>
                  <div class="O_description col justify-content-center align-content-center">
                      نظارت کامل توسط کارگروه ویژه دکتر گلباز؛ مناسب برای بالاترین سطح دقت.
                      <hr>
                      <p class="text-end">در این نوع، علاوه بر مراحل کامل و دقیق انتخاب رشته، چیدمان نهایی علاوه بر
                          ناظران کل، حتماً باید به تأیید کارگروه ویژه تحت نظر دکتر محمدامین گلباز برسد. این فرآیند برای
                          داوطلبانی طراحی شده که به‌دنبال اطمینان کامل، بررسی چندلایه و نظارت تخصصی شخصی‌سازی‌شده هستند.
                          تجربه داوطلبان سال‌های گذشته نشان داده است که این مدل بیشترین دقت و انطباق با اهداف تحصیلی را
                          داشته است.</p>
                  </div>
              </div>
          </div>
           <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <div class="O_card m-2 ">
              <div class="row justify-content-center align-content-center">
                  <div class="col-12 col-sm  justify-content-center align-content-center">
                      
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/Product/cip_online.webp')); ?>"
                          style="width: 90%; border-radius:7px;" class="m-auto" alt="CIP آنلاین">
                      <h3>انتخاب رشته آنلاین CIP</h3>
                      <div class="O_price">۵ میلیون تومان</div>
                  </div>
                  <div class="O_description col justify-content-center align-content-center">
                      تمام خدمات حضوری CIP به‌صورت آنلاین با مشاور اختصاصی و تأیید نهایی.
                      <hr>
                      <p class="text-end">تمامی خدمات مشابه حضوری CIP، با این تفاوت که داوطلب از هر نقطه کشور می‌تواند
                          به‌صورت آنلاین و بدون مراجعه حضوری در فرآیند انتخاب رشته شرکت کند. مشاور اختصاصی از طریق تماس
                          تلفنی در تمامی مراحل همراه داوطلب خواهد بود. چیدمان نهایی نیز توسط ناظران کل بررسی و تأیید
                          می‌شود.</p>
                  </div>
              </div>
          </div>
           <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <div class="O_card m-2 ">
              <div class="row justify-content-center align-content-center">
                  <div class="col-12 col-sm  justify-content-center align-content-center">
                      
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/Product/vip_online.webp')); ?>"
                          style="width: 90%; border-radius:7px;" class="m-auto" alt="VIP آنلاین">
                      <h3>انتخاب رشته آنلاین VIP</h3>
                      <div class="O_price">۱۰ میلیون تومان</div>
                  </div>
                  <div class="O_description col justify-content-center align-content-center">
                      انتخاب رشته VIP به‌صورت آنلاین، با تأیید نهایی دکتر گلباز و تیم تخصصی.
                      <hr>
                      <p class="text-end">فرآیندی کاملاً مشابه با حضوری VIP، اما به‌صورت آنلاین. مشاوره، تحلیل، چیدمان و
                          بررسی‌ها در محیطی مجازی انجام می‌شود و چیدمان نهایی داوطلب تنها پس از تأیید کارگروه ویژه دکتر
                          گلباز ثبت نهایی می‌شود. این گزینه برای داوطلبان شهرستانی یا کسانی که امکان حضور فیزیکی ندارند،
                          اما مایل به دریافت خدمات VIP هستند، بهترین انتخاب است.</p>
                  </div>
              </div>
          </div>
           <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <div class="O_card m-2 ">
              <div class="row justify-content-center align-content-center">
                  <div class="col-12 col-sm  justify-content-center align-content-center">
                      
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/Product/vvip.webp')); ?>"
                          style="width: 90%; border-radius:7px;" class="m-auto" alt="VVIP">
                      <h3>انتخاب رشته حضوری VVIP</h3>
                      <div class="O_price">25 میلیون تومان</div>
                  </div>
                  <div class="O_description col justify-content-center align-content-center">
                      انجام کامل فرآیند توسط شخص دکتر گلباز؛ مناسب برای انتخاب رشته فوق‌حرفه‌ای.
                      <hr>
                      <p class="text-end">ویژه‌ترین نوع انتخاب رشته بنیاد سنجش؛ در این سطح، تمام مراحل از صفر تا صد،
                          شخصاً و مستقیماً توسط دکتر محمدامین گلباز و کارگروه ویژه ایشان انجام می‌شود. این فرآیند شامل
                          مشاوره اختصاصی، تحلیل جامع، چیدمان لیست رشته‌ها، بررسی‌های دوبل و چندمرحله‌ای و پشتیبانی کامل
                          تا نهایی‌سازی انتخاب‌هاست. مناسب برای داوطلبانی با رتبه‌های درخشان تا خیلی نامناسب و یا
                          خانواده‌هایی که به‌دنبال انتخاب رشته کاملاً اختصاصی با بالاترین سطح تحلیل، دقت و نظارت هستند
                      </p>
                  </div>
              </div>
          </div>
           <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </div>

  </div>

  <style>
      .O_h2 {
          text-align: center;
          margin-bottom: 2rem;
          color: #222;
      }

      .O_cards-container {

          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
          gap: 1.5rem;
      }

      .O_card {
          background: white;
          border-radius: 20px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
          padding: 1.5rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          transition: transform 0.3s;
      }

      .O_card:hover {
          transform: translateY(-6px);
      }

      .O_card img {
          /* width: 64px;
          height: 64px; */
          margin-bottom: 1rem;
      }

      .O_card h3 {
          margin: 0.5rem 0;
          font-size: 1.2rem;
          color: #444;
      }

      .O_price {
          font-weight: bold;
          color: #007BFF;
          margin: 0.5rem 0;
      }

      .O_description {
          font-size: 0.95rem;
          color: #555;
      }
  </style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\products.blade.php ENDPATH**/ ?>