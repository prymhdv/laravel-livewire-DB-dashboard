<title>Dashboard</title>

<?php $__env->startSection('content'); ?>

<div id="loader"></div>

<div style="display:none;" id="myDiv">

<div class="flex justify-center">
<div class="w-8/12 bg-white p-6 rounded-sm">
Dashboard
</div>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\blog\dashboard.blade.php ENDPATH**/ ?>