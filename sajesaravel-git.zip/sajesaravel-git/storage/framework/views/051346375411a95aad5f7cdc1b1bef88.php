<style>
    :root {
        --bs-body-font-family: var(--bs-font-sans-serif);
        --bs-body-font-size: 1rem;
        /*--bs-body-font-weight: 400;*/
        /*  */
        --bs-body-font-family: 'iransans';
        --bs-body-font-size: 1rem;
        /*--bs-body-font-weight:bold;*/
    }

    html {
        font-family: 'iransans';
        font-weight: 500;
        font-weight: normal;
        font-style: normal;
        font-size: 16px;
    }

    body {}

    .fontSans {
        font-family: 'iransans';
    }

    /* Screen width	Font size
    320px (eg: iPhone 4 & 5)	16px
    768px (eg: iPad portrait)	18px
    1024px (eg: iPad landscape)	19px
    1280px	20px
    1536px	21px
    1920px	23px
    2560px	25px */
    /* If the screen size is 601px or more, set the font-size of <div> to 80px  @media only screen and (min-inline-size: 601px)*/
    /* If the screen size is 600px or less, set the font-size of <div> to 30px @media only screen and (max-inline-size: 600px)*/

    /* ---------------------------------------- */
    /* @media screen and just inition */
    @media (min-width: 768px) {

        html {
            /* Base font size */
            font-size: 16px !important;

        }


    }

    @media (min-inline-size: 520px) {

        html {
            /* Base font size */
            font-size: 14px !important;



        }

    }

    @media (min-inline-size: 320px) {

        html {
            /* Base font size */
            font-size: 12px !important;

        }


    }

    /* Styles for Desktop Devices */
    .fs-1 {
        font-size: 0.25rem !important;
    }

    .fs-2 {
        font-size: 0.50rem !important;
    }

    /* Large heading */
    .fs-3 {
        font-size: 0.75rem !important;
    }

    /* Medium heading */
    .fs-4 {
        font-size: 1.00rem !important;
    }



    /* Smaller heading */
    .fs-5 {
        font-size: 1.25rem !important;
    }


    /* Sub-heading */
    .fs-6 {
        font-size: 1.50rem !important;
    }

    /* Regular text */
    .fs-7 {
        font-size: 1.75rem !important;
    }

    /* Standard text */
    .fs-8 {
        font-size: 2.00rem !important;
    }

    /* Small text */
    .fs-9 {
        font-size: 2.25rem !important;
    }

    /* Smaller text */
    .fs-10 {
        font-size: 2.50rem !important;
    }

    /* Extra small text */
    .fs-11 {
        font-size: 2.75rem !important;
    }

    /* Extra small text */
    .fs-12 {
        font-size: 3.00rem !important;
    }

    /* Extra small text */
    .main-content {
        /* font-size: 18px; */
    }

    @media (min-width: 768px) {
        /* .fs-1 {
            font-size: 2.5rem !important;
        }

        .fs-2 {
            font-size: 2rem !important;
        }

        .fs-3 {
            font-size: 1.75rem !important;
        }

        .fs-4 {
            font-size: 1.5rem !important;
        } */
    }

    /* ------------------------------------ */
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/prymhdvAssets/css/font.blade.php ENDPATH**/ ?>