<?php

    $product = [
        [
            'name' => 'one',
            'price' => '780,000 تومان',
            'poster' => asset('storage/main/employee/counsellor/poster_II.webp'),
            'body' => 'one of one',
            'title' => ' آزمون استخدام و دوره مشاور',
            'href' => route('counsellor.employee.pages.home.Route'),
        ],
        [
            'name' => 'one',
            'price' => '300,000 تومان',
            'poster' => asset('storage/main/employee/counsellor/poster_I.webp'),
            'body' => 'one of one',
            'title' => 'آزمون استخدام مشاور',
            'href' => route('counsellor.employee.pages.home.Route'),
        ],
        //-----------------
        [
            'name' => 'one',
            'price' => '980,000 تومان',
            'poster' => asset('storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-tajrobi.webp'),
            'body' => 'one of one',
            'title' => 'تجربی',
            'href' => route('farhangian.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => '980,000 تومان',
            'poster' => asset('storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-riyazi.webp'),
            'body' => 'one of one',
            'title' => 'ریاضی',
            'href' => route('farhangian.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => '980,000 تومان',
            'poster' => asset('storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-ensani.webp'),
            'body' => 'one of one',
            'title' => 'انسانی',
            'href' => route('farhangian.index.Route'),
        ],
        //----------------
        [
            'name' => 'one',
            'price' => 'پیش ثبت نام',
            'poster' => asset('storage/main/home/0110-blue.webp'),
            // 'poster' => asset('storage/Pages/partials/Highlight-01.webp'),
            'body' => 'one of one',
            'title' => '(حضوری CIP) انتخاب رشته',
            'href' => route('entekhabReshte.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'پیش ثبت نام',
            'poster' => asset('storage/main/home/0110-red.webp'),
            // 'poster' => asset('storage/Pages/partials/Highlight-02.webp'),
            'body' => 'one of one',
            'title' => '(آنلاین CIP) انتخاب رشته',
            'href' => route('entekhabReshte.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'پیش ثبت نام',
            'poster' => asset('storage/main/home/0110-green.webp'),
            // 'poster' => asset('storage/Pages/partials/Highlight-03.webp'),
            'body' => 'one of one',
            'title' => '(حضوری VIP) انتخاب رشته',
            'href' => route('entekhabReshte.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'پیش ثبت نام',
            'poster' => asset('storage/main/home/0110-yellow.webp'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => '(آنلاین VIP) انتخاب رشته',
            'href' => route('entekhabReshte.index.Route'),
        ],
        //---------------------
        [
            'name' => 'one',
            'price' => 'دانشگاه های آلمان',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Germany.png'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Germany.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های ترکیه',
            'poster' => asset('storage/Pages/dispatch/Flag-Turkey.webp'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Turkiye.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های قبرس',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Cyprus.svg'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Cyprus.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های چین',
            'poster' => asset('storage/Pages/dispatch/Flag_of_the_Republic_of_China.png'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('China.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های روسیه',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Russia.svg.png'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Russia.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های ایتالیا',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Italy.svg'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Italy.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های آذربایجان',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Azerbaijan.png'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => route('Azarbayjan.dispatch.Route'),
        ],
        [
            'name' => 'one',
            'price' => 'دانشگاه های مالزی',
            'poster' => asset('storage/Pages/dispatch/Flag_of_Malaysia.png'),
            // 'poster' => asset('storage/Pages/partials/Highlight-04.webp'),
            'body' => 'one of one',
            'title' => 'اخذ پذیرش از',
            'href' => '#',
        ],

        //---------------------
    ];

?>
<div id="loop5R" class="container-fluid  ">
    <div id="owl-loop5R" class="owl-carousel owl-theme owl-loaded m-0 " style="direction:ltr;">
        <div class="owl-stage-outer">
            <div class="owl-stage d-flex flex-row justify-content-center align-content-center">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="owl-item justify-content-center align-content-center" style=" aspect-ratio:1;">
                        <div class="text-center justify-items-center"
                            style="background-color: #d4d4d494!important; border-radius:50%;  justify-self: center;    align-content: center;
                     width: 50%;height:50%; ">
                            <a class="product98 text-center " style="  " href="<?php echo e($item['href']); ?>">
                                <img src="<?php echo e($item['poster']); ?>" alt=""
                                    style=" justify-self: anchor-center; width: 60%;  border-radius:4px; "
                                    class="text-center">
                            </a>
                        </div>
                        <a href="<?php echo e($item['href']); ?>">
                            <div class="col-md-12 VFRD fs-3" style="">
                                <?php echo e($item['title']); ?> <br><?php echo e($item['price']); ?>

                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<style>
    .owl-item .VFRD {
        color: white;
         transition: all 0.3s ease-in-out 0s;
    }

    .owl-item:hover .VFRD {
        color: rgb(255, 255, 255);
        background-color: #83838312 !important;
        border-radius: 7px;
         transition: all 0.3s ease-in-out 0s;
    }
</style>
<style>
    .product98:hover {
        color: #4daf50 !important;
         transition: all 0.3s ease-in-out 0s;
    }
</style>


<script>
    $(document).ready(function() {
        var owl = $('#owl-loop5R');
        owl.owlCarousel({
            items: 6,
            loop: true,
            margin: 1,
            dots: false,
            autoplay: true,
            autoplayTimeout: 3000, // Set autoplay timeout
            autoplayHoverPause: true,
            mouseDrag: true,
            touchDrag: true,
            autoWidth: false,
            // responsive: {
            //     0: {
            //         items: 8 // 1 item for screen width 0px and up
            //     },
            //     400: {
            //         items: 9 // 2 items for screen width 400px and up
            //     },
            //     850: {
            //         items: 10 // 3 items for screen width 850px and up
            //     },
            //     1300: {
            //         items: 11 // 5 items for screen width 1300px and up
            //     },
            // },
        });
        // setTimeout(function() {}, 2000);
    });
</script>

<script>
    $(document).ready(function() {
        $("#toggle-iconDownC").on("click", function() {


            if ($("#fgb5brtrt").is(":hidden")) {
                // $('#fgb5brtrt').fadeIn();
                $("#loop5R").show();
                $('#LinkDFD').hide();
                $("#fgb5brtrt").slideDown();
               
                $('#toggle-iconUpC').show();
                $('#toggle-iconDownC').hide();
                return;
            }
            $("#loop5R").slideDown();
            $('#toggle-iconUpC').show();
            $('#toggle-iconDownC').hide();


        });
        $("#toggle-iconUpC").on("click", function() {

            if ($("#toggle-iconDownA").is(":visible")) {
                // $('#fgb5brtrt').fadeIn();
                $("#loop5R").slideUp();
                $("#fgb5brtrt").slideUp();
                $('#toggle-iconUpC').hide();
                $('#toggle-iconDownC').show();
                // alert('ggg');
                return;
            }
            $("#loop5R").slideUp();
            $('#toggle-iconUpC').hide();
            $('#toggle-iconDownC').show();

        });
    });
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\products.blade.php ENDPATH**/ ?>