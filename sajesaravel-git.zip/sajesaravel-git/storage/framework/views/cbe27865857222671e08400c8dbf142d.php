<script>
    // window.addEventListener("load", function () {
    window.addEventListener("DOMContentLoaded", function() {
        const button = document.getElementById("rotateButton");
        if (button) {
            // Add the rotating class when the page loads
            button.classList.add("rotating");

            // Optionally remove the animation after it's done to reset the button
            button.addEventListener("animationend", function() {
                button.classList.remove("rotating");
            });
        }
    });
    //_________________________________________________________________________________
    // $('#sticker').fadeIn('fast');
    // Add a scroll event listener to the window
    window.addEventListener("DOMContentLoaded", function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 0) {
            $(".scrollFade").fadeOut();
            $(".scrollFade2").fadeOut();
        } else {
            $(".scrollFade").fadeIn();
            $(".scrollFade2").fadeIn();
        }
    }); });
    //_________________________________________________________________________________
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/prymhdvAssets/js/scripts.blade.php ENDPATH**/ ?>