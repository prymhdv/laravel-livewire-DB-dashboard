<?php if (isset($component)) { $__componentOriginala7e3e3ab156e6fa1f86927d4765c5327 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7e3e3ab156e6fa1f86927d4765c5327 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(in_array(request()->route()->getName(),['static-sign-in', 'static-sign-up', 'register', 'login','password.forgot','reset-password'])): ?>
        <div class="container position-sticky z-index-sticky top-0">
            <div class="row">
                <div class="col-12">
                    
                </div>
            </div>
        </div>
        <?php if(in_array(request()->route()->getName(),['static-sign-in', 'login','password.forgot','reset-password'])): ?>
        <main class="main-content  mt-0">
            <div class="page-header page-header-bg align-items-start min-vh-100">
                    <span class="mask bg-gradient-dark opacity-6"></span>
            <?php echo e($slot); ?>

            
             </div>
        </main>
        <?php else: ?>
        <?php echo e($slot); ?>

        <?php endif; ?>

    <?php elseif(in_array(request()->route()->getName(),['rtl'])): ?>
    <?php echo e($slot); ?>

    <?php elseif(in_array(request()->route()->getName(),['virtual-reality'])): ?>
        <div class="virtual-reality">
            
            <div class="border-radius-xl mx-2 mx-md-3 position-relative"
                style="background-image: url('<?php echo e(asset('assets')); ?>/img/vr-bg.jpg'); background-size: cover;">
                
                <main class="main-content border-radius-lg h-100">
                    <?php echo e($slot); ?>


            </div>
            
            </main>
            
        </div>
    <?php else: ?>
        
        <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
            
            
            <?php echo e($slot); ?>


            
        </main>
        
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7e3e3ab156e6fa1f86927d4765c5327)): ?>
<?php $attributes = $__attributesOriginala7e3e3ab156e6fa1f86927d4765c5327; ?>
<?php unset($__attributesOriginala7e3e3ab156e6fa1f86927d4765c5327); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7e3e3ab156e6fa1f86927d4765c5327)): ?>
<?php $component = $__componentOriginala7e3e3ab156e6fa1f86927d4765c5327; ?>
<?php unset($__componentOriginala7e3e3ab156e6fa1f86927d4765c5327); ?>
<?php endif; ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\temp\app-Template\app.blade.php ENDPATH**/ ?>