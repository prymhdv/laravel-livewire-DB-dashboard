   <?php
   
   $arrVideos = [
    
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ دهم - استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دهم'],
   
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ دوازدهم انسانی-جلسه اول- استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'انسانی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ دوازدهم انسانی-جلسه دوم-استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'انسانی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ معاصر یازدهم-جلسه اول-استاد آزادی.mkv', 'class' => 'تاریخ معاصر', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ معاصر یازدهم-جلسه دوم-استاد آزادی.mkv', 'class' => 'تاریخ معاصر', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ یازدهم-جلسه اول-استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'tarix', 'folder' => 'تاریخ', 'title' => 'تاریخ یازدهم-جلسه دوم - استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
   
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دهم'],
   
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'jameShenasi', 'folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
   
       ['categoryI' => 'hoviatEjtemeie', 'folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی-جلسه اول-استاد میرزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'hoviatEjtemeie', 'folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی-جلسه دوم- استاد میرزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'hoviatEjtemeie', 'folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی جلسه سوم-استاد میزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
   
       ['categoryI' => 'dinZendegi', 'folder' => 'دین و زندگی', 'title' => 'دین و زندگی دوازدهم-جلسه اول.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'dinZendegi', 'folder' => 'دین و زندگی', 'title' => 'دین و زندگی دوازدهم-جلسه دوم.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['categoryI' => 'dinZendegi', 'folder' => 'دین و زندگی', 'title' => 'دین و زندگی یازدهم-جلسه اول-استاد نژادنجف.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['categoryI' => 'dinZendegi', 'folder' => 'دین و زندگی', 'title' => 'دین و زندگی یازدهم-جلسه دوم-استاد نژادنجف.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
   ];
//    $arrVideos = getBoosterVideo();
   $arrVideos = [];
   if (request('which') == 'I') {
       $arrVideos = getBoosterVideo();
   }
   if (request('which') == 'II') {
       $arrVideos = getBoosterIIVideo();
   }
   $classifiedVideos = [];
   // foreach ($arrVideos as $video){ $CategoriesVideos[$video['class']][] = $video;}
   
   $CategoriesVideos = [];
   foreach ($arrVideos as $video) {
       // Ensure the class and folder exist in the structure before assigning
       if (!isset($CategoriesVideos[$video['field_base']][$video['field']][$video['class']])) {
           $CategoriesVideos[$video['field_base']][$video['field']][$video['class']] = [];
       }
   
       // Add the video to the appropriate category
       $CategoriesVideos[$video['field_base']][$video['field']][$video['class']][] = $video;
   }
   
   // Output the categorized videos to check
   // echo '<pre>';
   // print_r($CategoriesVideos);
   // echo '</pre>';
   $fieldBase = Auth::user()->student->field_Base;
   $field = Auth::user()->student->field;
   
   $selectedVideos = [];
   ?>
   
   <!----------------------------------------------------array_keys($Videos[0]['folder']---------->

   <?php if(isset($CategoriesVideos[$fieldBase][$field]) || isset($CategoriesVideos[$fieldBase]['عمومی'])): ?>
       
       <?php if(isset($CategoriesVideos[$fieldBase][$field])): ?>
           <?php
               $videoSection = $CategoriesVideos[$fieldBase][$field];
               if (isset($CategoriesVideos[$fieldBase]['عمومی'])) {
                   $videoSection = $videoSection + $CategoriesVideos[$fieldBase]['عمومی'];
               }
           ?>
       <?php else: ?>
           <?php
               if (isset($CategoriesVideos[$fieldBase]['عمومی'])) {
                   $videoSection = $CategoriesVideos[$fieldBase]['عمومی'];
               }
           ?>
       <?php endif; ?>
       
       <?php $__currentLoopData = $videoSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexSection => $Videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
           
           <?php $__currentLoopData = $Videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexVideos => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php $selectedVideos[]=$video; ?>
               
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php
           // $selectedVideos[rand(0, count($selectedVideos) - 1)];
           // $selectedVideos = $selectedVideos[rand(0, 3)];
           //    $RandIndexs = array_rand($selectedVideos, 3);
           //    dd($selectedVideos, $RandIndexs, $selectedVideos[$RandIndexs]);
           // Declare an associative array
           $selectedVideos = RandElement($selectedVideos, 3);
       ?>
       
       
       <div class="col-12 p-0 py-2  align-content-center justify-content-center  mb-5 shadow1    "
           style="background-color: #f0f8ff50;">
           <div class="col-10 px-3  font-weight-bolder  pry-border1 shadow1  m-auto    text-bg-light " style="    ">
               <div class=" justify-content-between  align-items-center p-2  ">
                   نمونه جزوات <?php echo e($fieldBase); ?> <?php echo e($field); ?>

               </div>
           </div>

           <div class="owl-carousel owl-theme owl-loaded p-2  ">
               <div class="owl-stage-outer">
                   <div class="owl-stage">
                       <?php $__currentLoopData = $selectedVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexVideos => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           
                           <div class="owl-item">
                               <div class="p-0   "
                                   style=" border-radius:7px; border:1px solid #aaa; height:100%; width:100%;">

                                   <?php if($Videos[0]['field'] == 'انسانی'): ?>
                                       <img src="<?php echo e(asset('storage/' . $Videos[0]['posterE'])); ?>" alt="">
                                       <a class="btn btn-danger"
                                           href="<?php echo e(asset('storage/' . $Videos[0]['pdfE'])); ?>">دانلود جزوه
                                       </a>
                                   <?php elseif($Videos[0]['field'] == 'ریاضی'): ?>
                                       <img src="<?php echo e(asset('storage/' . $Videos[0]['posterR'])); ?>" alt="">
                                       <a class="btn btn-danger"
                                           href="<?php echo e(asset('storage/' . $Videos[0]['pdfR'])); ?>">دانلود جزوه</a>
                                   <?php elseif($Videos[0]['field'] == 'تجربی'): ?>
                                       <img src="<?php echo e(asset('storage/' . $Videos[0]['posterT'])); ?>" alt="">
                                       <a class="btn btn-danger w-100"
                                           href="<?php echo e(asset('storage/' . $Videos[0]['pdfT'])); ?>">دانلود جزوه</a>
                                   <?php endif; ?>
                               </div>
                           </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>

               </div>
           </div>




           <!-------------------------------------------------------------->
       </div>
       
   <?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\booster\DocumentsPreshow.blade.php ENDPATH**/ ?>