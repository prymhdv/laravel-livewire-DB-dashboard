<div id="Banner-Booster" class="col-md-8  py-3   align-content-center   ">
    <div class="d-flex  align-content-center justify-content-center " style=" border-radius:7px; ">
        <?php echo $__env->make('pages.student.entekhabReshte.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\fieldSelection\banner.blade.php ENDPATH**/ ?>