<div id="GetField" class="col-md-10"> 
        <div class="row my-1">
            <div class="input-group input-group-sm mb-3">
                <label class="col-3 input-group-text px-3" for="field">مقطع تحصیلی</label>
                <select id="field-select" name="field" class=" text-center  form-control" required
            wire:model="field"style="border:2px solid #ddd; border-radius:7px;">
            <option value="" hidden>مقطع تحصیلی</option>
            <option value="دیپلم">دیپلم</option>
            <option value="کارشناسی">کارشناسی</option>
            <option value="کارشناسی ارشد">کارشناسی ارشد</option>
            <option value="دکترا">دکترا</option>
        </select>
        <?php echo $__env->make('livewire.error', ['e' => 'field'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    </div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\employee.blade.php ENDPATH**/ ?>