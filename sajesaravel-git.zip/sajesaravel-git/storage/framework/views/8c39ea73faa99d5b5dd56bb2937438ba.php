<ul class="navbar-nav   justify-items-center mb-2"id="mainMenu">
   
    <li class="  nav-item ms-5 justify-content-center align-content-center text-middle d-none">
        <a  href="<?php echo e(route('DemoEntekhabreshte.pages.Route')); ?>" class="headbtn      ">
            <div class="d-flex flex-column justify-content-center align-content-center "> 
                <span class="fs-3 font-iransans justify-content-center align-content-center">دمو</span>
            </div>
        </a>
    </li>
    <li class="  nav-item ms-5 justify-content-center align-content-center text-middle ">
        <a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" class="headbtn      ">
            <div class="d-flex flex-column justify-content-center align-content-center "> 
                <span class="fs-3 font-iransans justify-content-center align-content-center">انتخاب رشته کنکور 1404</span>
            </div>
        </a>
    </li>
  
    <li class="  nav-item ms-5 justify-content-center align-content-center text-middle">
        <a wire:navigate href="<?php echo e(route('takhminRotbe.index.Route')); ?>" class="headbtn      ">
            <div class="d-flex flex-column justify-content-center align-content-center "> 
                <span class="fs-3 font-iransans justify-content-center align-content-center">تخمین رتبه کنکور 1404</span>
            </div>
        </a>
    </li>
    <li class="  nav-item ms-5 justify-content-center align-content-center text-middle">
        <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="headbtn      ">
            <div class="d-flex flex-column justify-content-center align-content-center "> 
                <span class="fs-3 font-iransans justify-content-center align-content-center ">سوالات امتحانات خرداد</span>
            </div>
        </a>
    </li>
    
    <li class="  nav-item ms-5 justify-content-center align-content-center text-middle ">
        <a href="<?php echo e(route('home.index.Route')); ?>"wire:navigate class="headbtn      ">
            <div class="d-flex flex-column justify-content-center align-content-center ">
                
                
                <span class="fs-3 font-iransans justify-content-center align-content-center">خانه</span>
            </div>
        </a>
    </li>


    <li class=" d-lg-none nav-item ms-3 justify-content-center align-content-center  ">
        <a wire:navigate href="<?php echo e(route('counsellor.employee.pages.home.Route')); ?>" class="headbtn    ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i id="HYUH"
                    class="fas fa-handshake  fa-beat <?php if(Request::is('*counsellor*')): ?> selected-pageNav <?php endif; ?> "
                    style="color:#d4af37!important;
                    animation-duration: var(--fa-animation-duration, 3s);
                    "></i>
                <span style="color:#4daf50;" class="fs-3">استخدام مشاور</span>
            </div>
        </a>
    </li>

    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('confrence.index.Route')); ?>"
            class="headbtn     justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class="fas fa-users      <?php if(Request::is('*confrence*')): ?> selected-pageNav <?php endif; ?>"></i>
                <span class="fs-3">همایش ها</span>
            </div>

        </a>
    </li>
    <li class="d-lg-none nav-item ms-3 justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>"
            class="headbtn justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class="fas fa-code-branch  fa-flip  
                  <?php if(Request::is('*entekhabReshte*')): ?> selected-pageNav <?php endif; ?>  
                      "
                    style="color:orangered ; 
                     animation: flip 5.2s infinite;
                    ">
                </i>
                <style>
                    @keyframes flip {
                        0% {
                            transform: rotateY(0deg);
                        }

                        50% {
                            transform: rotateY(180deg);
                        }

                        100% {
                            transform: rotateY(0deg);
                        }
                    }
                </style>
                <span class="fs-3">انتخاب رشته</span>
            </div>
        </a>
    </li>
    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">

        <a wire:navigate href="<?php echo e(route('takhminRotbe.index.Route')); ?>"
            class="headbtn justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class="fa-solid fa-cog fa-spin  <?php if(Request::is('*takhminRotbe*')): ?> selected-pageNav <?php endif; ?> "
                    style="animation: fa-spin 5s infinite linear;
                             --fa-animation-iteration-count: 1;
                             color:#00ff44;">
                </i>
                <span class="fs-3">تخمین رتبه کنکور</span>
            </div>
        </a>
    </li>

    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('farhangian.index.Route')); ?>"
            class="headbtn     justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i id="HYUH"
                    class=" fas fa-book-reader     fa-shake <?php if(Request::is('*farhangian*')): ?> selected-pageNav <?php endif; ?> "
                    style="color:#d4af37!important;
                        animation-duration: var(--fa-animation-duration, 4s);
                    ">
                </i>
                <span class="fs-3" style="color:#4daf50;">کنکور ۱۴۰۴ و فرهنگیان</span>
            </div>
        </a>
    </li>

    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('dispatch.index.Route')); ?>"
            class="headbtn     justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class=" fas fa-user-graduate    <?php if(Request::is('*dispatch*')): ?> selected-pageNav <?php endif; ?>   "></i>
                
                <span class="fs-3">اعزام دانشجو</span>
            </div>
        </a>
    </li>

    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"
            class="headbtn     justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class=" fas fa-rocket  fa-fade  <?php if(Request::is('*emtehanat_term_aval*')): ?> selected-pageNav <?php endif; ?> "
                    style="color:#006aff ; 
                     animation: fly 3.2s infinite;
                        text-shadow: #fc0 1px 0 10px;
                    ">
                </i>
                <style>
                    @keyframes fly {
                        0% {
                            text-shadow: #fc0 1px 0 10px;
                            transform: translateY(0px) rotateY(0deg);
                            color: #006aff;
                            opacity: 1;
                        }

                        12% {
                            transform: translateY(-18px) rotateY(45deg);
                        }

                        25% {
                            transform: translateY(-9px) rotateY(0deg);
                            opacity: .5;
                            color: #fbff00;
                        }

                        50% {
                            text-shadow: #ff0 2px 2px 15px;
                            transform: translateY(-0px) rotateY(0deg);
                            opacity: 1;
                        }

                        75% {
                            transform: translateY(-4px) rotateY(45deg);
                            color: #860000;
                        }

                        88% {
                            transform: translateY(-8px);
                            opacity: .5;
                        }

                        100% {
                            transform: translateY(0px) rotateY(0deg);
                            */ color: #96ff04;
                            text-shadow: #fc0 1px 0 10px;
                            opacity: 1;

                        }
                    }
                </style>
                
                <span class="fs-3">امتحانات</span>
            </div>
        </a>
    </li>

    <li class=" d-lg-none nav-item ms-3   justify-content-center align-content-center ">
        <a wire:navigate href="<?php echo e(route('formulaone.index.Route')); ?>"
            class="headbtn     justify-content-center align-content-center ">
            <div class="d-flex flex-column justify-content-center align-content-center">
                <i class=" fas fa-car-alt        <?php if(Request::is('*formulaone*')): ?> selected-pageNav <?php endif; ?> "></i>
                
                <span class="fs-3">فرمول یک</span>
            </div>
        </a>
    </li>



</ul>
<style>
    /*.navbar-nav .nav-item{
       max-height: 65px!important;
    }*/
    /*.headbtn {
        
    }*/
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/prymhdv/partials/navItem.blade.php ENDPATH**/ ?>