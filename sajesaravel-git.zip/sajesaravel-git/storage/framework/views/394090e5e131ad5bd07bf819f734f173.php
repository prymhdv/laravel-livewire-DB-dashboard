<link rel="preconnect" href="//fdn.fontcdn.ir">
<link rel="preconnect" href="//v1.fontapi.ir">
<link href="https://v1.fontapi.ir/css/IranNastaliq" rel="stylesheet">

<link href="https://v1.fontapi.ir/css/Lalezar" rel="stylesheet">

<link href="https://v1.fontapi.ir/css/Titr" rel="stylesheet">

<link href="https://v1.fontapi.ir/css/Farnaz" rel="stylesheet">

<link href="https://v1.fontapi.ir/css/Jadid" rel="stylesheet">

 

<nav class="">
    <ul>
        <!-- <li><a href="tarah-basham?pid=1"><i class="fas fa-book"></i>اگر من طراح باشم</a></li> -->
        <!-- <li><a href="ser"><i class="fas fa-receipt"></i>انتخاب رشته</a></li> -->
        <li class="d-none"><a wire:navigate href="<?php echo e(route('finalexams.index.Route')); ?>"><i
                    class="far fa-newspaper"></i>امتحانات نهایی</a></li>
        <li>
            <a wire:navigate href="<?php echo e(route('counsellor.employee.pages.home.Route')); ?>" class="linkMenu  ">
                
                    class="custom-class fa-2x d-none" />
                <i class=" fas fa-users-cog  fa-2x"></i>
                استخدام مشاور
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('confrence.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-users fa-2x"></i>
                
                همایش ها
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-laptop fa-2x"></i>
                
                
                انتخاب رشته
            </a>
        </li>
        <!-- <li><a href="./employment"><i class="fas fa-laptop"></i>فرصت شغلی</a></li> -->
        <li>
            <a wire:navigate href="<?php echo e(route('formulaone.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-car-alt fa-2x"></i>فرمول یک
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('farhangian.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-book-reader fa-2x"></i>
                کنکور 1404 و فرهنگیان
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('dispatch.index.Route')); ?>" class="linkMenu  ">
                <i class="fas fa-user-graduate fa-2x"></i>
                اعزام دانشجو
            </a>
        </li>
        <li>
            <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="linkMenu  ">
                <i class="fa fa-rocket fa-2x"></i>امتحانات
            </a>
        </li>
        <li class="d-none">
            <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="linkMenu  ">
                <i class="fa fa-rocket fa-2x"></i>
                امتحانات ترم اول (طرح بوستر)
            </a>
        </li>
    </ul>
    <?php if(request()->route()->getName()=='farhangian.index.Route'): ?>
    <div class="container p-0  "style="user-select: none;">
        <div class="row">
            <div class="col-12 p-0 user-select-none font-bold fsr-16" style="color:rgba(20, 20, 163, 0.822); 
            /* font-family: Iran Nastaliq, sans-serif; */
            font-family: Titr, sans-serif;"> 
                پرتال کاربری داوطلبان کنکور سراسری و فرهنگیان ۱۴۰۴
            </div>
        </div>
    </div>
    <?php endif; ?>
</nav>
<style>
    .fa-counseling::before {
        content: "\f0c0";
    }

    .linkMenu i {
        -webkit-transition: all 0.3s ease-out 0s;
        -moz-transition: all 0.3s ease-out 0s;
        -ms-transition: all 0.3s ease-out 0s;
        -o-transition: all 0.3s ease-out 0s;
        transition: all 0.3s ease-out 0s;
    }

    .linkMenu:hover i {
        color: var(--color_sanjesh_blue);
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partialsIII\header_menuDesktop.blade.php ENDPATH**/ ?>