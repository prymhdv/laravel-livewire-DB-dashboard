<!--[if BLOCK]><![endif]--><?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent') == 'PageCurrent_Success'): ?>
    <div class="col-12 justify-content-center align-content-center user-select-none text-center" style="height: 200px;width:90%;">
        <div class="col justify-content-center align-content-center text-center ">
            <h2 class="p-2 btn-Sanjesh1 text-bold bg-sanjesh-green text-white fsr-12 w-100" 
                <?php if(isset(Auth::user()->student) && isset(Auth::user()->student->farhangian)): ?>
                 wire:click="$dispatch('goStudentDashboard')"
                    <?php else: ?> 
                    
                    onclick="location.reload();"
                    <?php endif; ?>>
                با موفقیت ثبت گردید.
                <!--[if BLOCK]><![endif]--><?php if(isset(Auth::user()->student) && isset(Auth::user()->student->farhangian)): ?>
                <br>
                <small class="text-dark">جهت دانلود کلیک فرمایید!</small>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </h2>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php if(session()->has('Sign_PageCurrent')
           && isset(session('Sign_PageCurrent')[1]) && session('Sign_PageCurrent')[0] == 'PageCurrent_Success' && 
        (session('Sign_PageCurrent')[1] == 'counsellorRegistered'
         ||  session('Sign_PageCurrent')[1] == 'fieldSelectionRegistered'
         ||  session('Sign_PageCurrent')[1] == 'boosterIIRegistered')
         ): ?>
    <div class="col-12 justify-content-center align-content-center user-select-none text-center" style="height: 200px;width:90%;">
        <div class="col justify-content-center align-content-center text-center">
            <h2 class="p-2 btn-Sanjesh1 text-bold bg-sanjesh-green text-white fsr-12 w-100 " 
                
                  
                
                <?php if(session('Sign_PageCurrent')[1] == 'counsellorRegistered'): ?>
                wire:click="$dispatch('goEmployeeDashboard')"
                <?php endif; ?>
                <?php if(session('Sign_PageCurrent')[1] == 'fieldSelectionRegistered'): ?>
                
                onclick="window.location.href = '<?php echo e(route('fieldSelection.DashboardStudentLivewireRoute',['state'=>0])); ?>'"
                <?php endif; ?>
                <?php if(session('Sign_PageCurrent')[1] == 'boosterRegistered'): ?>
                
                onclick="window.location.href = '<?php echo e(route('booster.DashboardStudentLivewireRoute',['which'=>'I'])); ?>'"
                <?php endif; ?>
                <?php if(session('Sign_PageCurrent')[1] == 'boosterIIRegistered'): ?>
                
                onclick="window.location.href = '<?php echo e(route('booster.DashboardStudentLivewireRoute',['which'=>'II'])); ?>'"
                <?php endif; ?>
                > 
                با موفقیت ثبت گردید.
            </h2>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
 
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/auth/complete.blade.php ENDPATH**/ ?>