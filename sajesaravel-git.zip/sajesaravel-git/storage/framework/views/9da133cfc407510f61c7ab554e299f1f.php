<div id="carouselExampleIndicators" class="carousel slide pry-border1 shadow1" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-01.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-02.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-03.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-04.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-05.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-08.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/sanjeshBonyad_IMG/sanjeshBonyad-Enemad.webp" >
        </div>
        <div class="carousel-item">
            <img   fetchpriority="high"class="d-block w-100" src="/storage/Pages/home/Banners/homeMojavez.webp" >
        </div>
       
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\farhangian\carousel.blade.php ENDPATH**/ ?>