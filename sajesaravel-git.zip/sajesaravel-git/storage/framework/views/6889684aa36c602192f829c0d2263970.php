<div class=" col-12 p-2 mb-3  ">
    <div class="container text-center">
        <div class="row  justify-content-center align-content-center">
            <div class="col-6 p-2">
                <button class=" button-82-pushable text-center " role="button"
                    onclick="Livewire.dispatchTo('auth.sign','counsellorInit', { Page: 'counsellorInit' })">
                    <span class="button-82-shadow"></span>
                    <span class="button-82-edge"></span>
                    <span class="button-82-front text fs-4 p-2 px-3" style="    vertical-align: middle;">
                        <i class="fas fa-sign-in-alt fa-2x px-3  " style="    vertical-align: middle;"></i>
                        جهت ورود به پنل کاربری مشاوران بنیاد سنجش کلیک کنید!
                    </span>
                </button>
            </div>
            <?php if(1
            // Auth::check() &&
                    // Auth::user()->transaction()->exists() &&
                    // Auth::user()->transaction()->where('category_sub', 'employeeCunsellor')->where('status', 'verify_success')->first()
                    ): ?>
                <div class="col-6 p-2   ">
                    <a class="  text-decoration-none fs-4 text-center   " 
                        href="https://formafzar.com/form/zlofz" target="_blank">
                        <button class=" button-82-pushable text-center " role="button" >
                            <span class="button-82-shadow"></span>
                            <span class="button-82-edge"
                                style=" background: linear-gradient(to left,
                                                            #002a52 0%,
                                                            #0054a3 8%,
                                                            hsl(212, 100%, 32%) 92%,
                                                            hsl(202, 100%, 16%) 100%
                                                             );"></span>
                            <span class="button-82-front text fs-4 p-2 px-3"
                                style="background:#002a52; vertical-align: middle;">
                                <i class="fas   fa-user-plus  fa-2x px-3 " style=" vertical-align: middle;"></i>
                                جهت استخدام در موسسه بنیادسنجش کلیک کنید!
                            </span>
                        </button>
                    </a>

                </div>
                <div class="col-6 p-2">
                    <a class="  text-decoration-none fs-4 text-center   " 
                        href="https://formafzar.com/form/9hn8l" target="_blank">
                        <button class=" button-82-pushable text-center " role="button" >
                            <span class="button-82-shadow"></span>
                            <span class="button-82-edge"
                                style=" background: linear-gradient(to left,
                                                        #525100 0%,
                                                        #e7eb02 8%,
                                                        hsl(59, 100%, 32%) 92%,
                                                        hsl(59, 100%, 16%) 100%
                                                         );"></span>
                            <span class="button-82-front text fs-4 p-2 px-3"
                                style=" vertical-align: middle; color:red; background:yellow;">
                                <i class="fas   fa-user-plus  fa-2x px-3 " style=" vertical-align: middle;"></i>
                                لینک سریع:
                                <span class=" text-decoration-underline "> شرکت در آزمون + دوره تربیت
                                    مشاور</span>
                            </span>
                        </button>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\employee\counsellor\linksOff.blade.php ENDPATH**/ ?>