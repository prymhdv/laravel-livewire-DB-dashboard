
<?php $__env->startSection('pageTitle','وبلاگ'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('blog.showContentBlog', ['isAdmin' => $isAdmin], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('headerSub'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/blog/show.blade.php ENDPATH**/ ?>