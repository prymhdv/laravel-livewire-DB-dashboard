

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title> 429 - Woops. toast</title>
    <link rel="stylesheet" href="./style.css">
    <?php echo $__env->make('pages.layouts.headMeta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.headLinkScripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
    <?php echo $__env->make('components.prymhdvAssets.css.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.headStyle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.headScript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     
</head>

<body class="  " style="font-family: iransans;">
    <!-- partial:index.partial.html -->
    
    <div class="main-error-page">
       
        <?php echo $__env->make('errors.photosvg', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <h2 class="error-title fontSans">
            Woops! <br> ،درخواست بیش از حد :(
        </h2>
        <h2 class="error-subtitle  fontSans">
            دقایقی بعد دوباره مراجعه بفرمایید.
        </h2>


    </div>
    <!-- partial -->
    <script src="./script.js"></script>
    <?php echo $__env->make('errors.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

     <?php echo $__env->make('pages.layouts.bodyScript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
     <?php echo $__env->make('components.prymhdvAssets.js.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>

<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\errors\429.blade.php ENDPATH**/ ?>