<div class="" style="background-color: #fff;">
    
    
    
    <!-- Button to Open Modal -->
    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('RegSms_Loged')): ?>
        <div class="alert alert-success hideMe text-center shadow1">
            <?php echo e(session('RegSms_Loged')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
            </div>
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($isOpen || 0): ?>
        <div id="showSign" class="modal-overlay "
            style="position: fixed; top: 0; left: 0; 
               width: 100%; height: 100%; 
               background-color: rgba(36, 36, 36, 0.911); 
               z-index: 100; display: flex; 
               justify-content: center; 
               align-items: center;">
            <div id="modal-dialogX"class="modal-dialog modal-dialog-centere  justify-items-center  text-center w-100 justify-content-center"
                role="document" style="justify-items: center;">
                <div class="modal-content "
                    style="border-radius:4px;  width:80%; max-width:600px;
                /* width:450px; max-width:500px; */ max-height:70%;">
                   <?php echo $__env->make('livewire.auth.sign-modal-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="modal-body py-1 shadow1"
                        style=" z-index: 120!important; border: 1px solid #aaa!important;border-radius:4px; background-color: #ffffff;">
                        <div class="container text-center p-0">
                            <div class="row justify-content-center align-content-center">
                                
                                
                                

                                <div class="col-12 p-0 text-center">
                                    <div class="row justify-content-center align-content-center">
                                        <!--[if BLOCK]><![endif]--><?php if(!Auth::check() && !session()->has('Sign_form')): ?>
                                            <?php echo $__env->make('livewire.auth.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php echo $__env->make('livewire.auth.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                        <?php echo $__env->make('livewire.auth.complete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('livewire.auth.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        


        <script type="text/javascript">
            $(document).ready(function() {
                // $("#BTNregisterSMS").on('click', function(e) {
                //     // e.preventDefault();
                // });
                // // Listen for the 'close-modal' event to close the modal
                // Livewire.on('close-modal', () => {
                //     alert('777777777');
                //     //  $('#staticBackdrop').modal('hide'); // This will close the modal using Bootstrap's JS
                // });
                // // Optional: Show success/error messages
                // Livewire.on('form-submitted', (data) => {
                //     //alert(data.message); // Show a success message, or use your preferred method
                // });
            });
        </script>

        
        <style>
            .modal-body {
                display: flex;
                padding: 0;
                border-radius: 4rem;

            }

            .modal-content {
                border-radius: 4rem;
                width: 150%;
                -webkit-box-shadow: -1px -2px 42px -19px rgba(0, 0, 0, 0.74);
                -moz-box-shadow: -1px -2px 42px -19px rgba(0, 0, 0, 0.74);
                box-shadow: -1px -2px 42px -19px rgba(0, 0, 0, 0.74);
            }

            .modal-content h1,
            .modal-content h2,
            .modal-content h3 {
                text-align: center;
            }

            .modal-content h1 {

                text-transform: uppercase;
            }



            .column {
                flex: 50%;
                padding: 10px;
            }

            .column#main {
                flex: 75%;
                padding: 50px;
                margin-top: 30px;
                margin-left: 15px;
            }

            #secondary {
                background-color: var(--color_sanjesh_blue);
                border-radius: 0 4rem 4rem 0;
                text-align: center;
            }

            #main .form-control {
                border-radius: 0;
                font-size: .9em;
            }




            .modal-body label {
                margin-bottom: 0;
            }

            .sec-content {
                margin-top: 85%;
            }
        </style>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>




    <?php
        $__assetKey = '4167934405-0';

        ob_start();
    ?>
    <style>
        select {
            /* // A reset of styles, including removing the default dropdown arrow */
            appearance: none;
            /* // Additional resets for further consistency */
            background-color: transparent;
            border: none;
            padding: 0 1em 0 0;
            margin: 0;
            width: 100%;
            font-family: inherit;
            font-size: inherit;
            color: #777;
            cursor: inherit;
            line-height: inherit;
        }
    </style>
    <style>
        .form-check {
            display: block;
            min-height: 1.5rem;
            padding-left: 1.5em;
            margin-bottom: 0.125rem;
        }

        .form-check .form-check-input {
            float: left;
            margin-left: -1.5em;
        }

        .form-check-reverse {
            padding-right: 1.5em;
            padding-left: 0;
            text-align: right;
        }

        .form-check-reverse .form-check-input {
            float: right;
            margin-right: -1.5em;
            margin-left: 0;
        }

        .form-check-input {
            --bs-form-check-bg: var(--bs-body-bg);
            flex-shrink: 0;
            width: 1em;
            height: 1em;
            margin-top: 0.25em;
            vertical-align: top;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: var(--bs-form-check-bg);
            background-image: var(--bs-form-check-bg-image);
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            border: var(--bs-border-width) solid var(--bs-border-color);
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
            print-color-adjust: exact;
        }

        .form-check-input[type=checkbox] {
            border-radius: 0.25em;
        }

        .form-check-input[type=radio] {
            border-radius: 50%;
        }

        .form-check-input:active {
            filter: brightness(90%);
        }

        .form-check-input:focus {
            /* border-color: #86b7fe; */
            border-color: #9afe86;
            outline: 0;
            /* box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25); */
            box-shadow: 0 0 0 0.25rem rgba(81, 253, 13, 0.25);
        }

        .form-check-input:checked {
            /* background-color: #0d6efd; */
            /* border-color: #0d6efd; */
            background-color: var(--color_sanjesh_green);
            border-color: var(--color_sanjesh_green);
        }

        .form-check-input:checked[type=checkbox] {
            --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='m6 10 3 3 6-6'/%3e%3c/svg%3e");
        }

        .form-check-input:checked[type=radio] {
            --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='2' fill='%23fff'/%3e%3c/svg%3e");
        }

        .form-check-input[type=checkbox]:indeterminate {
            /* background-color:  #0d6efd;   */
            background-color: var(--color_sanjesh_green);
            /* border-color: #0d6efd; */
            border-color: var(--color_sanjesh_green);
            --bs-form-check-bg-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/%3e%3c/svg%3e");
        }

        .form-check-input:disabled {
            pointer-events: none;
            filter: none;
            opacity: 0.5;
        }

        .form-check-input[disabled]~.form-check-label,
        .form-check-input:disabled~.form-check-label {
            cursor: default;
            opacity: 0.5;
        }

        .form-switch {
            /* padding-left: 2.5em; */
        }

        .form-switch .form-check-input {
            --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%280, 0, 0, 0.25%29'/%3e%3c/svg%3e");
            width: 2em;
            margin-left: -2.5em;
            background-image: var(--bs-form-switch-bg);
            /* background-image:  var(--color_sanjesh_green);   */
            background-position: left center;
            border-radius: 2em;
            transition: background-position 0.15s ease-in-out;
        }

        @media (prefers-reduced-motion: reduce) {
            .form-switch .form-check-input {
                transition: none;
            }
        }

        .form-switch .form-check-input:focus {
            --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%2386b7fe'/%3e%3c/svg%3e");
            --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%234daf5050'/%3e%3c/svg%3e");

        }

        .form-switch .form-check-input:checked {
            background-position: right center;
            --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23fff'/%3e%3c/svg%3e");
        }

        .form-switch.form-check-reverse {
            padding-right: 2.5em;
            padding-left: 0;
        }

        .form-switch.form-check-reverse .form-check-input {
            margin-right: -2.5em;
            margin-left: 0;
        }

        .form-check-inline {
            display: inline-block;
            margin-right: 1rem;
        }

        .btn-check {
            position: absolute;
            clip: rect(0, 0, 0, 0);
            pointer-events: none;
        }

        .btn-check[disabled]+.btn,
        .btn-check:disabled+.btn {
            pointer-events: none;
            filter: none;
            opacity: 0.65;
        }

        [data-bs-theme=dark] .form-switch .form-check-input:not(:checked):not(:focus) {
            --bs-form-switch-bg: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='rgba%28255, 255, 255, 0.25%29'/%3e%3c/svg%3e");
        }
    </style>
    <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;

            // Check if we're in a Livewire component or not and store the asset accordingly...
            if (isset($this)) {
                \Livewire\store($this)->push('assets', $__output, $__assetKey);
            } else {
                \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$nonLivewireAssets[$__assetKey] = $__output;
            }
        }
    ?>

    <?php
        $__scriptKey = '4167934405-1';
        ob_start();
    ?>
    <script>
        $(document).ready(function() {
            // alert("ready!");
            console.log('202', $('#province').find('option:selected').val());
            $('#province').on('change', function() {
                alert("Change event triggered!");
            });

        });
    </script>


    <script type="text/javascript">
        console.log('This Javascript will get executed every time this component is loaded onto the page...');
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

    <?php
        $__scriptKey = '4167934405-2';
        ob_start();
    ?>
    <script type="text/javascript">
        function shake(divo) {
            var div = document.getElementById(divo);
            var interval = 100;
            var distance = 10;
            var times = 4;

            $(div).css('position', 'relative');

            for (var iter = 0; iter < (times + 1); iter++) {
                $(div).animate({
                    left: ((iter % 2 == 0 ? distance : distance * -1))
                }, interval);
            }
            $(div).animate({
                left: 0
            }, interval);
        }
        document.addEventListener('alpine:initialized', () => {
            console.log('--------alpine:initialized--------');
            console.log(Livewire);
            console.log($);
            console.log($.ui);
            Alpine.data('counter', () => {
                return {
                    count: 0,
                    increment() {
                        this.count++;

                        function shake2(divo) {
                            var div = document.getElementById(divo);
                            var interval = 100;
                            var distance = 10;
                            var times = 4;

                            $(div).css('position', 'relative');

                            for (var iter = 0; iter < (times + 1); iter++) {
                                $(div).animate({
                                    left: ((iter % 2 == 0 ? distance : distance * -1))
                                }, interval);
                            }
                            $(div).animate({
                                left: 0
                            }, interval);
                        }
                        /*   //   $(document).find('#modal-dialogX').css("background-color", "red"); */
                        $('#modal-dialogX').css("background-color", "red");
                        $('#modal-dialogX').addClass('col-12');
                        // $('#figo').effect("shake");
                        try {
                            shake2('#figo');
                        } catch (e) {
                            console.log('e:', e);
                        }


                        //  $("div.step").effect('slide', {direction: 'right', mode: 'hide'}, 500);
                        // $('#menu_bottom_container').effect("shake");
                        //    $(document).find('#modal-dialogX').effect("shake");
                        //   $("#modal-dialogX").effect("shake");
                    },
                }
            });
        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

    <?php
        $__scriptKey = '4167934405-3';
        ob_start();
    ?>
    <script type="text/javascript">
        setInterval(() => {
            /*  // $wire.$refresh();
             // console.log($("#modal-dialogX"),$("#modal-dialogX").effect("shake"));
             // $("#modal-dialogX").effect("shake"); */
        }, 500);
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
    <?php
        $__scriptKey = '4167934405-4';
        ob_start();
    ?>
    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", () => {
            Livewire.hook('element.updated', (el, component) => {
                $('#modal-dialogX').effect("shake");
                $('#menu_bottom_container').effect("shake");
            })
        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
    <?php
        $__scriptKey = '4167934405-5';
        ob_start();
    ?>
    <script type="text/javascript">
        window.addEventListener('jquery', event => {
            $('#modal-dialogX').css("background-color", "red");
            $('#modal-dialogX').effect("shake");
            $('#menu_bottom_container').effect("shake");
        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/auth/sign.blade.php ENDPATH**/ ?>