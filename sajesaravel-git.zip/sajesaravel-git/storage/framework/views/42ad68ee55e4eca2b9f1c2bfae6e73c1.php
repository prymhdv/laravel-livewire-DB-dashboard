<title>Home2</title>

<?php $__env->startSection('content'); ?>
    <div id="loader"></div>
    <div style="display:none;" id="myDiv">
        <div class="flex justify-center">
            <div class="w-8/12 bg-white p-6 rounded-sm">
                <?php if(session()->has('logged-in')): ?>
                    <div class="bg-green-500 p-1 rounded-sm mb-6 text-white text-center">
                        <?php echo e(session('logged-in')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('registered')): ?>
                    <div class="bg-green-500 p-1 rounded-sm mb-6 text-white text-center">
                        <?php echo e(session('registered')); ?>

                    </div>
                <?php endif; ?>
                <h1 class="font-bold">خوش آمدید<span
                        class="text-blue-700"><?php echo e(Auth::check() ? ' ' . Auth::user()->name : ' there!'); ?></span></h1>
                <p class="mt-2">How are you today..? I have an quote for you, hope you will like it &#128512;</p>
                <p class="mt-2 mb-2 text-rose-500">Quote:</p>
                
                
                <?php if($quote): ?>
                    <p>"<?php echo e($quote->body); ?>" - <span style="font-style: italic"><?php echo e($quote->author); ?></span></p>
                <?php else: ?>
                    <p>There are no quotes at the moment..</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="flex justify-center mt-5">
            
            
            <?php echo $__env->make('blog.showContentBlog', ['isAdmin' => 'true'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    /* Preloader */

    #loader {
        position: absolute;
        left: 50%;
        top: 50%;
        z-index: 1;
        width: 40px;
        height: 40px;
        margin: -76px 0 0 -76px;
        border: 7px solid #f3f3f3;
        border-radius: 50%;
        border-top: 7px solid #3498db;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
    }

    @-webkit-keyframes spin {
        0% {
            -webkit-transform: rotate(0deg);
        }

        100% {
            -webkit-transform: rotate(360deg);
        }
    }

    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }

    /* Add animation to "page content" */
    .animate-bottom {
        position: relative;
        -webkit-animation-name: animatebottom;
        -webkit-animation-duration: 1s;
        animation-name: animatebottom;
        animation-duration: 1s
    }

    @-webkit-keyframes animatebottom {
        from {
            bottom: -100px;
            opacity: 0
        }

        to {
            bottom: 0px;
            opacity: 1
        }
    }

    @keyframes animatebottom {
        from {
            bottom: -100px;
            opacity: 0
        }

        to {
            bottom: 0;
            opacity: 1
        }
    }

    #myDiv {
        display: none;
    }

    /* Other */

    .text-hover:hover {
        color: #6366F1;
        transition: 0.2s;
    }

    /* Three latest blog posts */

    @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap");

    *,
    *::before,
    *::after {
        box-sizing: border-box;
        padding: 0;
        margin: 0;
    }

    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        max-width: 1200px;
        margin-block: 2rem;
        gap: 2rem;
    }

    img {
        max-width: 100%;
        display: block;
        object-fit: cover;
    }

    .card {
        display: flex;
        flex-direction: column;
        width: clamp(20rem, calc(20rem + 2vw), 22rem);
        overflow: hidden;
        box-shadow: 0 .1rem 1rem rgba(0, 0, 0, 0.1);
        border-radius: 1em;
        background: #ECE9E6;
        background: linear-gradient(to right, #FFFFFF, #ECE9E6);
    }


    .card__body {
        padding: 1rem;
        display: flex;
        flex-direction: column;
        gap: .5rem;
    }


    .tag {
        align-self: flex-start;
        padding: .25em .75em;
        border-radius: 1em;
        font-size: .75rem;
    }

    .tag+.tag {
        margin-left: .5em;
    }

    .tag-blue {
        background: #56CCF2;
        background: linear-gradient(to bottom, #2F80ED, #56CCF2);
        color: #fafafa;
    }

    .tag-brown {
        background: #D1913C;
        background: linear-gradient(to bottom, #FFD194, #D1913C);
        color: #fafafa;
    }

    .tag-red {
        background: #cb2d3e;
        background: linear-gradient(to bottom, #ef473a, #cb2d3e);
        color: #fafafa;
    }

    .card__body h4 {
        font-size: 1.5rem;
        text-transform: capitalize;
    }

    .card__footer {
        display: flex;
        padding: 1rem;
        margin-top: auto;
    }

    .user {
        display: flex;
        gap: .5rem;
    }

    .user__image {
        border-radius: 50%;
    }

    .user__info>small {
        color: #666;
    }
</style>

<?php echo $__env->make('blog.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/blog/home.blade.php ENDPATH**/ ?>