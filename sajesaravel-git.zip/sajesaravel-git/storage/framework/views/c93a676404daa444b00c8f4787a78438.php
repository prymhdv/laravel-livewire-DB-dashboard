<div class="modal-header justify-content-between p-1 shadow1 mb-1 "
style=" z-index:120!important; background-color: #ffffff;
 border: 1px solid #aaa;
 border-radius:4px;">
<div class=" d-flex justify-content-around align-content-center" style="flex: 100%;">
    <button type="button" class=" close" id='closeModal';
        style="border:0px solid#eee; background-color:#fff; color:red;" 
           
         wire:click="$dispatch('switchModal')">
        <span aria-hidden="true" style=" font-size: 1.7rem!important;">&times;</span>
    </button>

    <span class="  " style="text-align: center;">
        <img loading="lazy" class=""
            style=" 
            filter: invert(0.8) sepia(10) saturate(100) hue-rotate(234deg);"
            src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>" class=""
            sizes="max-height:40px;" width="80%" alt="logo"></a>
    </span>
    
    <button type="button" class=" " id='resetModal' wire:click="$refresh"
        style=" float: right;
            font-size: 1.5rem!important;
            font-weight: 700;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            opacity: .5;
            padding: 0;
            background-color: transparent;
            border: 0;
            -webkit-appearance: none;
            cursor: pointer;
            ">
        <i class="fa fa-refresh" style=" font-size: 1.2rem!important;"></i>
    </button>

    
    
    
    
    
    
    
    
    <style>
        /* Add initial transition and rotation styles */
        .fa-refresh {
            transition: transform 0.3s ease-in-out;
        }

        /* Hover effect to rotate the icon */
        .fa-refresh:hover {
            transform: rotate(360deg);
            cursor: pointer;
            color: darkblue;
            transition: transform 2.3s ease-in-out;
        }
    </style>
</div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/auth/sign-modal-header.blade.php ENDPATH**/ ?>