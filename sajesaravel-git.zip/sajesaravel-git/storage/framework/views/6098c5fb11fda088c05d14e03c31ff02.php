<div class="col-md-12 boxShadow1"
    style=" border-radius: 7px; 
                 /*background: linear-gradient(90deg, #0c1a29af 0, #2b3163cb 50%, #24243eb9 100%);*/
                 background: linear-gradient(270deg, #f7010158 0, #f7017cc6 78%, #f7010179 100%);
                ">
    <p class="text-light text-center fs-5 p-2 pt-4 mt-2 mb-3"
        style="font-family: Lalezar, sans-serif;word-spacing: initial;">امتحانات نهایی خرداد 1404 و
        آزمون تخصصی فرهنگیان</p>
        <?php echo $__env->make('pages.student.farhangian.homelock', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="row justify-content-center align-content-center shadow1X text-center p-2 p-lg-5" style=" ">

        <div id="countdown_farhangian" wire:ignore class=" d-none
            text-bold fs-4 text-center f-700 "
            style=" word-spacing: normal!important;">
        </div>
        <div class=" col-12    m-0"
            style="  border-radius: 7px; border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;
             background: linear-gradient(270deg, #90010132 0, #98014d7e 78%, #9801013b 100%);
             border:1px solid #ac677491;border-bottom:0px solid #ac677491;
             ">
            <a <?php if(auth()->guard()->check()): ?> <?php switch(Auth::user()->role): 
        case ('admins'): ?>
                href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
            <?php break; ?>

            <?php case ('operators'): ?>
                    href="<?php echo e(route('home.index.Route')); ?>" 
            <?php break; ?>

            <?php case ('teachers'): ?>
                href="<?php echo e(route('home.index.Route')); ?>" 
            <?php break; ?>

            <?php case ('customers'): ?>
                    href="<?php echo e(route('home.index.Route')); ?>" 
            <?php break; ?>

            <?php case ('counselors'): ?>
                    href="<?php echo e(route('home.index.Route')); ?>" 
            <?php break; ?>

            <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
            <?php break; ?>
            <?php default: ?>
        <?php endswitch; ?> <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('farhangian.index.Route')); ?>" <?php endif; ?> role="button" class=" m-0 pos-relative "
                style="border-radius: 7px;border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;
        <?php if(Auth::check() && Str::contains(Auth::user()->access??'', 'admin')): ?> text-align: start!important; <?php endif; ?>">
                <div class="row justify-content-center align-content-center">
                    <div class="col-12 p-0 text-center my-3">
                        <i class=" fas fa-book-reader fa-2x mx-2  text-light "></i>
                        <span class=" fs-4 text-light" style="vertical-align: super;">
                            سوالات شبیه‌ساز کنکور، امتحانات نهایی خرداد ۱۴۰۴ و آزمون تخصصی فرهنگیان
                        </span>
                    </div>
                    <div class="col-12">

                        <?php if(auth()->guard('adminII')->check()): ?>
                            sss
                        <?php endif; ?>
                        <?php if(Auth::check() && Str::contains(Auth::user()->access??'', 'admin')): ?>
                            <div class="row justify-content-between text-center ">

                                <span class=" col text-nowrap fs-3">
                                    شرکت کنندگان:
                                    <?php echo e(\App\Models\UserStudentFarhangian::where('Isfarhangian', 'true')->count()); ?>

                                </span>
                                <span class=" col fs-3">تجربی:
                                    <?php echo e(\App\Models\UserStudent::where('field', 'تجربی')->whereHas('farhangian', function ($query) {
                                            $query->where('Isfarhangian', 'true');
                                        })->count()); ?>

                                </span>
                                <span class=" col fs-3">ریاضی:
                                    <?php echo e(\App\Models\UserStudent::where('field', 'ریاضی')->whereHas('farhangian', function ($query) {
                                            $query->where('Isfarhangian', 'true');
                                        })->count()); ?>

                                </span>
                                <span class=" col fs-3">انسانی:
                                    <?php echo e(\App\Models\UserStudent::where('field', 'انسانی')->whereHas('farhangian', function ($query) {
                                            $query->where('Isfarhangian', 'true');
                                        })->count()); ?>

                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>


            </a>
            
            <!-- onclick="Livewire.dispatchTo('auth.sign','switchModal')"  -->
        </div>
        <video preload="none" class="p-0" loop 
            poster="<?php echo e(asset('storage/main/student/konkur1404Farhangiyan/konkur1404Farhangiyan_intro_II.webp')); ?>"
            controls 
            style=" width:100%;height:100%;object-fit:cover; border:1px solid #ac677491; border-top:0px solid #ac677491;
            border-radius:7px; border-top-right-radius: 0px; border-top-left-radius: 0px;
            ">
            <source src="<?php echo e(asset('storage/main/student/konkur1404Farhangiyan/konkur1404Farhangiyan_intro_II.mp4')); ?>">
            Your browser does not support the video tag.
        </video>
        <div class=" row text-center justify-content-center mt-3" style="">
            <a class="col-10  text-decoration-none fs-4 text-center  text-center  "
                href="https://formafzar.com/form/smojr" target="_blank">
                <button class=" button-82-pushable text-center " role="button" >
                    <span class="button-82-shadow"></span>
                    <span class="button-82-edge"
                        style=" background: linear-gradient(to left,
                                                    #002a52 0%,
                                                    #0054a3 8%,
                                                    hsl(212, 100%, 32%) 92%,
                                                    hsl(202, 100%, 16%) 100%
                                                     );"></span>
                    <span class="button-82-front text fs-4 p-2 px-3"
                        style="background:#002a52; vertical-align: middle;">
                        <i class="fas fa-file-pdf   fa-2x px-3 " style=" vertical-align: middle;"></i>
                        دریافت سوالات شبیه‌ساز کنکور و فرهنگیان ۱۴۰۴
                    </span>
                </button>
            </a>
        </div>
    </div>
</div>
<script wire:ignore>
    if (document.getElementById("countdown")) {
        // Target date (17 Bahman 1402 = 2024-02-06 20:30:00)
        let targetDate = new Date("2025-02-06T20:30:00");

        // Function to update the countdown_Farhangiyan_live
        function updateCountdown() {
            let currentDate = new Date();
            let difference = targetDate - currentDate;

            if (difference > 0) {
                // Calculate days, hours, minutes, seconds
                let days = Math.floor(difference / (1000 * 60 * 60 * 24));
                let hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                let minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
                let seconds = Math.floor((difference % (1000 * 60)) / 1000);

                // Display the countdown_Farhangiyan_live
                daysR = `<span style="color: green;">${days}</span>,روز `;
                hoursR = `<span style="color: green;">${hours}</span>ساعت, `;
                minutesR = `<span style="color: green;">${minutes}</span>دقیقه, و `;
                secondsR = `<span style="color: green;">${seconds}</span> ثانیه, و `;
                if (0 == days) daysR = '';
                if (0 == hours) hoursR = '';
                if (0 == minutes) minutesR = '';
                if (0 == seconds) secondsR = '';
                if (document.getElementById("countdown_Farhangiyan_live"))
                    document.getElementById("countdown_Farhangiyan_live").innerHTML =
                    `${daysR}${hoursR}${minutesR}${secondsR} باقی‌مانده، زمان  سوالات شبیه ساز کنکور، امتحانات نهایی خرداد ۱۴۰۴ و آزمون تخصصی فرهنگیان  بنیاد سنجش`;


            } else {
                // If the target date has passed
                if (document.getElementById("countdown_Farhangiyan_live"))
                    document.getElementById("countdown_Farhangiyan_live").innerHTML = "";
            }
        }
        // Update the countdown_Farhangiyan_live every second
        setInterval(updateCountdown, 1000);
        // Initial call to display the countdown_Farhangiyan_live immediately when the page loads
        updateCountdown();
    }
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\konkur1404Farhangiyan.blade.php ENDPATH**/ ?>