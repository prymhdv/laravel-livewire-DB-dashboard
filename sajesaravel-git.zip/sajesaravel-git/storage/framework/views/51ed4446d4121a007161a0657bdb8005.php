<div class="  p-1  h-100">
    <?php if(!isset(Auth::user()->student->booster->Isbooster)): ?>
        <script>
            document.addEventListener('livewire:navigated', () => {
                Livewire.dispatchTo('sign-info-complete', 'switchModal1');
            });
        </script>
    <?php endif; ?>
    <div class="row align-content-center justify-content-center  h-100">
        <div class="col-12  p-1 align-content-center justify-content-center h-100 ">
            <div class=" p-1 shadow1 text-end h-100 boxShadow1_3d" style="background-color: #ddd0; border-radius:7px; ">
                <img <?php if(Auth::user()->personal && Auth::user()->personal->userPhotoPath): ?> src="<?php echo e(asset(Auth::user()->personal->userPhotoPath)); ?>"
                <?php else: ?>
                
                 src="<?php echo e(asset('storage/PrymhdvAssets/Logo/user.webp')); ?>" <?php endif; ?>
                    alt="" class=" text-start p-2"
                    style=" width:80px; scale:1.2; border-radius:50%; aspect-ratio: 1;">
                پرتال کاربری : مشاور
                <div class="col-12 position-relative" style="height: 20px;">

                    <div style=" left:0;" class=" position-absolute bottom-0  p-0 d-none">
                        <a class=" btn btn-outline-dark  "  
                            onclick="Livewire.dispatchTo('auth.sign-info-complete','switchModal')">تکمیل اطلاعات
                            شخصی</a>
                    </div>
                </div>
                <div class="p-1   " style="background-color: #ddd0; border-radius:7px; ">
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">نام:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->nameFirst); ?></div>
                    </div>
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">نام خانوادگی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->nameLast); ?></div>
                    </div>
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">کدملی/پرسنلی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->codeMeli ?? ''); ?></div>
                    </div>
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">موبایل:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->mobile); ?></div>
                    </div>
                    <hr class="m-0">
                    <div class="d-flex">
                        <div class="col text-end">مقطع تحصیلی:</div>
                        <div class="col text-end"><?php echo e(Auth::user()->employee->field); ?></div>
                    </div>
                    
                    <?php if(1 &&
                            Auth::user()->transaction()->exists() &&
                            Auth::user()->transaction()->where('category_sub', 'employeeCunsellor')->where('amount', '780000')->where('status', 'verify_success')->first()): ?>
                        <div class="row ">
                            <a class="menyj  p-2 m-1  align-content-center justify-content-center text-wrap text-center "
                                href="<?php echo e(asset('storage/main/employee/counsellor/certificated')); ?>/<?php echo e(Auth::user()->mobile); ?>.pdf"
                                target="_blank"
                                style="color:#fff; background-color: #161f42; border:1px solid #ccc; border-radius:12px;">
                                <i id="itemHeadXAIcone" class="InfoIcone35 fas fa-cloud-download-alt  "
                                    style=" color:#ff5100; "></i>
                                <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none  fs-3 "
                                    style=" vertical-align: middle; color:#00ff00;">
                                    دریافت گواهینامه دوره تربیت مشاور
                                </b>
                            </a>
                        </div>
                        
                    <?php endif; ?>
                    <div class="menyj  p-2 m-1  align-content-center justify-content-center text-wrap text-center "
                        style="color:#fff; background-color: #ffffff; border:1px solid #ccc; border-radius:12px;">

                        <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none  fs-3 "
                            style=" vertical-align: middle; color:#00005b;">
                            
                            <?php
                                //
                                // \App\Models\UserEmployeeCounsellor::find(21503)->delete();
                                // foreach(\App\Models\UserEmployeeCounsellor::where('employee_id',0)->get() as $item)
                                // {
                                //      $item->user->id
                                // }

                                /*
                                     -- Step 1: Update employee_id for rows where it's 0, using the value from the same user_id
                                    UPDATE che_users_employee_counsellor c
                                    JOIN (
                                        SELECT user_id, MAX(employee_id) AS non_zero_employee_id
                                        FROM che_users_employee_counsellor
                                        WHERE employee_id != 0
                                        GROUP BY user_id
                                    ) AS sub
                                    ON c.user_id = sub.user_id
                                    SET c.employee_id = sub.non_zero_employee_id
                                    WHERE c.employee_id = 0;

                                    -- Step 2: Delete rows where employee_id is still 0
                                    DELETE FROM che_users_employee_counsellor
                                    WHERE employee_id = 0;
                            */
                            ?>
                            نتایج آزمون :
                            
                            <?php if(isset(optional(Auth::user()->counsellor)->grade)): ?>
                                <?php if(Auth::user()->counsellor->grade >= 70): ?>
                                    <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none  fs-3 "
                                        style=" vertical-align: middle; color:#00ff00;">
                                        <?php echo e(Auth::user()->counsellor->grade); ?> قبول
                                    </b>
                                <?php else: ?>
                                    <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none  fs-3 "
                                        style=" vertical-align: middle; color:#ff3300;">
                                        <?php echo e(Auth::user()->counsellor->grade); ?> مردود
                                    </b>
                                <?php endif; ?>
                            <?php else: ?>
                                <b id="itemHeadXBInfo" class="Fefc3 p-2  user-select-none  fs-3 "
                                    style=" vertical-align: middle; color:#ffaa00;">
                                    ------
                                </b>

                            <?php endif; ?>
                        </b>
                    </div>
                    
                </div>
            </div>

        </div>

    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employee\userInfo.blade.php ENDPATH**/ ?>