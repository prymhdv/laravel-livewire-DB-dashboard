<?php if($paginator->hasPages()): ?>
    <div class="font-vazir">
        <nav>
            <ul class="pagination justify-content-center">
                
                <?php if($paginator->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <span class="page-link" aria-hidden="true">&lsaquo;</span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link   " href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"
                            aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;&lsaquo;</a>
                    </li>
                <?php endif; ?>





                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <?php if(is_array($element)): ?>
                        
                        
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li class="page-item active" aria-current="page"><span
                                        class="page-link"><?php echo e(App\Models\Fonter::arabic_w2eII($page)); ?></span></li>
                            <?php elseif($key == 1 && $page != 1): ?>
                                <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span>
                                </li>
                            <?php elseif($key == count($elements) - 2 && $page != $paginator->currentPage() && $page != $paginator->lastPage()): ?>
                                <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span>
                                </li>
                            <?php else: ?>
                                <?php if(
                                    $page == count($element) ||
                                        $page == 1 ||
                                        $page == $paginator->currentPage() + 1 ||
                                        $page == $paginator->currentPage() + 2 ||
                                        $page == $paginator->currentPage() - 1 ||
                                        $page == $paginator->currentPage() - 2): ?>
                                    <li class="page-item"><a class="page-link "
                                            href="<?php echo e($url); ?>"><?php echo e(App\Models\Fonter::arabic_w2eII($page)); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                
                <?php if($paginator->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link    " href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"
                            aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;&rsaquo;</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <span class="page-link" aria-hidden="true">&rsaquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php endif; ?>





<style>
    .page-link {
        position: relative;
        display: block;
        padding: .5rem .75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #007bff;
        color: var(--color_violate);
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: 10px;
        margin: 5px;
    }

    .page-link:hover {
        z-index: 2;
        color: #0056b3;
        color: var(--color_violate);
        text-decoration: none;
        background-color: #e9ecef;
        border-color: #dee2e6;
    }

    .page-link:focus {
        z-index: 3;
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(0, 123, 255, .25);
        color: var(--color_violate);
        box-shadow: 0 0 0 .2rem var(--color_violate);
        border-radius: 10px;
    }

    .page-item:first-child .page-link {
        margin-left: 0;
        border-top-left-radius: .25rem;
        border-bottom-left-radius: .25rem
    }

    .page-item:last-child .page-link {
        border-top-right-radius: .25rem;
        border-bottom-right-radius: .25rem
    }

    .page-item.active .page-link {
        z-index: 3;
        color: #fff;
        background-color: #007bff;
        background-color: var(--color_violate);
        border-color: #007bff;
        border-color: var(--color_violate);
        border-radius: 10px;
    }

    .page-item.disabled .page-link {
        color: #6c757d;
        pointer-events: none;
        cursor: auto;
        background-color: #fff;
        border-color: #dee2e6
    }

    .pagination-lg .page-link {
        padding: .75rem 1.5rem;
        font-size: 1.25rem;
        line-height: 1.5
    }

    .pagination-lg .page-item:first-child .page-link {
        border-top-left-radius: .3rem;
        border-bottom-left-radius: .3rem
    }

    .pagination-lg .page-item:last-child .page-link {
        border-top-right-radius: .3rem;
        border-bottom-right-radius: .3rem
    }

    .pagination-sm .page-link {
        padding: .25rem .5rem;
        font-size: .875rem;
        line-height: 1.5
    }

    .pagination-sm .page-item:first-child .page-link {
        border-top-left-radius: .2rem;
        border-bottom-left-radius: .2rem
    }

    .pagination-sm .page-item:last-child .page-link {
        border-top-right-radius: .2rem;
        border-bottom-right-radius: .2rem
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\vendor\pagination\bootstrap-4.blade.php ENDPATH**/ ?>