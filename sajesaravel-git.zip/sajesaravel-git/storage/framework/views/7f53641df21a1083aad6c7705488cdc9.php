


<?php if(Str::contains($this?->pageState??'', 'admin.student.fieldSelection.student') ||
        request()->route()->getName() == 'main.student.fieldSelection.student.adminPanelLivewireRoute' ||
        Str::contains(request()->route()->getName(), 'student.fieldSelection.student.adminPanelLivewireRoute')): ?>
    <?php
        // var_dump($this?->pageState??'');
        if (!Str::contains($this?->pageState??'', 'admin.student.fieldSelection.student')) {
            $this->pageState = 'admin.student.fieldSelection.student.main';
            // dd($this?->pageState??'');
        } //dd($this?->pageState??'');
    ?>
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
                // dd(route('manage.main.student.fieldSelection.student.adminPanelLivewireRoute', ['id' => 'all', 'state' => 'all']));
                // http://localhost/dashboard/admin/student/fieldSelection/student/manage/0/0"
            ?>
            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-4">
                <a class="hover4 d-block justify-items-center align-content-center  " style=" " wire:navigate
                    href="<?php echo e(route('manage.main.student.fieldSelection.student.adminPanelLivewireRoute', ['id' => 'all', 'state' => 'all'])); ?>">
                    لیست دانش‌آموز
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    برسی وضعیت
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    چاپ گواهی
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>

            </div>
            <hr class="m-0">
        </div>
        <?php if(request()->route()->getName() == 'main.student.fieldSelection.student.adminPanelLivewireRoute'): ?>
            <div class="col-md-8 mt-2 p-2" style="background-color: #ffffff; border-radius:8px;">
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان</div>
                    <div class="col-md-6">
                        <span style="color:rgb(0, 0, 0);"><?php echo e(App\Models\UserStudentFieldSelection::count()); ?></span>
                        /
                        <span
                            class=""style="color:#04ff04;"><?php echo e(App\Models\UserStudentFieldSelection::where('status', 'active')->count()); ?></span>
                    </div>
                </div>
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان تخصیص گرفته</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>
                <hr class="m-0">
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>
                <hr class="m-0">
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان تخصیص داده شده</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\student\fieldSelection\student\main.blade.php ENDPATH**/ ?>