

<a id="takhminRotbeClick" class=" d-flex px-2 rotate-button2 shadow1 align-content-center  justify-content-center"
    
     
     
     href="https://formafzar.com/form/allqk"
     target="_blank"
    style="color:white;cruser:pointer;font-weight:600;border-radius:12px;"><img
        src="<?php echo e(asset('storage/main/home/services/Icon-03.webp')); ?>" class=" p-1 px-2 " loading="lazy"
        style="width: 50px; ">
    <span class="align-content-center text-wrap text-center fs-4">
        
        سامانه جامع تخمین رتبه و اعلام رشته محل های قبولی
    </span>
</a>
<style>
    #takhminRotbeClick {
        transform: scale(1);
        transition: all 0.3s ease-in-out 0s;
        cursor: pointer;

        background-color: #3a0180 !important;
        border: 2px solid #3a0180 !important;
        ;
    }

    #takhminRotbeClick:hover {
        transform: scale(1);
        background-color: #6f04f3 !important;
        border: 2px solid #6c00f0 !important;
        ;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/student/takhminRotbe/regBtn.blade.php ENDPATH**/ ?>