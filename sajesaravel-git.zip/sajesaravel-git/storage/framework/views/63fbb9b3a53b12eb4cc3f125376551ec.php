<link rel="preconnect" href="//fdn.fontcdn.ir">
<link rel="preconnect" href="//v1.fontapi.ir">
<link href="https://v1.fontapi.ir/css/Lalezar" rel="stylesheet">
<style>
    a:hover {
        cursor: pointer;
    }

    @font-face {
        font-family: "Lalezar";
        src: url("https://cdn.fontcdn.ir/Fonts/Lalezar/148c72044161f7fdd874a7743f5402f15b04bc2b9a609d2734deb22057bef2d5.woff2") format("woff2");
        font-weight: 400;
        font-style: normal;
    }

    .font_lalezar {
        font-family: "Lalezar";
        letter-spacing: 1px;;
        
    }
    .carousel-control-prev-icon,.carousel-control-next-icon{
        width: 3rem;
        height: 3rem;
        background-size: 60% 60%;
        border-radius: 50%; 
        background-color:#2e2e2edd;
        color:#fff;
    }
    .carousel-control-next, .carousel-control-prev {
        width: 7%;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/headStyle.blade.php ENDPATH**/ ?>