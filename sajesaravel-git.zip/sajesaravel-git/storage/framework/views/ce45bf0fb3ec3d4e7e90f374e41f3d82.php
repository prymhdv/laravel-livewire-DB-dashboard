 <?php echo $__env->make('pages.prymhdv.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

 
 
 <nav class="navbar navbar-expand-xl  navbar-dark bg-dark py-1 d-none"
     style="background:#121944!important; direction:rtl;">
     <div class="container ">
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03"
             aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
         </button>
         <a class="navbar-brand p-0" href="<?php echo e(route('home.index.Route')); ?>">
             <img loading="lazy"src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>" width="100px" alt="logo">
         </a>
         
         <div class=" navbar-collapse" id="navbarTogglerDemo03" style="direction:rtl;">
             <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                 <div class="col-auto ms-2 justify-content-end d-block d-lg-none">
                     <?php echo $__env->make('pages.prymhdv.partials.popAdmin', ['idpop' => '1'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                 </div>
             </ul>
         </div>
         <div class="col-auto ms-2 justify-content-end d-none d-lg-block">
             <?php echo $__env->make('pages.prymhdv.partials.popAdmin', ['idpop' => '1'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         </div>
     </div>
 </nav>

 <style>
     ..exiting,
     .dashboarding,
     .alerting {
         transition: all 300ms ease-in-out 0s;
     }

     .exiting:hover i.a {
         color: red !important;

     }

     .dashboarding:hover i {
         color: red !important;

     }

     .alerting:hover i {
         color: red !important;

     }

     .exiting:hover {
         color: red !important;

     }

     .dashboarding:hover {
         color: red !important;

     }

     .alerting:hover {
         color: red !important;

     }
 </style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/header.blade.php ENDPATH**/ ?>