 
<?php $__env->startSection('pageTitle', 'صفحه ورود ، ثبت نام'); ?>
<?php $__env->startSection('content'); ?>
    <main class="   " style="min-height: 0vmi;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    sd
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\auth\newSign.blade.php ENDPATH**/ ?>