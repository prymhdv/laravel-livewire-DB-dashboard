
<!-- footer C4 T5-->
<footer class="footer-area black-bg container-fluid container-md">
    <div class="footer-top-wrap pt-95 pb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="footer-widget mb-50">
                        <div class="fw-logo mb-15">
                            <a href="index.html"><img
                                    loading="lazy"src="<?php echo e(asset('main/logo/bonyadlogo.svg')); ?>" alt="Logo"
                                    width="70%"></a>
                        </div>
                        <div class="footer-text" style="text-align:justify">
                            <p>بزرگترين موسسهٔ آموزشی کشور؛ پیشرو در ارایهٔ آموزش‌های حضوری و آنلاین، جلسات مشاوره و
                                برنامه‌ریزی، با ۱۰ سال سابقهٔ فعالیت آموزشی و کسب رتبه‌های برتر و تک‌رقمی در سال‌های
                                اخیر.</p>
                        </div>

                        <div class="footer-text" style="text-align:justify">
                            <a referrerpolicy='origin' target='_blank'
                                href='https://trustseal.enamad.ir/?id=427802&Code=vfqoIubfepbcmwY9Iu8ddrLoddILFS6s'><img
                                    referrerpolicy='origin'
                                    src='https://trustseal.enamad.ir/logo.aspx?id=427802&Code=vfqoIubfepbcmwY9Iu8ddrLoddILFS6s'
                                    alt='' style='cursor:pointer' code='vfqoIubfepbcmwY9Iu8ddrLoddILFS6s'></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 ">
                    <div class="footer-widget mb-50">
                        <div class="fw-title mb-20">
                            <h4>لینک های مفید</h4>
                        </div>
                        <div class="fw-link">
                            <ul>
                                <li><a href="/app/index">
                                        <i class="fas fa-angle-left"></i>
                                        خانه</a>
                                </li>
                                <li><a href="<?php echo e(route('confrence.index.Route')); ?>">
                                        <i class="fas fa-angle-left"></i>
                                        همایش
                                    </a>
                                </li>
                                <li>
                                    <a href="https://lms.sanjeshbonyad.org">
                                        <i class="fas fa-angle-left"></i>پرتال دانش آموزی
                                    </a>
                                </li>

                                <li class="d-none">
                                    <a href="/login">
                                        <i class="fas fa-angle-left"></i>
                                        پرسنل
                                    </a>
                                </li>
                                <li><a href="https://panel.sanjeshbonyad.org/login">
                                        <i class="fas fa-angle-left"></i>
                                        پرسنل
                                    </a>
                                </li>
                                <li class="d-none">
                                    <a href="/app/auth/login"><i class="fas fa-angle-left"></i>
                                        IIپرسنل
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-12 ">
                    <div class="footer-widget mb-50">
                        <div class="fw-title mb-20">
                            <h4>تماس با ما</h4>
                        </div>
                        <div class="fw-contact  " style="direction: none;">
                            <ul>
                                <!-- <li><i class="fas fa-phone"></i><span style="text-align: left; float:left; direction:ltr">(021) 91006668</span></li> -->
                                <li>
                                    <i class="fas fa-phone"></i>
                                    
                                    <span>(021) 91006668 </span>
                                </li>
                                <li>
                                    <i class="far fa-envelope"></i>
                                    <span style="   ">info@sanjeshbonyad.org</span>
                                </li>
                                <li class="d-none">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span style="   ">دفتر: تبریز، فلکه دانشگاه، خیابان
                                        دانشگاه، کوی خرداد، پلاک 19
                                    </span>
                                </li>
                                <li class="">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span style="   ">
                                        دفتر: تبریز، خیابان دانشگاه، کوی گلباد، پلاک 43
                                    </span>
                                </li>
                                <li class="d-flex">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span style="">ساختمان آموزشی: بالاتر از چهارراه
                                        رضانژاد، نرسیده به آبرسان، پشت ایستگاه تپلی باغ
                                    </span>
                                </li>
                                <!-- <li><i class="fas fa-fax"></i><span style="text-align: left !important; float:left; direction:ltr">041 - 91001191</span></li> -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright-wrap">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="copyright-text">
                        <p>&copy; تمامی حقوق مادی و معنوی این تارنما، برای <span style="font-weight: bold">موسسه بنیاد
                                سنجش</span> محفوظ است.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="copyright-social text-center text-md-left">
                        <ul>
                            <!-- <li><a href="#"><i class="fab fa-facebook-f"></i></a></li> -->
                            <li>
                                <a href="https://t.me/bonyadsanjesh" target="_blank">
                                    <i class="fab fa-telegram"></i>+
                                </a>
                            </li>
                            <li>
                                <a href="https://instagram.com/sanjesh.b_org" target="_blank">
                                    <i class="fab fa-instagram"></i>
                                </a>
                            </li>
                            <li>
                                <a id="whatsapp" target="_blank">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                            </li>
                            <!-- <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li> -->
                            <!-- <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12" style="height: 50px;"></div>
</footer>
<script>
    var size = screen.width;
    if (size > 770) {
        var link = 'https://web.whatsapp.com/send?phone=989129730474';
    } else {
        var link = 'https://api.whatsapp.com/send?phone=989129730474';
    }
    var a = document.getElementById("whatsapp");
    a.setAttribute('href', link);
</script>
<script>
    // var size = screen.width;
    // $.ajax({
    //     method: 'post',
    //     url: '/include/nheader.php',
    //     data: {
    //         size: size
    //     },
    //     success: function(msg) {
    //         $('#header').html(msg);
    //     }
    // })
</script>
<!-- footer-end -->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partialsIII\footer.blade.php ENDPATH**/ ?>