 <div class=" d-flex flex-row  form-check form-switch  my-3  justify-content-around">
     <label class=" form-check-label " for="hasCareer">آیا سابقه کار در زمینه آموزشی را دارید؟</label>
     <input class=" form-check-input p-2 form-control " type="checkbox" id="hasCareer" name="hasCareer"required
         wire:model="hasCareer"style="border:2px solid #777; border-radius:7px;">
     
 </div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\employeeCounsellor.blade.php ENDPATH**/ ?>