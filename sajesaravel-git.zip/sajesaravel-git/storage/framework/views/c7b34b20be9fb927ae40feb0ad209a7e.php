






<?php $__env->startSection('pageTitle', 'صفحه نخست|ورود وبلاگ'); ?>
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-5">
                <d-flex>
                    <div class="card mb-4 p-4">
                        <div class="card-body text-center">
                            <h2 class="card-title">ورود به مدیریت وبلاگ</h2>
                            <form method="POST" action="<?php echo e(route('accessIn.weblog.dashboard.Route')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="mobile">شماره موبایل</label>
                                    <input type="text" class="form-control" id="mobile" name="mobile"
                                        placeholder="شماره موبایل خود را وارد کنید" required>
                                </div>
                                <div class="form-group">
                                    <label for="pass">رمز</label>
                                    <input type="pass" class="form-control" id="pass" name="pass"
                                        placeholder="رمز خود را وارد کنید" required>
                                </div> 
                                <button type="submit" class="btn btn-danger m-2">ارسال</button>
                            </form>
                        </div>
                    </div>
                </d-flex>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('headerSub'); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/dashboard/weblog.blade.php ENDPATH**/ ?>