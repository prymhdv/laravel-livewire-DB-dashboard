<nav class=" navbar navbar-expand-xl navbar-dark bg-dark   border-body shadow1 font-iransans shadow1 position-relative"
    style="
     direction: rtl;
      height: var(--height-nav);
      left:0px;
      top:0px;
       position: fixed !important;
       z-index:1010;
       width:100%;
        background:linear-gradient(90deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
        /* padding-top:5px; */
        /* padding-bottom:0px; */
        border-bottom-right-radius:7px;
        border-bottom-left-radius:7px;
        border-bottom: 3px double #6e6e6f;
            justify-self: anchor-center;
       ">

    <div id="mobileDiv" class="container-fluid d-block d-xl-none " style="">
       
    </div>

</nav>


<style>
    @media (max-width: 400px) {
        #Header_logo {
            min-width: 20.0vmin !important;
            max-width: 20.0vmin !important;
            width: 20.0vmin !important;
            /* max-width: 0.1vw!important; */
        }

        #Location_logo {
            min-width: 5.0vmin !important;
            max-width: 5.0vmin !important;
            width: 5.0vmin !important;
            /* max-width: calc(var(--height-nav) * 0.1vw)!important; */
        }
    }
</style>


<li
class="  nav-item ms-3  ms-3justify-content-center align-content-center  dropdown  d-none">
<a href="#"
    class="dropdown-toggle headbtn  p-2 ms-3justify-content-center align-content-center "
    id="navbarDropdown" role="button" data-bs-toggle="dropdown"
    aria-expanded="false" style="visibility: show;">
    <div class="d-flex flex-column justify-content-center align-content-center">
        
        <i class="fas fa-align-justify fa-1x   "></i>
        <span class="fs-3">سایر</span>
    </div>
</a>
</li>
<ul class="dropdown-menu shadow1 d-none" aria-labelledby="navbarDropdown" style="">
<li class="dropdown-item my-1 w-100 justify-content-center m-auto "
    style="min-width: 100%!important;">
    <a wire:navigate data-path="show.blog.Route"
        class="load_content_ajax  headbtn  p-2 m-1      text-decoration-none  
                                justify-content-center   text-center  float-start"
         style="">
        <i class=" fa-solid  fa-blog  mx-1  iconeHead  "
            style="visibility: show;"></i>
        <span class="fs-3">وبلاگ</span>
    </a>
</li>

<li class="dropdown-item">
    <div class="row justify-content-center ">
        <a wire:ignore class="     font-iransans fontR4    m-1 mb-0 "
             >
            <img src="<?php echo e(asset('/storage/assets/PrymhdvMedya/bazaar-downloadI.png')); ?>"
                alt="direct-download-from-cafebazaar" class="gth53 p-0 "
                style="width:100%;   
                                        aspect-ratio: 2/1.0;
                                        max-width:100%;
                                        border:3px solid #007bff00;
                                        border-radius:5px;">
            
        </a>
        <a wire:navigate class=" align-middle    font-iransans fontR4   m-1 mb-0   "
            href="#">

            
            <img src="<?php echo e(asset('storage/assets/PrymhdvMedya/anarduni-download.png ')); ?>"
                alt="direct-download-from-cafebazaar" class="gth53 p-0 "
                style="width:100%;   
                            aspect-ratio: 2/1.0;
                            max-width:100%;
                            border:3px solid #007bff00;
                            border-radius:5px;">
        </a>

    </div>
</li>
<li class="  nav-item ms-3 "> <a wire:navigate data-path="about.Route"
         
        class="load_content_ajax  headbtn  p-2 m-1     text-decoration-none   "
        >
        درباره ما
    </a>
</li>
</ul>



<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\navII.blade.php ENDPATH**/ ?>