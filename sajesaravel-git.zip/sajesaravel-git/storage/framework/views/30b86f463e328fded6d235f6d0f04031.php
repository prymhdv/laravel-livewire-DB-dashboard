<div class="row justify-content-center align-content-center shadow1X text-center"
style="background-color: #eee; border-radius:7px; border:0px solid #aaa;">


<span class="w-100">
    <a 
        <?php if(auth()->guard()->check()): ?> <?php switch(Auth::user()->role): 
        case ('admins'): ?>
            href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
        <?php break; ?>

        <?php case ('operators'): ?>
                href="<?php echo e(route('home.index.Route')); ?>" 
        <?php break; ?>

        <?php case ('teachers'): ?>
            href="<?php echo e(route('home.index.Route')); ?>" 
        <?php break; ?>

        <?php case ('customers'): ?>
                href="<?php echo e(route('home.index.Route')); ?>" 
        <?php break; ?>

        <?php case ('counselors'): ?>
                href="<?php echo e(route('home.index.Route')); ?>" 
        <?php break; ?>

        <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
            href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
        <?php break; ?>
        <?php default: ?>
    <?php endswitch; ?> <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" <?php endif; ?>
        role="button"
        class="button-87 button-87-grass m-0 pos-relative"
        style="border-radius: 7px;border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;
        <?php if(Auth::check() && Str::contains(Auth::user()->access??'', 'admin')): ?> text-align: start!important; <?php endif; ?>">
        <span class="   ">
            طرح ویژه امتحانات ترم اول (بوستر)
            <i class="fa fa-rocket fa-2x mx-2"></i>
        </span>
        <?php if(auth()->guard('adminII')->check()): ?>
            sss
        <?php endif; ?>
        <?php if(Auth::check() && Str::contains(Auth::user()->access??'', 'admin')): ?>
            <span style=" position:absolute; left:0;">
                شرکت کنندگان:
                <span class=" mx-2">
                    <?php echo e(\App\Models\UserStudentBooster::where('Isbooster', '1')->count()); ?>

                </span>
            </span>
        <?php endif; ?>

    </a>
    
    <!-- onclick="Livewire.dispatchTo('auth.sign','switchModal')"  -->
</span>
<video preload="none" class="col-12 p-0 video-background  shadow1X"
    loop
    poster="<?php echo e(asset('storage/Pages/Emtehanat-term-aval/boosterInterduction.webp')); ?>"
    controls
    style=" width:100%;height:100%;object-fit: cover; border-radius: 0px; border-bottom-left-radius:0px;border-bottom-right-radius:0px;">
    <source
        src="<?php echo e(asset('storage/Pages/Emtehanat-term-aval/boosterInterduction.mkv')); ?>">
    Your browser does not support the video tag.
</video>
<div class="col-12 row    p-2  text-center justify-content-center"
    style="background-color: #eee; border-radius:7px; border:1px solid #eee;">
    <a class=" button-82-pushable text-center " role="button"
        <?php if(auth()->guard()->check()): ?> <?php switch(Auth::user()->role): 
    case ('admins'): ?>
        href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
    <?php break; ?>

    <?php case ('operators'): ?>
            href="<?php echo e(route('home.index.Route')); ?>" 
    <?php break; ?>

    <?php case ('teachers'): ?>
        href="<?php echo e(route('home.index.Route')); ?>" 
    <?php break; ?>

    <?php case ('customers'): ?>
            href="<?php echo e(route('home.index.Route')); ?>" 
    <?php break; ?>

    <?php case ('counselors'): ?>
            href="<?php echo e(route('home.index.Route')); ?>" 
    <?php break; ?>

    <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
        href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
    <?php break; ?>
    <?php default: ?>
<?php endswitch; ?> <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?> onclick="Livewire.dispatchTo('auth.sign','switchModal')" <?php endif; ?>
        style=" ">
        <span class="button-82-shadow"></span>
        <span class="button-82-edge_green"></span>
        <span class="button-82-front_green text  "
            style=" font-size:large!important;">

            <span class="col mx-1"
                style="color:  rgb(255, 255, 255); text-decoration-line:none;">دریافت
                نمونه سوالات و جزوات</span>
            <span class="col mx-2 "
                style="color:  rgb(252, 245, 245); text-decoration-line:none;">(ویژه
                امتحانات ترم اول) </span>
        </span>

    </a>
</div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\booster.blade.php ENDPATH**/ ?>