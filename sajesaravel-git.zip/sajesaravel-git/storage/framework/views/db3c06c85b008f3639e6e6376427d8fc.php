 <div style=" " class="container-fluid p-0">
     <div wire:loading class="d-none">
         Saving post...
     </div>
     <?php $__env->startSection('header'); ?>
         <?php echo $__env->make('livewire.dashboard.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         
     <?php $__env->stopSection(); ?>
     
     <?php echo $__env->make('livewire.dashboard.employeed.userSection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <div class="row justify-content-center align-content-center text-center mt-2 p-0  " style="direction: rtl;">
         
         <div class="col-md-12 align-content-center   col-lg-2   align-content-center ">
             <div class="row justify-content-center align-content-center  ">
                 <?php echo $__env->make('livewire.dashboard.employeed.userInfo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

             </div>
         </div>
         <div class="col-md-12 align-content-start col-lg-10 ">
             <div class="row align-content-start justify-content-center " style="border:1px solid#fff; border-radius:7px; height:500px">
             
               <?php echo $__env->make('livewire.dashboard.employeed.tableStudent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
             </div>
         </div>
     </div>
     
     <?php $__env->startSection('Menu'); ?>
         <?php echo $__env->make('livewire.dashboard.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         
     <?php $__env->stopSection(); ?>
 </div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employeed\employeed-counsellor-panel.blade.php ENDPATH**/ ?>