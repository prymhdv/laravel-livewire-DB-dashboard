
<div class=" position-relative d-none ">
    <div class="areaX2">
        <ul class="circlesX2">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <div class="contextX2"></div>
</div>

<div id="Xmenu_bottom_container_Footer_Controll" class="container-fluid fixed-bottom p-0 "
    style="  height: 65px;  z-index:101!important; background-color: #121944;">
    <div class=" position-relative w-100">
        <div class="areaX2">
            <ul class="circlesX2">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
        <div class="contextX2"></div>
    </div>
</div>
<div id="menu_bottom_container" class="container-fluid fixed-bottom    px-sm-1 p-0"
    style="  height: 45px;  direction:rtl!important; z-index:102!important;  
    /*background-color:var(--color_sanjesh_blue);*/
    ">
    <div id="menu_bottom" class="container ">
        
        <ul class="row justify-content-evenly align-content-center" style=" ">
            <?php if(!Auth::check()): ?>
                <li id="Dashboard" class="col-3 p-1  MenuContainer text-center   "
                    style=" visibility: show;  display: inline-block;">
                    <a class="   d-flex flex-column align-middle   text-center  text-decoration-none menuLink" href="javascript:void()" onclick="Livewire.dispatchTo('auth.sign','switchModal')"
                    style="  background-color: initial!important;" href="<?php echo e(route('entekhabReshte.index.Route')); ?>">
                            
                            <img src="<?php echo e(asset('storage/main/home/services/dashboard-3d.webp')); ?>" 
                                 class="iconeSize menuPos" style="    "> 
                            <p class="  font-peyda m-0 p-0 fs-3 text-nowrap  " style="  ">
                                پنل‌کاربری
                            </p>
                    </a>
                </li>
            <?php else: ?>
                <li id="Dashboard" class="col-3 p-1  MenuContainer   text-center  "
                    style=" visibility: show;  display: inline-block;">
                    <a class=" d-flex flex-column align-middle   text-center  text-decoration-none menuLink"
                       style="   background-color: initial!important;"
                        <?php switch(Auth::user()->role): 
                                        case ('admins'): ?>
                                            href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
                                        <?php break; ?>

                                        <?php case ('operators'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('teachers'): ?>
                                            href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('customers'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('counselors'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                                            href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
                                        <?php break; ?>
                                        <?php default: ?>
                                           href="<?php echo e(route('entekhabReshte.index.Route')); ?>"
                                    <?php endswitch; ?>>
                        
                            
                            <img src="<?php echo e(asset('storage/main/home/services/dashboard-3d.webp')); ?>" class="iconeSize menuPos"
                                 style="  ">
                            <p class="  font-peyda m-0 p-0 fs-3 text-nowrap  "style="  ">
                                پنل‌کاربری
                            </p>
                       
                    </a>
                </li>
            <?php endif; ?> 

            

            <li id="takhmin" class="col-3  MenuContainer " style=" visibility: show; display: inline-block;">
                <a class="   d-flex flex-column align-middle   text-center  text-decoration-none menuLink"
                    style=" background-color: initial!important;align-items: center;" href="<?php echo e(route('takhminRotbe.index.Route')); ?>">
                    
                    <img src="<?php echo e(asset('storage/main/home/services/Icon-03.webp')); ?>" class="iconeSize menuPos">
                    <p class="  font-peyda fs-3   text-nowrap    " style="  ">
                        تخمین رتبه
                    </p>
                </a>
            </li>

            
            <li id="entekhabReshte" class="col-3 MenuContainer      " style=" visibility: show; display: inline-block;">
                <a class=" d-flex flex-column align-middle   text-center   text-decoration-none menuLink"
                    style="   background-color: initial!important;" href="<?php echo e(route('entekhabReshte.index.Route')); ?>">
                    <img src="<?php echo e(asset('storage/main/home/services/Icon-04.webp')); ?>" class="iconeSize menuPos"
                         style="   ">
                    <p class="  font-peyda  fs-3 text-nowrap   " style="  ">
                        انتخاب رشته
                    </p>
                </a>
            </li>

            <li id="home" class="col-3   MenuContainer  " style=" visibility: show; display: inline-block;">
                <a class="  d-flex flex-column align-middle text-center text-decoration-none menuLink"
                    style=" background-color: initial!important;" href="<?php echo e(route('home.index.Route')); ?>">
                    <img src="<?php echo e(asset('storage/main/home/services/home.webp')); ?>" class="iconeSize menuPos  ">
                    <p class=" font-peyda fs-3 text-nowrap     " style=" ">
                        خانه
                    </p>
                </a>
            </li>
        </ul>
    </div>
</div>

<style>
    .menuPos {  
        width: 55px !important;
        height: 55px !important; 
    }

    .menuLink {
        position: absolute !important;
        top: -35px;
        /*right: 50%;
        left: 50%;*/
        justify-self: anchor-center;
    }

    .MenuContainer {
        position: relative !important;
    }

    .icons {
        text-shadow: 2px 2px #151515;
    }

    /*   background-color: #4daf50;  color: var(--color_sanjesh_blue); */
    #menu_bottom_container {

        color: #ffffff !important;
        /* background-color: var(--color_sanjesh_blue); */
        background-color: initial;
    }

    #menu_bottom_container p {

        color: #ffffff !important;
        /* background-color: var(--color_sanjesh_blue); */
        transition: 0.25s;
        background-color: initial;
    }

    #menu_bottom_container i {

        color: #ffffff;
        cursor: pointer;
        transition: ease-in-out all 0.2s !important;

        color: #FFFFFF;
        /* background: initial; */
        /* background-color: initial; */
        text-shadow: 0 1px 0 #CCCCCC, 0 2px 0 #c9c9c9, 0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0, 0, 0, .1), 0 0 5px rgba(0, 0, 0, .1), 0 1px 3px rgba(0, 0, 0, .3), 0 3px 5px rgba(0, 0, 0, .2), 0 5px 10px rgba(0, 0, 0, .25), 0 10px 10px rgba(0, 0, 0, .2), 0 20px 20px rgba(0, 0, 0, .15);
        -webkit-background-clip: text;

    }

    .svg-inline--fa {
        transition: all 0.3s ease-in-out 0s !important;  
        text-shadow: 2px 2px 2px #0a0a0a, 0 0 1em #000000, 0 0 0.2em #0f0f0f;

    }

    #menu_bottom_container i:hover {
        color: var(--color_sanjesh_green);

    }



    .mb-auto1 {
        margin-bottom: 2.2rem;
    }

    .selected-page {
        color: var(--color_sanjesh_green) !important;
    }



    /* .selected-page::after {
          border-radius:50%!important;;
         border:4px solid var(--color_yellow) !important;
        content: "";
        border-bottom: 4px solid var(--color_yellow) !important;;
       
        display: inline-block;
      
        width: 100%;
         
    } */
</style>


<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partials\Menu.blade.php ENDPATH**/ ?>