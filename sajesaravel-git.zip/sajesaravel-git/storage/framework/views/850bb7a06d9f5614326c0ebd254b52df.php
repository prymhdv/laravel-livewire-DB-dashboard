<link href="<?php echo e(asset('storage/asset/Editor-SummerNotE/summernote-0.8.18-dist/summernote.css')); ?>"rel="stylesheet">
<div class="  min-vh-100 my-5">
   
            <?php echo $__env->make('blog.showContentBlogLoop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/blog/showContentBlog.blade.php ENDPATH**/ ?>