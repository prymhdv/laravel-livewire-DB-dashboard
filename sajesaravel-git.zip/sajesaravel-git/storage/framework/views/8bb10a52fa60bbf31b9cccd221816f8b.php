<div class="container">
    <div class="row">
        <div class="col-md-12">
            
        </div>
    </div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\fieldSelection\workShop.blade.php ENDPATH**/ ?>