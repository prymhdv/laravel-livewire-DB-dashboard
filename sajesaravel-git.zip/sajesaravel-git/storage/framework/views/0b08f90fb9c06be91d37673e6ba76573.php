  <?php if(Session::has('info') || Session::has('error') || isset($error) || isset($success) || isset($warning)): ?>
      <div id="ALERTS" class="container m-3 w-100" style=" ">
        <div class="row justify-content-center  align-content-center">
          <div class=" m-3 w-100 p-3" style="border:1px solid #eee; border-radius:7px;">
              <?php if(Session::has('info')): ?>
                  
                  <div class="container">
                      <div class="alert alert-success mg-b-10" role="alert">
                          <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                              <span aria-hidden="true">×</span>
                          </button>
                          <strong> <?php echo e(Session::get('info')); ?> </strong>
                      </div>
                  </div>
                  
              <?php endif; ?>
              <?php if(Session::has('error')): ?>
                  
                  <div class="container">
                      <div class="alert alert-danger mg-b-10" role="alert">
                          <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                              <span aria-hidden="true">×</span>
                          </button>
                          <strong><?php echo e(Session::get('error')); ?></strong>
                      </div>
                  </div>
                  
              <?php endif; ?>
              
              <?php if(isset($error)): ?>
                  
                  
                  <div class="container">
                      <div class="alert alert-danger mg-b-10" role="alert">
                          <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                              <span aria-hidden="true">×</span>
                          </button>
                          <strong><?php echo e($error); ?></strong>
                      </div>
                  </div>
                  
              <?php elseif(isset($success)): ?>
                  
                  <div class="container">
                      <div class="alert alert-success mg-b-10" role="alert">
                          <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                              <span aria-hidden="true">×</span>
                          </button>
                          <strong> <?php echo e($success); ?> </strong>
                      </div>
                  </div>
                  
              <?php elseif(isset($warning)): ?>
                  
                  <div class="container">
                      <div class="alert alert-warning mg-b-10" role="alert">
                          <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                              <span aria-hidden="true">×</span>
                          </button>
                          <strong> <?php echo e($warning); ?></strong>
                      </div>
                  </div>
                  
              <?php endif; ?>
          </div>
        </div>
  </div>
  <?php endif; ?>


  <?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\dashboard\partials copy\alert.blade.php ENDPATH**/ ?>