 <!-- معرفی موسسه -->
 <div class="content-wrapper">
     <div class="row align-items-center">
         <div class="col-md-5">
             <h4 class="text-center text-primary fw-bold">معرفی موسسه بنیاد سنجش ایرانیان</h4>
             <p class="mb-4">
                 موسسه بنیاد سنجش ایرانیان از بزرگ‌ترین و به‌روزترین موسسات آموزشی کشور است که با مجوز رسمی از وزارت
                 آموزش‌و‌پرورش و ارشاد اسلامی فعالیت می‌کند. این موسسه با بیش از ۱۴ نمایندگی، ۷۰۰ پرسنل و ۵۰۰ مشاور و
                 مدرس،
                 خدمات آموزشی حضوری و آنلاین را در قالب بیش از ۱۰ مجموعه فعال ارائه می‌دهد.
             </p>
             <p class="mb-4">
                 بنیاد سنجش برگزارکننده بزرگ‌ترین لایوها، همایش‌ها، کلاس‌ها و آزمون‌های شبیه‌ساز کنکور در کشور بوده و
                 ناشر
                 مجموعه معتبر «اگر من طراح باشم» است. همچنین این موسسه با سابقه‌ای درخشان از سال ۱۳۹۵، به عنوان
                 بزرگ‌ترین
                 مرکز تخصصی انتخاب رشته در کشور شناخته می‌شود.
             </p>
         </div>
         <div class="col-md-7">
             <div id="carouselTop" class="carousel slide" data-bs-ride="carousel">
                 <div class="carousel-inner">
                     <div class="carousel-item active">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (1).webp')); ?>"
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (2).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (3).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (4).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (5).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (6).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (7).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (8).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (9).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (10).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (11).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (12).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                     <div class="carousel-item">
                         <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home (13).webp')); ?> "
                             class="d-block w-100" alt="...">
                     </div>
                 </div>

                 <!-- دکمه‌های قبلی و بعدی -->
                 <button class="carousel-control-prev" type="button" data-bs-target="#carouselTop"
                     data-bs-slide="prev">
                     <span class="carousel-control-prev-icon"></span>
                 </button>
                 <button class="carousel-control-next" type="button" data-bs-target="#carouselTop"
                     data-bs-slide="next">
                     <span class="carousel-control-next-icon"></span>
                 </button>

             </div>

         </div>

     </div>
 </div>
 <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 <!-- اسلایدر بالای صفحه -->
 <div class="content-wrapper p-1">
     <div class="row g-3 align-items-center mb-5">
         <div class="col-md-4">
             <a wire:navigate href="<?php echo e(route('takhminRotbe.index.Route')); ?>" class="card p-2">
                 <img class="" src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-03.webp')); ?>"
                     alt="">
             </a>
         </div>
         <div class="col-md-4">
             <a wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" class="card p-2">
                 <img class="" src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-01.webp')); ?>"
                     alt="">
             </a>
         </div>
         <div class="col-md-4">
             <a wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>" class="card p-2">
                 <img class="" src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-09.webp')); ?>"
                     alt="">
             </a>
         </div>
         <div class="col-md-4">
             <a  wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" class="card p-2">
                 <img class="" src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-02.webp')); ?>"
                     alt="">
             </a>
         </div>
         <div class="col-md-4">
             <a wire:navigate href="<?php echo e(route('farhangian.index.Route')); ?>" class="card p-2">
                 <img class=""
                     src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-07.webp')); ?>"
                     alt="">
             </a>
         </div>
         <div class="col-md-4">
             <a wire:navigate href="<?php echo e(route('counsellor.employee.pages.home.Route')); ?>"  class="card p-2">
                 <img class=""
                     src="<?php echo e(asset('storage/main/student/fieldSelection/img/Site Section-08.webp')); ?>"
                     alt="">
             </a>
         </div>
     </div>


     <div class="slider-section p-1 p-lg-4">
         <div id="carouselMid" class="carousel slide" data-bs-ride="carousel">
             <div class="carousel-inner">
                 <div class="carousel-item active">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home ai-03.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home ai-07.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home ai-11.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/home ai-15.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-22.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-23.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-26.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-27.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-31.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-32.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-35.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
                 <div class="carousel-item">
                     <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/هوم-38.webp')); ?>"
                         class="d-block w-100" alt="...">
                 </div>
             </div>
             <!-- دکمه‌های قبلی و بعدی -->
             <button class="carousel-control-prev" type="button" data-bs-target="#carouselMid"
                 data-bs-slide="prev">
                 <span class="carousel-control-prev-icon"></span>
             </button>
             <button class="carousel-control-next" type="button" data-bs-target="#carouselMid"
                 data-bs-slide="next">
                 <span class="carousel-control-next-icon"></span>
             </button>
         </div>
     </div>

 </div>
 <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 <!-- در یک نگاه -->
 <div class="section-title p-1">
     <div class="content-wrapper p-1">
         <h4 class="text-center text-primary fw-bold">بنیاد سنجش در یک نگاه</h4>
         <div class="row row-cols-1 row-cols-md-2 g-5  mt-4">
             <div class="col p-1">
                 <div class="text-center rounded card p-2">
                     <div class="card-body p-1">
                         <video controls width="100%" preload="none" poster="<?php echo e(asset('storage\Pages\home\entekhabreshte.webp')); ?>" class="pry-video1" style="border:1px solid #ddd!important;border-radius: 21px!important;">
                                              <source src="/storage/assets/uploads/videos/entekhabreshte.mp4" type="video/mp4">
                         </video>
                         <div class="card-text fw-bold">
                             انتخاب رشته بنیادسنجش </div> 
                     </div>
                 </div>
             </div>
             <div class="col p-1">
                 <div class="text-center rounded card p-2">
                     <div class="card-body p-1">
                         <video controls width="100%" preload="none" poster="<?php echo e(asset('storage\Pages\home\sarbaz.webp')); ?>" class="pry-video1" style="border:1px solid #ddd!important;border-radius: 21px!important;">
                             <source src="/storage/assets/uploads/videos/sarbaz.mp4" type="video/mp4">
                         </video>
                         <div class="card-text fw-bold">
                             همایش انتخاب رشته
                         </div>
                     </div>
                 </div>
             </div>
               <div class="col p-1">
                 <div class="text-center rounded card p-2">
                     <div class="card-body p-1">
                         <video controls width="100%" preload="none" poster="<?php echo e(asset('storage\Pages\home\khavaran.webp')); ?>" class="pry-video1" style="border:1px solid #ddd!important;border-radius: 21px!important;">
                             <source src="/storage/assets/uploads/videos/khavaran.mp4" type="video/mp4">
                         </video>
                         <div class="card-text fw-bold">
                             همایش تجلیل از دانش آموزان
                         </div>
                      

                     </div>
                 </div>
             </div>
               <div class="col p-1">
                 <div class="text-center rounded card p-2">
                     <div class="card-body p-1">
                         <video controls preload="none" poster="<?php echo e(asset('storage\Pages\home\sahand.webp')); ?>" class="pry-video1" style="border:1px solid #ddd!important;border-radius: 21px!important;">
                             <source src="/storage/assets/uploads/videos/sahand.mp4" type="video/mp4">
                         </video>
                         <div class="card-text fw-bold">
                             پخش در شبکه سهند
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 <!-- افتخار آفرینان -->
 <section class="py-5">
     <div class="container">
         <h4 class="text-center text-primary fw-bold mb-4">افتخار آفرینان بنیادسنجش</h4>
         <div id="multiItemCarousel" class="carousel slide" data-bs-ride="carousel">
             <div class="carousel-inner">
                 <div class="carousel-item active">
                     <div class="row">
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (1).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (2).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (3).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (4).webp')); ?>"
                                     class="card-img-top" alt="...">

                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="carousel-item">
                     <div class="row">
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (5).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (6).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (7).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="p-2">
                                 <img src="<?php echo e(asset('storage/main/student/fieldSelection/img/eftekhar (8).webp')); ?>"
                                     class="card-img-top" alt="...">
                             </div>
                         </div>
                     </div>
                 </div>

             </div>

             <!-- دکمه‌های قبلی و بعدی -->
             <button class="carousel-control-prev" type="button" data-bs-target="#multiItemCarousel"
                 data-bs-slide="prev">
                 <span class="carousel-control-prev-icon"></span>
             </button>
             <button class="carousel-control-next" type="button" data-bs-target="#multiItemCarousel"
                 data-bs-slide="next">
                 <span class="carousel-control-next-icon"></span>
             </button>
         </div>

     </div>
 </section>
 <?php echo $__env->make('pages.student.entekhabReshte.reserveBtn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\about.blade.php ENDPATH**/ ?>