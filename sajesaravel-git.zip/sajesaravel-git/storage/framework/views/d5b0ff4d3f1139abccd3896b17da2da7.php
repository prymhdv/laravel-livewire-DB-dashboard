<section class="slider-area slider-three-area pt-100 pb-100 d-none">
    <div class="container">
        <h3 class="text-center">
            بخشی از کارنامه های درخشان بنیادسنجش در انتخاب رشته فرهنگیان سال های قبل
        </h3>
        <div class="row">
            <div class="col-12">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="11"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="10"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="9"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img loading="lazy"class="d-block w-100 pry-border1 "
                                src="<?php echo e(asset('')); ?>/storage/assets/img/Farhangian-01.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>/storage/assets/img/Farhangian-02.jpg" alt="آزمون 8 دی">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-04.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-05.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-6.jpg" alt="آزمون 8 دی">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-07.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-08.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-09.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-10.jpg" alt="آزمون 8 دی">
                        </div>
                        <div class="carousel-item">
                            <img loading="lazy"class="d-block w-100 pry-border1"
                                src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-11.jpg" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\farhangian\Karname.blade.php ENDPATH**/ ?>