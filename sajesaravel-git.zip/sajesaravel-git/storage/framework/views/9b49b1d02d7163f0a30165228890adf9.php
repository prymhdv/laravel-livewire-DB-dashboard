<div class="d-flex justify-content-center align-content-center m-2 ">
    <div class=" justify-content-center align-content-center text-middle text-center text-danger ">
        ورود به کانال VIP سوالات بنیاد سنجش
        <span class=" align-content-center"><i class="fab fa-telegram fa-1x px-1 " style="color: #ff0000;"></i></span>
        &#8656;
    </div>
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->booster()->exists() && Auth::user()->booster->IsboosterII == '1'): ?>
            <a id="buyClick"
                class="d-flex  dvdvdvdv 
            <?php if(request()->route()->getName() == 'emtehanat_term_aval.index.Route'): ?> px-4 <?php else: ?> px-2 <?php endif; ?>
            rotate-button2 shadow1 "
                 href="https://t.me/sanjesh12bot" target="_blank" 
                style="line-height: normal;  color:white;  cruser:pointer; font-weight:600;   border-radius:12px;">
                <img src="<?php echo e(asset('storage/main/home/services/Icon-08.webp')); ?>" class="  p-1 px-2 " loading="lazy"
                    style="width: 50px; ">
                <span class="align-content-center text-wrap">
                    
                    دریافت جزوات و شبیه ترین سوالات امتحانات خرداد 1404
                </span>
                

            </a>
        <?php else: ?>
            
            <a target="_blank" id="buyClick"
                class=" d-flex  dvdvdvdv
            <?php if(request()->route()->getName() == 'emtehanat_term_aval.index.Route'): ?> px-4 <?php else: ?> px-2 <?php endif; ?>
              rotate-button2 shadow1 "
                 href="https://t.me/sanjesh12bot"
                style="line-height: normal;  color:white;  cruser:pointer;
               ; font-weight:600;   border-radius:12px;">
                <img src="<?php echo e(asset('storage/main/home/services/Icon-08.webp')); ?>" class=" p-1 px-2" loading="lazy"
                    style="width: 50px; ">
                <span class="align-content-center text-wrap">جهت بهره مندی از دوره جامع بوستر نیمسال دوم بنیاد سنجش، کلیک
                    کنید
                </span>
                

            </a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
        <a id="buyClick"
            class=" d-flex  
        <?php if(request()->route()->getName() == 'emtehanat_term_aval.index.Route'): ?> px-4 <?php else: ?> px-2 <?php endif; ?>
        rotate-button2 shadow1 align-content-center "
             href="https://t.me/sanjesh12bot" target="_blank"
            style=" color:white;  cruser:pointer;
                  font-weight:600;  border-radius:12px;">
            <img src="<?php echo e(asset('storage/main/home/services/Icon-08.webp')); ?>" class=" p-1  px-2" loading="lazy"
                style="width: 50px; ">
            <span class="align-content-center text-wrap">
                
                دریافت جزوات و شبیه ترین سوالات امتحانات خرداد 1404
            </span>
            

        </a>
    <?php endif; ?>
    
    <style>
        #buyClick {
            transform: scale(1);
            transition: all 0.3s ease-in-out 0s;
            cursor: pointer;

            background-color: #013680 !important;
            border: 2px solid #003580 !important;
            ;
        }

        #buyClick:hover {
            transform: scale(1);
            background-color: #006aff !important;
            border: 2px solid #006aff !important;
            ;
        }

        .dvdvdvdv {
            box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset !important;
        }
    </style>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\emtehanat\boosterBTN_inself.blade.php ENDPATH**/ ?>