   <?php
   
   $arrVideos = [
       ['folder' => 'تاریخ', 'title' => 'تاریخ دهم - استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ دوازدهم انسانی-جلسه اول- استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'انسانی', 'field_base' => 'دوازدهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ دوازدهم انسانی-جلسه دوم-استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'انسانی', 'field_base' => 'دوازدهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ معاصر یازدهم-جلسه اول-استاد آزادی.mkv', 'class' => 'تاریخ معاصر', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ معاصر یازدهم-جلسه دوم-استاد آزادی.mkv', 'class' => 'تاریخ معاصر', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ یازدهم-جلسه اول-استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'تاریخ', 'title' => 'تاریخ یازدهم-جلسه دوم - استاد آزادی.mkv', 'class' => 'تاریخ', 'ostad' => 'استاد آزادی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دهم'],
   
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی دوازدهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه اول-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه دوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'جامعه شناسی یازدهم-جلسه سوم-استاد ابوالهادی میرزایی.mkv', 'class' => 'جامعه شناسی', 'ostad' => 'استاد ابوالهادی میرزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
   
       ['folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی-جلسه اول-استاد میرزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی-جلسه دوم- استاد میرزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'جامعه شناسی', 'title' => 'هویت اجتماعی جلسه سوم-استاد میزایی.mkv', 'class' => 'هویت اجتماعی', 'ostad' => 'استاد میزایی', 'session' => 'سوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
   
       ['folder' => 'دین و زندگی', 'title' => 'دین و زندگی دوازدهم-جلسه اول.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'دین و زندگی', 'title' => 'دین و زندگی دوازدهم-جلسه دوم.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'دوازدهم'],
       ['folder' => 'دین و زندگی', 'title' => 'دین و زندگی یازدهم-جلسه اول-استاد نژادنجف.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'اول', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
       ['folder' => 'دین و زندگی', 'title' => 'دین و زندگی یازدهم-جلسه دوم-استاد نژادنجف.mkv', 'class' => 'دین و زندگی', 'ostad' => 'استاد نژادنجف', 'session' => 'دوم', 'field' => 'عمومی', 'field_base' => 'یازدهم'],
   ];
//    $arrVideos = getBoosterVideo();
   $arrVideos5 = null;
   if (request('which') == 'I') {
       $arrVideos5 = getBoosterVideo();
   }
   if (request('which') == 'II') {
       $arrVideos5 = getBoosterIIVideo();
   }
   $classifiedVideos = [];
   // foreach ($arrVideos as $video){ $CategoriesVideos[$video['class']][] = $video;}
   
   $CategoriesVideos = [];
   foreach ($arrVideos as $video) {
       // Ensure the class and folder exist in the structure before assigning
       if (!isset($CategoriesVideos[$video['field_base']][$video['field']][$video['class']])) {
           $CategoriesVideos[$video['field_base']][$video['field']][$video['class']] = [];
       }
   
       // Add the video to the appropriate category
       $CategoriesVideos[$video['field_base']][$video['field']][$video['class']][] = $video;
   }
   
   // Output the categorized videos to check
   // echo '<pre>';
   // print_r($CategoriesVideos);
   // echo '</pre>';
   $fieldBase = Auth::user()->student->field_Base;
   $field = Auth::user()->student->field;
   
   ?>
   
   <!----------------------------------------------------array_keys($Videos[0]['folder']---------->

   <?php if(isset($CategoriesVideos[$fieldBase][$field]) || isset($CategoriesVideos[$fieldBase]['عمومی'])): ?>
       
       <?php if(isset($CategoriesVideos[$fieldBase][$field])): ?>
           <?php
               $videoSection = $CategoriesVideos[$fieldBase][$field];
               if (isset($CategoriesVideos[$fieldBase]['عمومی'])) {
                   $videoSection = $videoSection + $CategoriesVideos[$fieldBase]['عمومی'];
               }
           ?>
       <?php else: ?>
           <?php
               if (isset($CategoriesVideos[$fieldBase]['عمومی'])) {
                   $videoSection = $CategoriesVideos[$fieldBase]['عمومی'];
               }
           ?>
       <?php endif; ?>
       
       <?php $__currentLoopData = $videoSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexSection => $Videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
           
           <div class="col-12 p-0   align-content-center justify-content-center  mb-5 ">
               <div class="col-10 p-2 font-weight-bolder  pry-border1 shadow1  m-auto " style="">

                   <?php echo e($Videos[0]['class'] .
                       ' - ' .
                       $Videos[0]['field_base'] .
                       ' - ' .
                       $Videos[0]['field'] .
                       ' - ' .
                       $Videos[0]['ostad']); ?>


               </div>
               <!-- style="direction: ltr;" -->
               <div class="owl-carousel owl-theme owl-loaded p-2">
                   <div class="owl-stage-outer">
                       <div class="owl-stage">
                           <?php $__currentLoopData = $Videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexVideos => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                               
                               <div class="owl-item">
                                   <div class="p-0   " style=" border-radius:7px; border:1px solid #aaa; ">
                                       <video preload="none" class="video-background  " controls 
                                           <?php if($video['field'] == 'انسانی'): ?> poster="<?php echo e(asset('storage/' . $video['posterE'])); ?>"
                                             <?php elseif($video['field'] == 'ریاضی'): ?>
                                                poster="<?php echo e(asset('storage/' . $video['posterR'])); ?>"
                                             <?php elseif($video['field'] == 'تجربی'): ?>
                                                poster="<?php echo e(asset('storage/' . $video['posterT'])); ?>" <?php endif; ?>
                                           style=" width:100%;height:100%;object-fit: cover; border-radius: 7px;
                                            border-bottom-left-radius: 0px;
                                            border-bottom-right-radius: 0px;">
                                           <source
                                               src="<?php echo e(asset('storage/Pages/Emtehanat-term-aval/' . $video['folder'] . '/' . $video['title'])); ?>">

                                           Your browser does not support the video tag.
                                       </video>
                                       
                                       <div class="pb-2 " style="  border-radius:0px;">
                                           <span class="font-peyda ">جلسه
                                               <?php echo e($video['session']); ?></span>
                                       </div>

                                   </div>
                               </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </div>
                       <!-- <div class="owl-nav">
                        <div class="owl-prev">prev</div>
                        <div class="owl-next">next</div>
                    </div>
                       <div class="owl-dots">
                        <div class="owl-dot active"><span></span></div>
                        <div class="owl-dot"><span></span></div>
                        <div class="owl-dot"><span></span></div>
                    </div> -->
                   </div>
               </div>
               <!-------------------------------------------------------------->
           </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\booster\VideoNomune.blade.php ENDPATH**/ ?>