<!--Footer ------------------------------------------------------------------------------------------------ -->
<!--Footer ------------------------------------------------------------------------------------------------ -->

<footer id="XfooterX" class=" "> 
</footer> <?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\footer.blade.php ENDPATH**/ ?>