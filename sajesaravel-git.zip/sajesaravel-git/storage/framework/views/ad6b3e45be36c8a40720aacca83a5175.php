<div class="col-md-12 p-0 d-none">
    <div id="secound" class=" p-1 cardX cardX2 m-1  justify-content-center align-content-center shadow1X w-100">
        <?php echo $__env->make('pages.home.employee-counsellor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\employeeCounsellor.blade.php ENDPATH**/ ?>