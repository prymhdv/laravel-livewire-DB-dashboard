




<div class="  p-5 fs-1 text-bold" style="margin-top:200px">
    
   the time is: <?php echo e(time()); ?>

</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\home\test.blade.php ENDPATH**/ ?>