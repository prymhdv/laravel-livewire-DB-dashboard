<!--[if BLOCK]><![endif]--><?php if(request()->route()->getName() == 'edit.users.adminPanelLivewireRoute'): ?>
    <div class="row p-1">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    ویرایش حساب کاربری
                </div>
            </div>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/user/edit.blade.php ENDPATH**/ ?>