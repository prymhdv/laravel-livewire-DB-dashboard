<meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <title>بنیاد سنجش | <?php echo $__env->yieldContent('pageTitle'); ?> <?php echo e($title ?? ''); ?> </title>
 <!-- Fonts -->
 
 
 

 <meta name="description"
     content="بزرگترين موسسهٔ آموزشی کشور؛ پیشرو در ارایهٔ آموزش‌های حضوری و آنلاین، جلسات مشاوره و برنامه‌ریزی، با ۱۰ سال سابقهٔ فعالیت آموزشی و کسب رتبه‌های برتر و تک‌رقمی در سال‌های اخیر.">
 <meta name="enamad" content="143392" />
 <meta name="author" content="SanjeshBonyad.org">
 <meta name="keywords"
     content="همایش بزرگ, بنیاد سنجش, بورسیه تحصیلی, اساتید کنکور, کلاس کنکور, مشاوره تحصیلی, آزمون هفتگی, برنامه‌ریزی درسی, پایه نهم, پایه دهم, پایه یازدهم, پایه دوازدهم, پشت کنکوری, آموزش, استاد آریان حیدری, استاد محمد همدانی, کتب کمک آموزشی, مشاوران تحصیلی برتر, بنیاد سنجش ایران">

 <?php
 // Set the cache to expire 3 days from today
//  $expireDate = gmdate('D, d M Y H:i:s', time() + 259200) . ' GMT';
//  $expireDate = gmdate('D, d M Y H:i:s', time() + 0) . ' GMT';
//   $expireDate =0;
 // Send the appropriate cache headers
//  header('Cache-Control: max-age=259200, public');
//  header("Expires: $expireDate");
 
 ?>

 <?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\layouts\headMeta.blade.php ENDPATH**/ ?>