 <style>
    
/* <!-- HTML !-->
<button class="button-87" role="button">Button 87</button> */

/* CSS */
.button-87 {
  margin: 10px;
  padding: 15px 30px;
  text-align: center;
  text-transform: uppercase;
  transition: 0.5s;
  background-size: 200% auto;
  color: white;
  border-radius: 10px; 
  display: block;
  border: 0px;
  font-weight: 700;
  box-shadow: 0px 0px 14px -7px #f09819;
  background-image: linear-gradient(45deg, #FF512F 0%, #F09819  51%, #FF512F  100%);
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-87:hover {
  background-position: right center;
  /* change the direction of the change here */
  color: #fff;
  text-decoration: none;
}

.button-87:active {
  transform: scale(0.95);
}

.button-87-blue {
  box-shadow: 0px 0px 14px -7px #0066b2!important;
  background-image: linear-gradient(45deg, #002244 0%, #0066b2  51%, #002244  100%)!important;
  
}
.button-87-Ice {
  box-shadow: 0px 0px 14px -7px #00f0ed!important;
  background-image: linear-gradient(45deg, #00f0ed 0%, #ff0055  51%, #00f0ed  100%)!important;
  
}

.button-87-grass {
  box-shadow: 0px 0px 14px -7px #00f00c!important;
  background-image: linear-gradient(45deg, #00f00c 0%, #0a4e01  51%, #00f00c  100%)!important;
  
}
 
 </style><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/prymhdvAssets/css/btn.blade.php ENDPATH**/ ?>