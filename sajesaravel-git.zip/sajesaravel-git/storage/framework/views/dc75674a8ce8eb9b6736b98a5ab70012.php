<?php
// //Illuminate\Support\Facades\View::share('admins', new CAdmins());   // Or fetch dynamic data
// //Illuminate\Support\Facades\View::share('agents', new CAgents());   // Or fetch dynamic data
// //Illuminate\Support\Facades\View::share('orders', new COrders());
// //global $admins,$agents,$orders;

// $agents = new CAgents();
// 
// $admins = new CAdmins();
// $operator = new CAdmins();
// $_SESSION['ausername'] = 'AKdeh';
// $admin = $admins->GetAdminInfo($_SESSION['ausername']);
// $accessadmin = $admins->accessadmin($admin['aid']);
// // if ($accessadmin == 0) {
// //     header('location:../logout?error=block');
// //     exit();
// // }
?>



<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <!-- dashboard head -->
    <?php echo $__env->make('Home.Dashboard.layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'داشبورد'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('Home.Dashboard.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('home'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Dashboard'); ?>
    <body class="main-body leftmenu">

        
        
        
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\dashboard\main.blade.php ENDPATH**/ ?>