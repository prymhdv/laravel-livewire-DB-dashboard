<?php if(request()->route()->getName() == 'callCenter.adminPanelLivewireRoute'): ?>
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="text-end p-2"> گزارش ها:</div>
            <div class="card">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-2 text-end">
                                    تعداد کل تماس ها:
                                </div>
                                <div class="col-md">
                                    XXXX
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-2 text-end">
                                    تعداد تماس های موفق:
                                </div>
                                <div class="col-md">
                                    XXXX
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-2 text-end">
                                    تعداد تماس های رد شده:
                                </div>
                                <div class="col-md">
                                    XXXX
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-2 text-end">
                                    تعداد تماس های در انتظار:
                                </div>
                                <div class="col-md">
                                    XXXX
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\callCenter\hello.blade.php ENDPATH**/ ?>