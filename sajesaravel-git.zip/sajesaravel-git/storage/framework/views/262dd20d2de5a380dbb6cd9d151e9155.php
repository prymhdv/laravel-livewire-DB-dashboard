<!--[if BLOCK]><![endif]--><?php if(request()->route()->getName()=='callCenter.adminPanelLivewireRoute' 
     || request()->route()->getName()=='sms.operator.callCenter.adminPanelLivewireRoute'): ?>
    <div class="row">
        <div class="col-md-12">

            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-3">
                <a href="<?php echo e(route('sms.operator.callCenter.adminPanelLivewireRoute')); ?>" class="hover4 d-block justify-items-center align-content-center  "
                    style=" ">
                    مدیریت پیامک اپراتور ها
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
              
            </div>
            <hr class="m-0">
            <?php echo $__env->make('livewire.dashboard.admin.callCenter.hello', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('livewire.dashboard.admin.callCenter.operator.sms', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/callCenter/main.blade.php ENDPATH**/ ?>