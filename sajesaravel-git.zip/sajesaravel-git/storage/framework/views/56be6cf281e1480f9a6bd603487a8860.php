<!--Header ------------------------------------------------------------------------------------------------ -->
<!--Header ------------------------------------------------------------------------------------------------ -->


<?php echo $__env->make('pages.prymhdv.partials.header-side', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<style>
    :root {
        --height-nav: 65px;
        --height-navG: 35px;
        /* 58px */
    }
</style>


<?php echo $__env->make('pages.prymhdv.partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<div style="margin-top: var(--height-nav ); visibility:hidden " class="container-fluid "></div>


<?php if(request()->route()->getName() == 'counsellor.employee.pages.home.Route' || request()->route()->getName() == 'edit.profile.route' || Str::contains( request()->route()->uri(),'dashboard')): ?>;
<?php else: ?>
    <?php $__env->startSection('headerSub'); ?> 
        <?php echo $__env->make('pages.prymhdv.partials.headerSub', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
<?php endif; ?>


<?php if(request()->route()->getName() == 'farhangian.index.Route'): ?>
    <div class="container p-0 column text-center shadow1"style="user-select: none;">
        <div class="row">
            <div class="col-12 p-3 user-select-none font-bold fs-5"
                style="
                color:#4daf50; 
                border-bottom-left-radius: 7px;border-bottom-right-radius: 7px;;
                background: linear-gradient(90deg, #0f0c29 0%, #302b63 50%, #24243e 100%);">
                پرتال کاربری داوطلبان کنکور سراسری و فرهنگیان ۱۴۰۴
            </div>
        </div>
    </div>
<?php endif; ?>


<!-- ---------------------------------------------------------- -->

<!--Header Modals------------------------------------------------------------------------------------------------ -->

<!--Header Modals------------------------------------------------------------------------------------------------data-bs-backdrop="static" -->

<style>
    .selected-pageNav {
        color: #0072ff !important;
    }
</style>
<script wire:ignore type="text/javascript">
    /*Wait until the shadow DOM is ready*/
    document.addEventListener('DOMContentLoaded', (event) => {
        var customSelect = document.querySelector('webrouk-custom-select2');

        if (customSelect && customSelect.shadowRoot) {
            var selectDescCity = customSelect.shadowRoot.querySelector('#selectDesc_city');
            /* 
                //   if (selectDescCity) {
                //       selectDescCity.innerHTML = "شهر";
                //   } 
            */
        }
    });
    /* document.addEventListener('DOMContentLoaded', () => { */
    /*   $(document).ready(function() {alert($('#province').all);alert('#province[name="province' + jobs+ '"]'); */

    /*------------------------------------------*/
</script>


<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/prymhdv/partials/header.blade.php ENDPATH**/ ?>