<div x-data="counter" class="col-12 p-0 d-none">
    <h1 x-text="count"></h1>
    <button x-on:click="increment">+</button>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\temp.blade.php ENDPATH**/ ?>