<div id="carouselExampleIndicators" class="carousel slide pry-border1 shadow1" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-01.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-02.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-03.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-04.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-05.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
        <div class="carousel-item">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('')); ?>storage/assets/img/sendingsetudent/Slider-06.jpg"
                alt="توضیحات اولیه خدمات اخذ پذیرش بنیاد سنجش">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\dispatch\banner.blade.php ENDPATH**/ ?>