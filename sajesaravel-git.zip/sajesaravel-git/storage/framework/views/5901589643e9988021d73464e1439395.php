<div id="carouselExampleIndicators" class="carousel slide"
data-ride="carousel">
<ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators"
        data-slide-to="2">
    </li>
    <li data-target="#carouselExampleIndicators"
        data-slide-to="1">
    </li>
    <li data-target="#carouselExampleIndicators"
        data-slide-to="0"class="active"></li>
</ol>
<div class="carousel-inner">
  
    <div class="carousel-item active">
        <a href="javascript:void()"
            <?php if(auth()->guard()->guest()): ?> onclick="Livewire.dispatchTo('auth.sign','switchModal')" <?php endif; ?>>
            <img loading="lazy" class=" d-block w-100 "
                style="height:100%;width:auto;"
                src="<?php echo e(asset('storage/Pages/home/etelaiye/اطلاعیه_مهم_امتحانات_ترم_اول_دی_ماه_1403_01.jpg')); ?>"
                alt="امتحانا ترم اول (بوستر-1)">
        </a>
    </div>
    <div class="carousel-item">
        <a href="javascript:void()"
            <?php if(auth()->guard()->guest()): ?> onclick="Livewire.dispatchTo('auth.sign','switchModal')" <?php endif; ?>>
            <img loading="lazy" class=" d-block w-100 "
                style="height:100%;width:auto;"
                src="<?php echo e(asset('storage/Pages/home/etelaiye/قابل_توجه_دانش_آموزان_گرامی_پایه_های_ششم،_نهم،_دهم،_یازدهم_و_دوازدهم.jpg')); ?>"
                alt="امتحانا ترم اول (بوستر-11)">
        </a>
    </div>


</div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\booster-side.blade.php ENDPATH**/ ?>