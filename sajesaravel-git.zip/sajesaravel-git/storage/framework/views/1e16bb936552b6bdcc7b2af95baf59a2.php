<!--[if BLOCK]><![endif]--><?php if(!Auth::check() || session()->has('Sign_captcha')): ?>
    <div id="GetMobile" class="col-md-12 py-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <p class=" text-dark fs-4 " style=" user-select:none;">
                    جهت ثبت نام و یا ورود به پنل کاربری
                    <span class="text-bold text-success mx-2">شماره موبایل</span>
                    خود را وارد کنید...
                </p>
                <div class="row justify-content-center">
                    <div class="col-md-12 ">
                        <input class=" text-center form-control " type="text" name="mobile"
                            <?php if(session()->has('Sign_captcha')): ?> disabled <?php endif; ?> placeholder="09120000000"
                            wire:model="mobile" style="border:2px solid #aaa; border-radius:7px;">
                        <?php echo $__env->make('livewire.error', ['e' => 'mobile'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <div class="col-md-12  p-2">
                        <div class="row align-content-center my-2 ">
                            <div class=" <?php if(!session()->has('Sign_captcha')): ?> col-md-12 <?php else: ?> col-md-6 <?php endif; ?>"
                                style=" user-select: none!important;">
                                <span id="BTNHYGHFG" class=" btn btn-success fs-4 py-2  my-2  w-100" 
                                      
                                      
                                     
                                    <?php if(!session()->has('Sign_captcha')): ?> wire:click="getMobileCode"
                                    <?php else: ?> 
                                            wire:click="checkMobileCode" <?php endif; ?>>
                                    <!--[if BLOCK]><![endif]--><?php if(!session()->has('Sign_captcha')): ?>
                                        دریافت کد پیامک
                                        <i id="BTNHYG" class="fa-solid fa-spinner fa-pulse mx-2 invisible"   > </i>
                                    <?php else: ?>
                                        تایید کد پیامک
                                        <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
                                            ورود | 
                                        <?php else: ?>
                                            ثبت نام | 
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>
                                <?php
        $__scriptKey = '2140954765-0';
        ob_start();
    ?>
                            <script >
                                $(document).ready(function() {
                                    // console.log('llsssssssssssssl');
                                    $('#BTNHYGHFG').click(function() {
                                        // alert('Button clicked!');
                                        // console.log('lll'); 
                                        // $('#BTNHYG').show();
                                        $('#BTNHYG').removeClass('invisible');  
                                        $('#BTNHYG').addClass('visible');
                                        // $('#BTNHYG').fadeOut();
                                        // $('#BTNHYG').fadeIn();
                                    });
                                }); 
                            </script>
                                <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
                            <div class="  col-md-6  <?php if(!session()->has('Sign_captcha')): ?> d-none <?php endif; ?>">
                                <input class=" text-center form-control py-2  my-2  " type="text" name="smsCode"
                                    placeholder="کد تایید پیامک"  
                                     wire:model.live.debounce.500ms="smsCode"
                                      
                                     
                                    style="border:2px solid #aaa; border-radius:7px;">
                                <?php echo $__env->make('livewire.error', ['e' => 'smsCode'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/auth/mobile.blade.php ENDPATH**/ ?>