<?php if(session()->has('Sign_success')): ?>
<div class="alert alert-success my-3 py-2">
    <?php echo e(session('Sign_success')); ?>

</div>
<?php elseif(session()->has('Sign_warning')): ?>
<div class="alert alert-warning my-3 py-2">
    <?php echo e(session('Sign_warning')); ?>

</div>
<?php elseif(session()->has('Sign_danger')): ?>
<div class="alert alert-danger my-3 py-2">
    <?php echo e(session('Sign_danger')); ?>

</div>
<?php elseif(session()->has('Sign_error')): ?>
<div class="alert alert-error alert-danger my-3 py-2">
    <?php echo e(session('Sign_error')); ?>

</div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\alerts.blade.php ENDPATH**/ ?>