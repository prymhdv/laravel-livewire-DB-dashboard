 

 
 <figure class="icon-cards mt-3 justify-content-center align-content-center">
     <div class="icon-cards__content justify-content-center align-content-center">
         
         
         <?php
             $numbers = range(1, 53);
             shuffle($numbers);
             $last = array_pop($numbers);
             $numbers[] = $last;
             foreach ($numbers as $index => $i) { 
                 echo '
                  <div class="icon-cards__item d-flex align-items-center justify-content-center">
                    <img fetchpriority="high" class="d-block w-100 pry-border1" src="' .
                     asset('storage/main/student/fieldSelection/KarnameSelected/Slide') .
                     $i .
                     '.webp" alt="' .
                     $i .
                     ' انتخاب رشته">
                 </div>';
             }
         ?>
     </div>
 </figure>

 
 
 
 <script>
     function classToggle() {
         var el = document.querySelector('.icon-cards__content');
         el.classList.toggle('step-animation');
     }

     document.querySelector('#toggle-animation').addEventListener('click', classToggle);
 </script>

 <style>
     .icon-cards {
         position: relative;
         width: 60vw;
         height: 40vw;
         max-width: 380px;
         max-height: 250px;
         margin: 0;
         color: white;
         perspective: 1000px;
         transform-origin: center;
     }

     .icon-cards__content {
         position: absolute;
         width: 100%;
         height: 100%;
         transform-origin: center;
         transform-style: preserve-3d;
         transform: translateZ(-30vw) rotateY(0);
         animation: carousel 100s infinite cubic-bezier(0.77, 0, 0.175, 1) forwards;
     }

     .icon-cards__content.step-animation {
         animation: carousel 80s infinite steps(1) forwards;
     }

     .icon-cards__item {
         position: absolute;
         top: 0;
         left: 0;
         right: 0;
         bottom: 0;
         width: 60vw;
         height: 40vw;
         max-width: 380px;
         max-height: 250px;
         box-shadow: 0 5px 20px rgba(0, 0, 0, .1);
         border-radius: 6px;
         transform-origin: center;
         display: flex;
         align-items: center;
         justify-content: center;
         font-size: 3rem;
     }

     .icon-cards__item:nth-child(1) {
         background: #fdd94f;
         transform: rotateY(0) translateZ(35vw);
     }

     .icon-cards__item:nth-child(2) {
         background: #f87949;
         transform: rotateY(120deg) translateZ(35vw);
     }

     .icon-cards__item:nth-child(3) {
         background: #fbab48;
         transform: rotateY(240deg) translateZ(35vw);
     }

     @keyframes carousel {

         0%,
         17.5% {
             transform: translateZ(-35vw) rotateY(0);
         }
          22.5% {
             transform: translateZ(-35vw) rotateY(-60deg);
         }

         27.5%,
         45% {
             transform: translateZ(-35vw) rotateY(-120deg);
         }

         55%,
         72.5% {
             transform: translateZ(-35vw) rotateY(-240deg);
         }

         77.5% {
             transform: translateZ(-35vw) rotateY(-300deg);
         }

         82.5%,
         100% {
             transform: translateZ(-35vw) rotateY(-360deg);
         }
     }

     .checkbox {
         position: relative;
         margin-top: 2rem;
         font-size: 0.9rem;
         font-weight: bold;
         text-transform: uppercase;
         color: #f47956;
         transition: color 0.3s ease;
         user-select: none;
     }

     .checkbox:hover {
         color: #f7a95a;
     }

     .checkbox__checkbox {
         position: relative;
         top: 0;
         width: 1.0625rem;
         height: 1.0625rem;
         background: white;
         border: 1px solid currentColor;
         border-radius: 4px;
         vertical-align: middle;
         transition: background 0.1s ease;
         cursor: pointer;
     }

     .checkbox__checkbox::after {
         content: '';
         position: absolute;
         top: 1px;
         left: 5px;
         width: 5px;
         height: 11px;
         opacity: 0;
         transform: rotate(45deg) scale(0);
         border-right: 2px solid #fff;
         border-bottom: 2px solid #fff;
         transition: all 0.3s ease;
         transition-delay: 0.15s;
     }

     .checkbox__label {
         margin-left: 5px;
         vertical-align: middle;
         cursor: pointer;
     }

     .checkbox>input:checked~.checkbox__checkbox {
         border-color: transparent;
         background: #f47956;
         animation: jelly 0.6s ease;
     }

     .checkbox>input:checked~.checkbox__checkbox:after {
         opacity: 1;
         transform: rotate(45deg) scale(1);
     }

     @keyframes jelly {
         from {
             transform: scale(1, 1);
         }

         30% {
             transform: scale(1.25, 0.75);
         }

         40% {
             transform: scale(0.75, 1.25);
         }

         50% {
             transform: scale(1.15, 0.85);
         }

         65% {
             transform: scale(0.95, 1.05);
         }

         75% {
             transform: scale(1.05, 0.95);
         }

         to {
             transform: scale(1, 1);
         }
     }
 </style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\carousel.blade.php ENDPATH**/ ?>