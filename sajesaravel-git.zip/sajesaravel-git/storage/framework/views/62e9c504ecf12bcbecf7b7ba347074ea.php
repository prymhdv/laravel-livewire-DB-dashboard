<div id="Banner-Booster" class="col-12   align-content-center   ">
    <div class="d-flex m-1 p-0 align-content-center justify-content-center" style=" border-radius:7px; ">
        
        <img loading="lazy"
        class="pry-border1 d-block w-100"
        src="<?php echo e(asset('storage/Pages/home/Banners/homeEmployeeCounsellor.webp')); ?>"
        alt="employment07">
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employee\panel\banner.blade.php ENDPATH**/ ?>