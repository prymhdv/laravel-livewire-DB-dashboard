<head>
    <meta http-equiv="Cache-Control" content="max-age=1, public ,no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="cache">
    <meta http-equiv="Expires" content="1">

    <script type="text/javascript">
        // Notice how this gets configured before we load Font Awesome
        // window.FontAwesomeConfig = {autoReplaceSvg: false}
    </script>
    
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-LGPE2CMN5M"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-LGPE2CMN5M');
    </script>

    <?php echo $__env->make('pages.layouts.headMeta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
        
    <?php echo $__env->make('pages.layouts.headLinkScripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.prymhdvAssets.css.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.headStyle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.headScript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pages.layouts.TagAll', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script type="text/javascript">
        window.RAYCHAT_TOKEN = "9ca95b10-c0f6-442c-8fe0-0cda1ec5c08a";
        (function() {
            d = document;
            s = d.createElement("script");
            s.src = "https://widget-react.raychat.io/install/widget.js";
            s.async = 1;
            d.getElementsByTagName("head")[0].appendChild(s);
        })();
    </script>
    <script>
        document.addEventListener('livewire:navigated', () => {
            //$('.sc_launcher').css('height', '82px;');

        });
        $(document).ready(function() {

        });
        window.addEventListener('raychat_ready', function(ets) {
            window.Raychat.setPosition({
                top: 'auto',
                right: 'auto',
                bottom: '100px',
                left: '15px'
            });
        });
    </script>
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/head.blade.php ENDPATH**/ ?>