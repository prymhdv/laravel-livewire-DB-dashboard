<div class="col-md-12  my-5  ">
    <div class="row align-items-top justify-content-center p-2 boxShadow1"
        style="  border-radius:7px;  background: linear-gradient(135deg, #01f71158 0, #024a97c6 78%, #2ef70179 100%);">

        <section class="shop-details-area p-relative pt-70 pb-50">

            <div class="container">
                <!-- <div class="image">
                                                                                                                                                                                                                <img loading="lazy" src="uploads/img/بنر تجربی.jpg')}}" width="100%">
                                                                                                                                                                                                            </div> -->
                <div class="text-center">
                    <!-- <h3 class="text-center mt-20">کلاس های جمع بندی کنکور دی ماه 1401</h3> -->
                    <!-- <a href="#" ><button class="btn btn-success mt-20" >جهت ثبت نام کلیک کنید</button></a> -->
                </div>
                <div class="row mt-20">

                    <div class="col-md-6">
                        <video preload="none" poster="<?php echo e(asset('storage\Pages\home\IMG_1531.webp')); ?>"
                            class="pry-video1" width="100%" controls="">
                            <source src="/storage/assets/uploads/videos/IMG_1531.MP4" type="video/mp4">
                        </video>
                    </div>
                    <div class="col-md-6 text-end">
                        <h3 class="text-center mt-20">مروری بر اولین آزمون شبیه ساز کنکور ویژه کنکور سراسری
                            تیرماه
                            1401
                        </h3>
                        <p class="mt-30 text-end text-light  text-dark">
                            بنا بر مصوبه های اخیر سازمان سنجش مبنی بر تغییر روند برگزاری کنکور سراسری اعم از حذف
                            دروس عمومی،
                            سه
                            دفترچه ای شدن کنکور سراسری علوم تجربی و دو دفترچه ای شدن کنکور های سراسری علوم
                            انسانی و
                            ریاضی و
                            فیزیک،
                            بنیاد سنجش ایران اولین آزمون شبیه ساز در فضای عینا" شبیه سازی شده کنکور سراسری
                            اردیبهشت
                            ماه 1402
                            را با استفاده از
                            مخزن سوالات پیشنهادی طراحان برتر کشور در محل حوزه های کنکور سراسری و توسط تیم های
                            اجرایی
                            کنکور
                            سراسری برگزار
                            می کند، تا داوطلبان با تمامی زوایای تغییرات اخیر کنکور سراسری آشنا شوند.
                        </p>
                    </div>
                    <div class="col-md-12 p-2 p-lg-4 text-dark">

                        <h4>
                            از ویژگی های منحصر بفرد این آزمون :
                        </h4>
                        <ul>
                            <li>
                                1.معتبرترین مرجع سوالات مشابه با کنکور سراسری اردیبهشت ماه 1402
                            </li>
                            <li>
                                2.شیوه برگزاری کاملا منطبق با ریزترین جزئیات برگزاری کنکور سراسری
                            </li>
                            <li>
                                3.دربرگیرنده تمامی زوایای طراحی سوال مطابق با ذهنیت طراحان برتر کشور
                            </li>
                            <li>
                                4.پرمخاطب ترین آزمون جامع شبیه ساز کنکور سراسری
                            </li>
                            <li>
                                5.بهره گیری از سوالات و مباحث پیشنهادی طراحان برتر کشور
                            </li>
                            <li>
                                6.اجرای کامل تغییرات اعمال شده از سوی سازمان سنجش آموزش کشور
                            </li>
                            <li>
                                7.رقابت بیش از هزاران هزار داوطلب در فضای کاملا شبیه سازی شده کنکور سراسری
                            </li>
                        </ul>
                        <!-- <p>
                                                                                                                                                                                                                                این آزمون در روز 23 دی ماه 1401، ساعت 8 صبح در محل دانشگاه آزاد اسلامی واحد تبریز واقع در ضلع شرقی اتوبان
                                                                                                                                                                                                                                پاسداران برگزار می گردد.
                                                                                                                                                                                                                            </p> -->
                    </div>
                </div>
                <!-- <a href="classregister"><button class="btn btn-success btn-block mt-20">جهت ثبت نام در "کلاس رایگان دی" کلیک کنید</button></a> -->
                <!-- <center> -->
                <!-- <a href="examregister"><button class="btn riazi-btn btn-block mt-20">جهت ثبت نام در "آزمون شبیه ساز دی ماه" کلیک کنید</button></a> -->
                <!-- <a href="examregister"><img loading="lazy" src="/assets/img/azmun.jpg')}}" width="100%"></a> -->
                <!-- </center> -->


            </div>
        </section>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\konkurSimulation.blade.php ENDPATH**/ ?>