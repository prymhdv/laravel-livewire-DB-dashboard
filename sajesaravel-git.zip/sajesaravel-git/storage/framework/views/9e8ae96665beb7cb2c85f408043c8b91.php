


<!DOCTYPE html>
<html   lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
        class="w-100"
        style="width: 100%!important;
         max-width: 100%!important;
          min-width: 100%!important;
           overflow-x:hidden;
           direction:ltr;
           ">

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('pages.layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('home'); ?>
    <?php echo $__env->make('pages.layouts.body', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('Dashboard'); ?>
    <?php echo $__env->make('pages.layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldSection(); ?>

</html>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/html.blade.php ENDPATH**/ ?>