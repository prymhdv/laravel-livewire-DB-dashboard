<div class="loader-container">
    <div class="animated-background profile-image"></div>
    <div class="animated-background"></div>
    <div class="animated-background"></div>
    <div class="animated-background" style="width: 50%"></div>
</div>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    .loader-container {
        margin: 0 auto;
        width: 400px;
        max-width: 90%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    @keyframes placeholder {
        0% {
            background-position: -600px 0;
        }

        100% {
            background-position: 600px 0;
        }
    }

    .animated-background {
        animation-duration: 1s;
        animation-fill-mode: forwards;
        animation-iteration-count: infinite;
        animation-name: placeholder;
        animation-timing-function: linear;
        background: #eeeeee;
        background: linear-gradient(to right, #eee 8%, #ddd 18%, #eee 33%);
        background-size: 1200px 100px;
        min-height: 30px;
        width: 100%;
        margin: 5px 0 5px 0;
        border-radius: 3px;
    }

    .profile-image {
        margin-top: 10px;
        border-radius: 50%;
        width: 100px;
        height: 100px;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\assets\PageLoader.blade.php ENDPATH**/ ?>