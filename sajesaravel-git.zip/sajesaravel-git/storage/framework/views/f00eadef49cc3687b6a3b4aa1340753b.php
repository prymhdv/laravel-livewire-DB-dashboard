
<div class="
<?php if(request()->route()->getName() != 'home.index.Route'): ?>
col-6
<?php else: ?>
col-12
<?php endif; ?>

   p-2 my-2  ">
    <div class="row  position-relative " style=" border:0px solid #f3b5b5; border-radius:7px;">
        
        <div class="col-12 p-0  ">
            <h3 class="text-center closeX_ w-100     p-2 m-0 pry-border1 fs-3 "
                style="user-select: none;  border-radius: 7px;  border-bottom-left-radius:0px ;border-bottom-right-radius:0px;    line-height: normal; color:#fff;
                border-bottom:2px solid#f3b5b5;
                    background: linear-gradient(282deg, #977b7ba8 0, #e9acacc6 78%, #d0a5a5d1 100%);
                    ">
                
                سوالات شبیه ساز کنکور، امتحانات نهایی خرداد 1404 و آزمون تخصصی فرهنگیان
                <br>
                <span style="color:<?php echo e($product6['color']); ?>; " class="p-3">ویژه رشته <?php echo e($product6['field']); ?></span>
            </h3>
        </div>
        
        <div class="col-12 p-0   " >
            <div class="row p-0 pry-border1   justify-content-center align-content-center"
                style="border-top-left-radius:0px ;border-top-right-radius:0px;   ">
                <?php $__currentLoopData = $product6['جلد']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class=" col p-0 boxShadow1  " style="background: linear-gradient(135deg, #dbbabaa8 0, #e8e0e0c6 78%, #decdcdd1 100%);">
                        <div class="row   justify-content-center align-content-center">
                            <div class="col-4 col-sm-2 p-0 text-center h-100">
                                <div class="row">
                                    <img src=<?php echo e($item['poster']); ?>

                                        style="width: 100%; height:100%; object-fit: contain;" class="p-0">
                                </div>
                            </div>
                            <div class="col-8 col-sm-10 p-0  text-center  justify-content-center align-content-center">
                                <div class="row justify-content-center align-content-center"
                                 style="direction: rtl">
                                    
                                    
                                    <div class="col-12 col-sm-12 ps-3   fsr-12 justify-content-center align-content-center ">

                                        <div class="row ps-5 fs-3 mt-3">
                                            شامل :

                                        </div>
                                        <div class="row">
                                            <span style="color:<?php echo e($product6['color']); ?>; "class="col-1 px-1 fs-6 ">•</span>
                                            <p class="col text-justify  text-break  text  m-0 text-bold  text-end px-2 fs-3"
                                                style=" ">
                                                <?php echo e($item['descI']); ?>

                                            </p>
                                          
                                        </div>
                                        <div class="row">
                                            <span style="color:<?php echo e($product6['color']); ?>; "class="col-1 px-1 fs-6 ">•</span>
                                            <p class="col text-justify  text-break  text  m-0 text-bold    text-end  px-2 fs-3 " style=" "><?php echo e($item['descII']); ?>

                                            </p>
                                           
                                        </div>
                                        <div class="row">
                                            <span style="color:<?php echo e($product6['color']); ?>; "class="col-1 px-1 fs-6 ">•</span>
                                            <p class="col text-justify  text-break  text m-0  text-bold   text-end   px-2 fs-3 "
                                                style=" ">
                                                <?php echo e($item['descIII']); ?>

                                            </p>
                                          
                                        </div>
                                        <div class="row">
                                            <span style="color:<?php echo e($product6['color']); ?>; "class=" col-1 px-1 fs-6   ">•</span>
                                            <p class="col text-justify  text-break  text m-0  text-bold   text-end   px-2 fs-3 "
                                                style=" ">
                                                <?php echo e($item['descIV']); ?>

                                            </p>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if( !Auth::check() 
                            || ( Auth::check() && !Auth::user()->transaction()->exists() )
                            || ( Auth::check() && Auth::user()->transaction()->exists() 
                                 && !Auth::user()->transaction()->where('category_sub', 'employeeCunsellor')
                            //->whereLike('description', $product6['field']??null)
                            //->where('description', 'like', '%' . $product6['field'] . '%')
                            //->where('description', 'like', '%' . 'dd' . '%')
                            //Since whereLike() isn’t native and caching expects well-defined query structure, use this instead:
                            ->where('description', 'like', '%' . ($product6['field'] ?? '') . '%')
                            ->where('status', 'verify_success')->first())
                            ): ?>
                                 <?php echo $__env->make('livewire.dashboard.student.konkur1404Farhangiyan.financialStatement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                            <?php else: ?>
                                <div class=" col-8 p-2 mb-3   ">
                                    <div class="container">
                                        <div class="row justify-content-center align-content-center">
                                            <button class=" button-82-pushable text-center " role="button"
                                                onclick="Livewire.dispatchTo('auth.sign','counsellorInit', { Page: 'counsellorInit' })">
                                                <span class="button-82-shadow"></span>
                                                <span class="button-82-edge"></span>
                                                <span class="button-82-front text fs-6 ">
                                                    ورود به پنل کاربری دانش‌آموز
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?> 
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>

        </div>
        
        <?php if(0 &&
                null !== Auth::check() &&
                null !== Auth::user() &&
                null !== Auth::user()->farhangiyan() &&
                null !== Auth::user()->farhangiyan()->where('Isfarhangian', 'true') &&
                Auth::user()->farhangiyan->Isfarhangian): ?>
        <?php else: ?>
            <div class=" col-12 p-2 mb-3 d-none ">
                <div class="container">
                    <div class="row justify-content-center align-content-center">
                        <button class="dlPre position-absolute  p-3 w-75  text-center  otto fs-6 "
                            style="bottom: -30%;   right:12%; ; 
                           border-radius:7px; word-spacing: 3px;  
                           background-color:#ffe600;
                           color:rgb(0, 0, 0); border:0;"
                            onclick="Livewire.dispatchTo('auth.sign','farhangianInit', { Page: 'farhangianInit' })">
                            دانلود و دریافت رایگان
                        </button>
                    </div>
                </div>

            </div>
        <?php endif; ?>
    </div>
</div>


<style>
    .rowX {
        --bs-gutter-x: 1.5rem;
        --bs-gutter-y: 0;
        display: flex;
        flex-wrap: wrap;
        margin-top: calc(-1* var(--bs-gutter-y));
        margin-right: calc(-0.5* var(--bs-gutter-x));
        margin-left: calc(-0.5* var(--bs-gutter-x));
    }

    .rowC {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        margin-right: 0px;
        margin-left: 0px;
    }

    a {
        text-decoration: none;
        color: inherit;

    }

    .dlPre {
        border: 2px solid #ddd !important;
        transition: all .3s;
    }

    .dlPre:hover {
        cursor: pointer;
        background-color: rgb(255, 0, 0) !important;
        color: #fff !important;
        border: 2px solid #eee !important;
        text-shadow: 0px 0px 0px !important;

        /* background-color: white; */

    }

    /* #dlPre:hover > button {
         cursor: pointer;
        background-color: aliceblue!important;
         color: inherit!important;
         border:2px solid
 
    } */
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/student/farhangian/7gen_PreShow.blade.php ENDPATH**/ ?>