<?php
    $products6 = [
        'تجربی' => [
            'field' => 'تجربی',
            'color' => 'green',
            'colorBG' => '#568636',
            'جلد' => [
                [
                    'subject' => 'جلد 1',
                    'title' => 'اگر من طراح باشم جلد 1',
                    'descI' => 'مرور و جمع بندی کامل تمامی دروس',
                    'descII' => 'سوالات پیشنهادی و شبیه ساز کنکور سراسری 1404',
                    'descIII' => 'سوالات پیشنهادی و شبیه ساز امتحانات نهایی خرداد 1404',
                    'descIV' => 'سوالات و منابع ازمون اختصاصی فرهنگیان 1404',
                    'poster' => asset('/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-tajrobi.webp'),
                    //sanjeshbonyad-laravel-git\storage\app\public\img\sample-e.jpg
                ],
            ],
        ],
        'ریاضی' => [
            'field' => 'ریاضی',
            'color' => 'red',
            'colorBG' => '#1979017',
            'جلد' => [
                [
                    'subject' => 'جلد 1',
                    'title' => 'اگر من طراح باشم جلد 1',
                    'descI' => 'مرور و جمع بندی کامل تمامی دروس',
                    'descII' => 'سوالات پیشنهادی و شبیه ساز کنکور سراسری 1404',
                    'descIII' => 'سوالات پیشنهادی و شبیه ساز امتحانات نهایی خرداد 1404',
                    'descIV' => 'سوالات و منابع ازمون اختصاصی فرهنگیان 1404',
                    'poster' => asset('/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-riyazi.webp'),
                ],
            ],
        ],
        'انسانی' => [
            'field' => 'انسانی',
            'color' => 'mediumblue',
            'colorBG' => '#46117182',
            'جلد' => [
                [
                    'subject' => 'جلد 1',
                    'title' => 'اگر من طراح باشم جلد 1',
                    'descI' => 'مرور و جمع بندی کامل تمامی دروس',
                    'descII' => 'سوالات پیشنهادی و شبیه ساز کنکور سراسری 1404',
                    'descIII' => 'سوالات پیشنهادی و شبیه ساز امتحانات نهایی خرداد 1404',
                    'descIV' => 'سوالات و منابع ازمون اختصاصی فرهنگیان 1404',
                    'poster' => asset('/storage/Pages/konkur1404Farhangiyan/konkur1404Farhangiyan-ensani.webp'),
                ],
            ],
        ],
    ];
?>
<div class="row">
    <div class="col-md-4">
        <?php echo $__env->make('pages.student.farhangian.7gen_PreShow', ['product6' => $products6['تجربی']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="col-md-4">
        <?php echo $__env->make('pages.student.farhangian.7gen_PreShow', ['product6' => $products6['ریاضی']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="col-md-4">
        <?php echo $__env->make('pages.student.farhangian.7gen_PreShow', ['product6' => $products6['انسانی']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\farhangian\homelock.blade.php ENDPATH**/ ?>