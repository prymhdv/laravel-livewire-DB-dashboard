<?php if(request()->route()->getName() == 'main.operators.employee.adminPanelLivewireRoute' ||
        request()->route()->getName() == 'addNumber.operators.employee.adminPanelLivewireRoute'): ?>
    <div class="row">
        <div class="col-md-12">

            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-4">
                <a class="hover4 d-block justify-items-center align-content-center  " style=" ">
                    افزودن شماره
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    برسی کاربر
                </a> 
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    تغییر شماره
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
               
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
            </div>
            <hr class="m-0">

        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\employee\operator\main.blade.php ENDPATH**/ ?>