<style>
    a:hover {
        cursor: pointer;
    }
</style><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\layoutsII\headStyle.blade.php ENDPATH**/ ?>