<div class=" cardX cardX2 shadow1X ">
    
    <section class="flex slider-area slider-three-area  p-0 m-0">
        <div class="container " style="padding: 5px">
            <div class="col p-0">
                
                

            </div>
            <?php echo $__env->make('pages.home.news', ['$Feeddata' => $Feeddata ?? false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="mt-3 ">
                <div class="col-12 p-0 ">
                    
                    <?php echo $__env->make('pages.employee.counsellor.carousel-Home', ['CCname' => 'side'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                
            </div>

            <div class="row">
                <div class="col-12">
                    <img loading="lazy" class=" " src="<?php echo e(asset('storage/img/f1/SiteBaners-19.png')); ?>"
                        width="100%" alt="اطلاعیه ویژه داوطلبان کنکور">
                </div>
            </div>
        </div>

    </section>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\side.blade.php ENDPATH**/ ?>