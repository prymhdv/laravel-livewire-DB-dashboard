<div id="carouselExampleFade" class="carousel slide carousel-fade mt-2 p-0 d-none d-lg-block" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php
        $numbers = range(41, 43);
        shuffle($numbers);
        $last = array_pop($numbers);
        $numbers[] = $last;
        foreach ($numbers as $index => $i) {
            $active = $index === 0 ? 'active' : '';
            echo '<div class="carousel-item ' . $active . '"> <img   fetchpriority="high" class="d-block w-100 " src="' . asset('storage/main/student/takhmin/banners/desktop/s') . $i . '.webp" alt="' . $i . ' پشتیبانی انتخاب رشته بنیادسنجش"></div>';
        }
        ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>



<div id="carouselExampleFadeII" class="carousel slide carousel-fade p-0 mt-2 d-block d-lg-none" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php
        $numbers = range(44, 46);
        shuffle($numbers);
        $last = array_pop($numbers);
        $numbers[] = $last;
        foreach ($numbers as $index => $i) {
            $active = $index === 0 ? 'active' : '';
            echo '<div class="carousel-item ' . $active . '"> <img   fetchpriority="high" class="d-block w-100 " src="' . asset('storage/main/student/takhmin/banners/mobile/s') . $i . '.webp" alt="' . $i . ' پشتیبانی انتخاب رشته بنیادسنجش"></div>';
        }
        ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFadeII" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFadeII" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>


<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\takhminRotbe\banner.blade.php ENDPATH**/ ?>