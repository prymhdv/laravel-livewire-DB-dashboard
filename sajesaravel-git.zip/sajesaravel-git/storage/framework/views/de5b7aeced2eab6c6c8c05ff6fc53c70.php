
<?php $__env->startSection('pageTitle', $blogPost->title); ?>
<?php $__env->startSection('content'); ?>
    

    <div class="row justify-content-center align-items-center g-2">
        <a wire:navigate href="<?php echo e(route('show.blog.Route')); ?>" class="col-6 btn btn-warning text-center p-2">
            بازگشت به وبلاگ
        </a> 
    </div>


    <?php echo $__env->make('blog.detiledItems', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('headerSub'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\blog\detile.blade.php ENDPATH**/ ?>