<body class="w-100 px-0 "
    style=" width: 100%!important; 
            max-width: 100%!important; 
            min-width: 100%!important;
            overflow-x:hidden;
            min-height: 100vh;
            direction:ltr;
            background: linear-gradient(135deg, #eee 0, #eee 78%, #eee 100%);
            ">
     
    <div class="container-fluid" style="direction:rtl;">
        <div class="row">
            <div class="col-12 px-0">
                <?php if(auth()->guard()->check()): ?>
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.sign', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1151997103-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endif; ?>
                
                <?php if(auth()->guard()->guest()): ?>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.sign', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1151997103-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endif; ?>
                <div id="XOISSSS" class="container-fluid p-0">
                    <div class="row justify-content-center align-content-center">
                        <?php $__env->startSection('header'); ?>
                            <?php echo $__env->make('pages.prymhdv.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php echo $__env->yieldSection(); ?>
                        <?php $__env->startSection('alert'); ?>
                            
                            <?php echo $__env->make('pages.partials.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->yieldSection(); ?>
                        
                        <div id="XOIS" class="container-fluid container-xl overflow-hidden w-100 p-0">
                            <div class="row justify-content-center align-content-center">
                                <div class="col-12 p-0">
                                    <?php echo $__env->yieldContent('content'); ?>
                                     <?php echo e($slot??''); ?>

                                </div>
                            </div>
                        </div>
                        

                    </div>
                </div>

                
                <?php echo $__env->make('pages.partials.Menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                
                <!-- Include Livewire Scripts -->
                <?php echo $__env->make('pages.layouts.bodyScript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('components.prymhdvAssets.js.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

            </div>
        </div>
    </div>
    
    <?php $__env->startSection('footer'); ?>
        <?php echo $__env->make('pages.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
    <?php echo $__env->make('pages.layouts.share', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/body.blade.php ENDPATH**/ ?>