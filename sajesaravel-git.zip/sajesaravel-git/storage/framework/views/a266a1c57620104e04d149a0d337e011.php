<div class="container-fluid mb-3 mt-1 fs-3 p-0" style="direction: rtl;">
    
    <div class=" p-0 py-2 justify-content-around  text-nowrap  shadow1 position-relative  text-center"
        style="background-color: #ddd0; border-radius:7px;   ">


        <?php echo $__env->make('livewire.dashboard.admin.userSectionEmployee', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('livewire.dashboard.admin.userSectionStudent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('livewire.dashboard.admin.userSectionCallCenter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('livewire.dashboard.admin.userSectionUsers', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('livewire.dashboard.admin.userSectionBlogs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
</div>
<style>
    .bandX {
        background-color: green;
        width: 10px;
        height: 100%;
        right: -4px;
        top: 0px;
        opacity: 0.7;
    }

    .card-userSection-active {
        background-color: darkslategrey !important;
        color: aliceblue !important;
        border: 0;
    }

    .card-userSection-active .bandX {
        background-color: #0080f7;
        width: 10px;
        height: 100%;
        right: -4px;
        top: 0px;
        opacity: 0.7;
    }

    .card-userSection-active .container .col svg {

        color: aliceblue !important;
    }
    .card-userSection-active div span span{
        color:#00ff00!important;
    }
  
    .card-userSection {
        text-decoration: none;
        user-select: none;
        width: 100%;
        transition: all 0.3s ease-in-out 0s;
    }

    .card-userSection:hover {
        cursor: pointer;
        background-color: darkslategrey;
        color: aliceblue;
        border: 0;

    }
    .card-userSection:hover div span span{
        color:#00ff00!important;
    }

    .card-userSection:hover .container .col svg {

        color: aliceblue !important;
    }

    .card-userSection:active {
        /* cursor: pointer; */
        background-color: darkslategrey;
        color: aliceblue;
    }




    .card-userSection:hover .bandX {
        background-color: #0080f7;
        width: 10px;
        height: 100%;
        right: -4px;
        top: 0px;
       
    }
</style>
<script>
    $(document).ready(function() {
        // alert("ggg"); 
        // $('.item-nav-link').click(function(event) { 
        //     event.preventDefault(); 
        //     wire:ref
        //     // ------------------------------
        //     $('.MaincontentBanner').children().each(function() {$(this).css('opacity', '0.2');});livewire.dashboard.konkur1404Farhangiyan.banner
        //     $('.Maincontent').load($(this).attr('href'), function(response, status, xhr) {
        //         if (status == "success") {$('.Maincontent').css('opacity', '1');} 
        //         else {$('.Maincontent').css('opacity', '0.2');}
        //     });
        //     // ------------------------------
        //     $('.Maincontent').children().each(function() {$(this).css('opacity', '0.2');});
        //     $('.Maincontent').load($(this).attr('href'), function(response, status, xhr) {
        //         if (status == "success") {$('.Maincontent').css('opacity', '1');} 
        //         else {$('.Maincontent').css('opacity', '0.2');}
        //     });
        // });

    });
</script>
<style>
    .fontBold {
        font-weight: bold;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\userSection.blade.php ENDPATH**/ ?>