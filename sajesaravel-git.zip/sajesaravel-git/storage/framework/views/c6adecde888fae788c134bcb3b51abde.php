 

 <!-- SweetAlert2 -->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>

 <div class="F9525">
     <?php if(Session::has('success')): ?>
     <?php endif; ?>
     <?php if(Session::has('error')): ?>
     <?php endif; ?>
     <?php if(Session::has('warning')): ?>
     <?php endif; ?>
     <?php if(Session::has('error')): ?>
     
     <?php endif; ?>
 </div>


 <style>
     .F9525 {
         background-color: aliceblue;
         background-color: rgb(0, 0, 0);
         font-family: sans-serif;
         text-align: center;
     }

     .F9525 button {
         background-color: cadetblue;
         color: whitesmoke;
         border: 0;
         -webkit-box-shadow: none;
         box-shadow: none;
         font-size: 18px;
         font-weight: 500;
         border-radius: 7px;
         padding: 15px 35px;
         cursor: pointer;
         white-space: nowrap;
         margin: 10px;
     }

     .F9525 img {
         width: 120px;
     }

     .F9525 input[type="text"] {
         padding: 12px 20px;
         display: inline-block;
         border: 1px solid #ccc;
         border-radius: 7px;
         box-sizing: border-box;
     }

     .F9525 h1 {
         border-bottom: solid 2px grey;
     }

     .F9525 #success {
         background: green;
     }

     .F9525 #error {
         background: red;
     }

     .F9525 #warning {
         background: coral;
     }

     .F9525 #info {
         background: cornflowerblue;
     }

     .F9525 #question {
         background: grey;
     }
 </style>

 <script>
     // Alert Modal Type
     $(document).on('click', '#success', function(e) {
         swal(
             'Success',
             'You clicked the <b style="color:green;">Success</b> button!',
             'success'
         )
     });

     $(document).on('click', '#error', function(e) {
         swal(
             'Error!',
             'You clicked the <b style="color:red;">error</b> button!',
             'error'
         )
     });

     // $(document).on('click', '#warning', function(e) 
     <?php if(Session::has('warning')): ?> 
         $(document).ready(function(e) {
             swal(
                 'هشدار!',
                 '<b style="color:coral; " class=" fs-9 font-bold font-iransans"> <?php echo e(Session::get("warning")); ?> </b>',
                 "warning"
             )
         });
     <?php endif; ?>
     $(document).on('click', '#info', function(e) {
         swal(
             'Info!',
             'You clicked the <b style="color:cornflowerblue;">info</b> button!',
             'info'
         )
     });

     $(document).on('click', '#question', function(e) {
         swal(
             'Question!',
             'You clicked the <b style="color:grey;">question</b> button!',
             'question'
         )
     });

     // Alert With Custom Icon and Background Image
     $(document).on('click', '#icon', function(event) {
         swal({
             title: 'Custom icon!',
             text: 'Alert with a custom image.',
             imageUrl: 'https://image.shutterstock.com/z/stock-vector--exclamation-mark-exclamation-mark-hazard-warning-symbol-flat-design-style-vector-eps-444778462.jpg',
             imageWidth: 200,
             imageHeight: 200,
             imageAlt: 'Custom image',
             animation: false
         })
     });

     $(document).on('click', '#image', function(event) {
         swal({
             title: 'Custom background image, width and padding.',
             width: 700,
             padding: 150,
             background: '#fff url(https://image.shutterstock.com/z/stock-vector--exclamation-mark-exclamation-mark-hazard-warning-symbol-flat-design-style-vector-eps-444778462.jpg)'
         })
     });

     // Alert With Input Type
     $(document).on('click', '#subscribe', function(e) {
         swal({
             title: 'Submit email to subscribe',
             input: 'email',
             inputPlaceholder: 'Example@email.xxx',
             showCancelButton: true,
             confirmButtonText: 'Submit',
             showLoaderOnConfirm: true,
             preConfirm: (email) => {
                 return new Promise((resolve) => {
                     setTimeout(() => {
                         if (email === 'example@email.com') {
                             swal.showValidationError(
                                 'This email is already taken.'
                             )
                         }
                         resolve()
                     }, 2000)
                 })
             },
             allowOutsideClick: false
         }).then((result) => {
             if (result.value) {
                 swal({
                     type: 'success',
                     title: 'Thank you for subscribe!',
                     html: 'Submitted email: ' + result.value
                 })
             }
         })
     });

     // Alert Redirect to Another Link
     $(document).on('click', '#link', function(e) {
         swal({
                 title: "Are you sure?",
                 text: "You will be redirected to https://utopian.io",
                 type: "warning",
                 confirmButtonText: "Yes, visit link!",
                 showCancelButton: true
             })
             .then((result) => {
                 if (result.value) {
                     window.location = 'https://utopian.io';
                 } else if (result.dismiss === 'cancel') {
                     swal(
                         'Cancelled',
                         'Your stay here :)',
                         'error'
                     )
                 }
             })
     });
 </script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partials\alert.blade.php ENDPATH**/ ?>