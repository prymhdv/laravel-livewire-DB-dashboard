 <div class="col-md-12 p-0 mt-2 main_content">
     <div class="content-wrapper row p-0"
         style=" 
        border-radius: 7px;  
        background: linear-gradient(135deg, #e1e1e158 0, #dadadac6 78%, #e9e9e979 100%);
            box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset;
        ">

         <div id="carouselExampleFade" class="carousel slide carousel-fade p-0 d-none d-lg-block" data-bs-ride="carousel">
             <div class="carousel-inner">
                 <?php
                 // $numbers = range(1, 5);
                 // $numbers = array_diff($numbers, [3]);
                 // shuffle($numbers);
                 // $last = array_pop($numbers);
                 // $numbers[] = $last;
                 // foreach ($numbers as $index => $i) {
                 //     $active = $index === 1 ? 'active' : '';
                 //     echo '<div class="carousel-item ' .
                 //         $active . '"> <img loading="eager" class="d-block w-100 " src="' .
                 //         asset('storage/main/home/banners/desktop/s') . $i .
                 //         '.webp" alt="' . $i . ' صفحه نخست  بنیادسنجش"></div>';
                 // }
                 ?>
                 <div class="carousel-item active "> <img loading="eager" class="d-block w-100 "
                         src="<?php echo e(asset('storage/main/home/banners/desktop/s1.webp')); ?>" alt="صفحه نخست  بنیادسنجش">
                 </div>
                 <a class="carousel-item "  href="<?php echo e(route('takhminRotbe.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/desktop/s2.webp')); ?>" alt="صفحه نخست  بنیادسنجش| تخمین رتبه">
                 </a>
                 <a class="carousel-item "  href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/desktop/s4.webp')); ?>" alt="صفحه نخست  بنیادسنجش| امتحانات">
                 </a>
                 <a class="carousel-item " href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/desktop/s5.webp')); ?>" alt="صفحه نخست  بنیادسنجش| امتحانات">
                 </a>
             </div>
             <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade"
                 data-bs-slide="prev">
                 <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Previous</span>
             </button>
             <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade"
                 data-bs-slide="next">
                 <span class="carousel-control-next-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Next</span>
             </button>
         </div>

         

         <div id="carouselExampleFadeII" class="carousel slide carousel-fade p-0  d-block d-lg-none"
             data-bs-ride="carousel">
             <div class="carousel-inner">
                 <?php
                //  $numbers = range(1, 5);
                //  $numbers = array_diff($numbers, [3]);
                //  shuffle($numbers);
                //  $last = array_pop($numbers);
                //  $numbers[] = $last;
                //  foreach ($numbers as $index => $i) {
                //      $active = $index === 1 ? 'active' : '';
                //      echo '<div class="carousel-item ' . $active . '"> <img loading="eager" class="d-block w-100 " src="' . asset('storage/main/home/banners/mobile/s') . $i . '.webp" alt="' . $i . ' صفحه نخست  بنیادسنجش"></div>';
                //  }
                 ?>
                  <div class="carousel-item active "> <img loading="eager" class="d-block w-100 "
                         src="<?php echo e(asset('storage/main/home/banners/mobile/s1.webp')); ?>" alt="صفحه نخست  بنیادسنجش">
                 </div>
                 <a class="carousel-item "  href="<?php echo e(route('takhminRotbe.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/mobile/s2.webp')); ?>" alt="صفحه نخست  بنیادسنجش| تخمین رتبه">
                 </a>
                 <a class="carousel-item "  href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/mobile/s4.webp')); ?>" alt="صفحه نخست  بنیادسنجش| امتحانات">
                 </a>
                 <a class="carousel-item " href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"> <img loading="eager" class="d-block w-100 " 
                         src="<?php echo e(asset('storage/main/home/banners/mobile/s5.webp')); ?>" alt="صفحه نخست  بنیادسنجش| امتحانات">
                 </a>
             </div>
             <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFadeII"
                 data-bs-slide="prev">
                 <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Previous</span>
             </button>
             <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFadeII"
                 data-bs-slide="next">
                 <span class="carousel-control-next-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Next</span>
             </button>
         </div>

     </div>
 </div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/home/banner.blade.php ENDPATH**/ ?>