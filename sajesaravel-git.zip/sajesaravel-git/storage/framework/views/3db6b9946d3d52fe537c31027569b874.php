<div class="main-content side-content pt-0">
    <div class="container-fluid">
        <div class="inner-body">
            <!-- Page Header -->
            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card custom-card overflow-hidden">
                        <div class="card-body">
                            <div>
                                <h4 class="main-content-label mb-1">دانش‌آموزان تخصیص داده شده</h4>

                            </div>
                            <div class="table-responsive p-2 mt-3">
                                <?php
                                    // $items = Auth::user()->::paginate(5);
                                    $items = \App\Models\User::paginate(5);
                                    // $items = \App\Models\User::simplePaginate(7);
                                    // $items = \App\Models\User::cursorPaginate(6);
                                ?>
                                <?php if(0): ?>
                                    <div class="alert alert-danger mg-b-10" role="alert">
                                        <strong>دانش‌آموز وجود ندارد!</strong>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted card-sub-title">با کلیک روی نام مخاطب وارد صفحه مشخصات وی شوید
                                    </p>
                                    <table id="exportexample"
                                        class="table table-bordered border-t0 key-buttons text-nowrap w-100">
                                        <thead>
                                            <tr>
                                                <th>نام و نام خانوادگی</th>
                                                <th>موبایل</th>
                                                <th>نوع مشاوره</th>
                                                <th>رشته</th>
                                                <th>وضعیت</th>
                                            </tr>
                                        </thead>

                                        
                                        <tbody>
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <tr <?php echo e($bg = 0); ?>>
                                                    <td> <a href="#"> <?php echo e($item->nameFirst); ?> <?php echo e($item->nameLast); ?>

                                                        </a></td>
                                                    <td> <?php echo e($item->mobile); ?> </td>
                                                    <td> <?php echo e($item->access); ?> </td>
                                                    <td> <?php echo e($item->access); ?> </td>
                                                    <td> <?php echo e($item->access); ?> </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <div class="div" style="direction:ltr">
                                        <?php echo e($items->links()); ?>

                                    </div>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
    </div>
</div>
<style>
    .table tr:hover td {
        background-color: #c9ceda;

    }

    .table {
        width: 100%;
        margin-bottom: 1rem;
        border-radius: 12px !important;
        border: 2px solid #000000;
    }

    .table tr:nth-child(even) td {
        background: rgba(223, 223, 223, 0.6);
    }

    .table td,
    .table th {
        padding: .75rem;
        vertical-align: middle
    }

    .table thead th {
        vertical-align: bottom;
        border-bottom: 1px solid #e8e8f7
    }

    .table tbody+tbody {
        border-top: 1px solid #e8e8f7
    }

    .table-sm td,
    .table-sm th {
        padding: .3rem
    }

    .table-bordered,
    .table-bordered td,
    .table-bordered th {
        border: 1px solid #e8e8f7
    }

    .table-bordered thead td,
    .table-bordered thead th {
        border-bottom-width: 2px
    }

    .table-borderless tbody+tbody,
    .table-borderless td,
    .table-borderless th,
    .table-borderless thead th {
        border: 0
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, .05)
    }

    .table-hover tbody tr:hover {
        background-color: #f8f8ff
    }

    .table-primary,
    .table-primary>td,
    .table-primary>th {
        background-color: #c6d4ff
    }

    .table-primary tbody+tbody,
    .table-primary td,
    .table-primary th,
    .table-primary thead th {
        border-color: #95afff
    }

    .table-hover .table-primary:hover,
    .table-hover .table-primary:hover>td,
    .table-hover .table-primary:hover>th {
        background-color: #adc1ff
    }

    .table-secondary,
    .table-secondary>td,
    .table-secondary>th {
        background-color: #d9dde5
    }

    .table-secondary tbody+tbody,
    .table-secondary td,
    .table-secondary th,
    .table-secondary thead th {
        border-color: #b9c1ce
    }

    .table-hover .table-secondary:hover,
    .table-hover .table-secondary:hover>td,
    .table-hover .table-secondary:hover>th {
        background-color: #cacfdb
    }

    .table-success,
    .table-success>td,
    .table-success>th {
        background-color: #c8e9b8
    }

    .table-success tbody+tbody,
    .table-success td,
    .table-success th,
    .table-success thead th {
        border-color: #99d67b
    }

    .table-hover .table-success:hover,
    .table-hover .table-success:hover>td,
    .table-hover .table-success:hover>th {
        background-color: #b9e3a5
    }

    .table-info,
    .table-info>td,
    .table-info>th {
        background-color: #bee5eb
    }

    .table-info tbody+tbody,
    .table-info td,
    .table-info th,
    .table-info thead th {
        border-color: #86cfda
    }

    .table-hover .table-info:hover,
    .table-hover .table-info:hover>td,
    .table-hover .table-info:hover>th {
        background-color: #abdde5
    }

    .table-warning,
    .table-warning>td,
    .table-warning>th {
        background-color: #ffeeba
    }

    .table-warning tbody+tbody,
    .table-warning td,
    .table-warning th,
    .table-warning thead th {
        border-color: #ffdf7e
    }

    .table-hover .table-warning:hover,
    .table-hover .table-warning:hover>td,
    .table-hover .table-warning:hover>th {
        background-color: #ffe8a1
    }

    .table-danger,
    .table-danger>td,
    .table-danger>th {
        background-color: #f5c6cb
    }

    .table-danger tbody+tbody,
    .table-danger td,
    .table-danger th,
    .table-danger thead th {
        border-color: #ed969e
    }

    .table-hover .table-danger:hover,
    .table-hover .table-danger:hover>td,
    .table-hover .table-danger:hover>th {
        background-color: #f1b0b7
    }

    .table-light,
    .table-light>td,
    .table-light>th {
        background-color: #fcfcfd
    }

    .table-light tbody+tbody,
    .table-light td,
    .table-light th,
    .table-light thead th {
        border-color: #f9fafb
    }

    .table-hover .table-light:hover,
    .table-hover .table-light:hover>td,
    .table-hover .table-light:hover>th {
        background-color: #ededf3
    }

    .table-dark,
    .table-dark>td,
    .table-dark>th {
        background-color: #c8ccd3
    }

    .table-dark tbody+tbody,
    .table-dark td,
    .table-dark th,
    .table-dark thead th {
        border-color: #99a0ae
    }

    .table-hover .table-dark:hover,
    .table-hover .table-dark:hover>td,
    .table-hover .table-dark:hover>th {
        background-color: #babfc8
    }

    .table-active,
    .table-active>td,
    .table-active>th,
    .table-hover .table-active:hover,
    .table-hover .table-active:hover>td,
    .table-hover .table-active:hover>th {
        background-color: rgba(0, 0, 0, .075)
    }

    .table .thead-dark th {
        color: #fff;
        background-color: #3b4863;
        border-color: #49597b
    }

    .table .thead-light th {
        color: #3c4858;
        background-color: #f0f0ff;
        border-color: #f0f0ff
    }

    .table-dark {
        color: #fff;
        background-color: #3b4863
    }

    .table-dark td,
    .table-dark th,
    .table-dark thead th {
        border-color: #49597b
    }

    .table-dark.table-bordered {
        border: 0
    }

    .table-dark.table-striped tbody tr:nth-of-type(odd) {
        background-color: hsla(0, 0%, 100%, .05)
    }

    .table-dark.table-hover tbody tr:hover {
        color: #fff;
        background-color: hsla(0, 0%, 100%, .075)
    }

    @media (max-width: 575.98px) {
        .table-responsive-sm {
            display: block;
            width: 100%;
            overflow-x: scroll;
            -webkit-overflow-scrolling: touch
        }

        .table-responsive-sm>.table-bordered {
            border: 0
        }
    }

    @media (max-width: 767.98px) {
        .table-responsive-md {
            display: block;
            width: 100%;
            overflow-x: a;
            -webkit-overflow-scrolling: touch
        }

        .table-responsive-md>.table-bordered {
            border: 0
        }
    }

    @media (max-width: 991.98px) {
        .table-responsive-lg {
            display: block;
            width: 100%;
            overflow-x: scroll;
            -webkit-overflow-scrolling: touch
        }

        .table-responsive-lg>.table-bordered {
            border: 0
        }
    }

    @media (max-width: 1199.98px) {
        .table-responsive-xl {
            display: block;
            width: 100%;
            overflow-x: scroll;
            -webkit-overflow-scrolling: touch
        }

        .table-responsive-xl>.table-bordered {
            border: 0
        }
    }

    .table-responsive {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch
    }

    .table-responsive>.table-bordered {
        border: 0
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employeed\tableStudent.blade.php ENDPATH**/ ?>