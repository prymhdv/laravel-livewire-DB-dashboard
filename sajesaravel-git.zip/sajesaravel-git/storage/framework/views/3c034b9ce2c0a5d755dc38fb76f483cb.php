<style>
    /*
@media not|only mediatype and (mediafeature and|or|not mediafeature)
    {
        CSS-Code;
    }
10px = 0.625rem
12px = 0.75rem
14px = 0.875rem
16px = 1rem (base)
18px = 1.125rem
20px = 1.25rem
24px = 1.5rem
30px = 1.875rem
32px = 2rem
*/

    :root {
        text-rendering: optimizeSpeed !important;
        --color_violate: #7301f7;
        --color_blue: #007bff;
        --color_yellow: #f9a603;
        --color_sanjesh_red: #9f3030;
        --color_sanjesh_blue: #303f9f;
        --color_sanjesh_green: #4daf50;

    }

    html,
    body {
        line-height: 1.15;
        line-height: normal;
        -ms-text-size-adjust: 100%;
        -webkit-text-size-adjust: 100%;
        scroll-behavior: smooth;
        height: 100%;
        width: 100%;

        align-items: center;
        justify-content: center;
    }

    .shadowin {
        box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;
    }

    .pry-border1 {
        /* border: 2px solid #ddd; */
        border-radius: 7px;
        overflow: hidden;
        /*box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 1px,
            rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;*/
    }

    .pry-border4 {
        /* border: 2px solid #ddd; */
        border-radius: 4px;
        overflow: hidden;
        box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 1px,
            rgba(60, 64, 67, 0.15) 0px 1px 3px 1px; 
    }

  
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\prymhdvAssets\css\style.blade.php ENDPATH**/ ?>