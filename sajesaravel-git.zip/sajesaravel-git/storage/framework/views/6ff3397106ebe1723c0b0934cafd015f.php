 <a id="entekhabReshteClick" class=" d-flex px-2 rotate-button2 shadow1 align-content-center justify-content-center"
     
     <?php if(Auth::check() &&
             Auth::User() &&
             Auth::User()->student()->exists() &&
             Auth::User()->student->fieldSelection()->exists()): ?> 
         href="<?php echo e(route('fieldSelection.DashboardStudentLivewireRoute',['state'=>'all'])); ?>" wire:navigate
        <?php else: ?>
            wire:navigate href="<?php echo e(route('entekhabReshte.index.Route')); ?>" <?php endif; ?>
     style="color:white;cruser:pointer;font-weight:600;border-radius:12px;"><img
         src="<?php echo e(asset('storage/main/home/services/Icon-04.webp')); ?>" class=" p-1 px-2 " loading="lazy"
         style="width: 50px; ">
     <span class="align-content-center text-wrap fs-4">
         <?php if(Auth::check() &&
                 Auth::User() &&
                 Auth::User()->student()->exists() &&
                 Auth::User()->student->fieldSelection()->exists()): ?>
             پنل انتخاب رشته
             <?php echo e(Auth::User()->student->fieldSelection->type ?? ''); ?>

         <?php else: ?>
             ثبت نام و رزرو انتخاب رشته تخصصی بنیاد سنجش
         <?php endif; ?>
     </span>
 </a>
 <style>
     #entekhabReshteClick {
         transform: scale(1);
         transition: all 0.3s ease-in-out 0s;
         cursor: pointer;

         background-color: #1c8001 !important;
         border: 2px solid #1c8000 !important;
         ;
     }

     #entekhabReshteClick:hover {
         transform: scale(1);
         background-color: #2fcf03 !important;
         border: 2px solid #2cc501 !important;
         ;
     }
 </style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\regBtn.blade.php ENDPATH**/ ?>