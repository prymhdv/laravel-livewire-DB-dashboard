
<?php $__env->startSection('pageTitle', 'ثبت نام فرهنگیان'); ?>
<?php $__env->startSection('content'); ?>

    <?php
    if(1)
   {  //
      //$products = $products->GetBookList();
      //$products =   ;
      //dd('---',App\Models\Products\Product::where('pphysical','1')->first(),App\Models\Products\Product::all());
    }
    
    $_SESSION['error']                  = null;
    $_SESSION['validation']             = null;
    $_SESSION['success']                = null;
    $_SESSION['warning']                = null;


    $_SESSION['cusername']              = null;
    $_SESSION['counselorverify']        = null;
    $_SESSION['contactfname']           = null;
    $_SESSION['contactlname']           = null;
    $_SESSION['contactmcode']           = null;
    $_SESSION['contactphone']           = null;
 
    $products =App\Models\Products\Product::all();
    $products =App\Models\Products\Product::where('pphysical',1)->get();
    ?>

<main class="container" style="
/* margin-top:60px; */
 ">
    <section class="slider-area slider-three-area mt-1 d-none">
        <div class="container">
            <!-- <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/اگرمنطراحباشمتوضیحات-02.jpg" width="100%" alt="نماد اعتماد الکترونیکی">
                </div>
            </div> -->
            <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/اگرمنطراحباشمتوضیحات-03.jpg" width="100%" alt="نماد اعتماد الکترونیکی" class="pry-border1">
                </div>
            </div>
            <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/اگرمنطراحباشمتوضیحات-04.jpg" width="100%" alt="نماد اعتماد الکترونیکی" class="pry-border1">
                </div>
            </div>
            <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/اگرمنطراحباشمتوضیحات-05.jpg" width="100%" alt="نماد اعتماد الکترونیکی" class="pry-border1">
                </div>
            </div>
            <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/اگرمنطراحباشمتوضیحات-06.jpg" width="100%" alt="نماد اعتماد الکترونیکی" class="pry-border1">
                </div>
            </div>
            <div class="row mb-50">
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/enamad.jpg" width="100%" alt="نماد اعتماد الکترونیکی" class="pry-border1">
                </div>
                <div class="col-12">
                    <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/پشتیبانی.jpg" width="100%" alt="زمانبندی های کنکور فرهنگیان" class="pry-border1">
                </div>
            </div>
        </div>
    </section>
    <section>
     <?php echo $__env->make('pages.farhangian.carousel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>





    <section class="slider-area slider-three-area pt-100 pb-100 d-none">
        <div class="container">
            <h3 class="text-center">
                بخشی از کارنامه های درخشان بنیادسنجش در انتخاب رشته فرهنگیان سال های قبل
            </h3>
            <div class="row">
                <div class="col-12">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="11"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="10"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="9"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img loading="lazy"class="d-block w-100 pry-border1 " src="<?php echo e(asset('')); ?>/storage/assets/img/Farhangian-01.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>/storage/assets/img/Farhangian-02.jpg" alt="آزمون 8 دی">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-04.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-05.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-6.jpg" alt="آزمون 8 دی">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-07.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-08.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-09.jpg" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-10.jpg" alt="آزمون 8 دی">
                            </div>
                            <div class="carousel-item">
                                <img loading="lazy"class="d-block w-100 pry-border1" src="<?php echo e(asset('')); ?>storage/assets/img/Farhangian-11.jpg" alt="Third slide">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="shop-details-area pt-80 pb-80">
        <div class="container">
            <h3 class="text-center">
                زمانبندی های کنکور فرهنگیان
            </h3>
            <div class="row align-items-center pt-40">
                <img loading="lazy"src="<?php echo e(asset('')); ?>/storage/assets/img/Farhangiansite-06.jpg" width="100%" alt="زمانبندی های کنکور فرهنگیان" class="pry-border1">
                <!-- <p class="pt-80 pb-80" style="font-size: x-large; line-height: normal;">
                    بر حسب زمان بندی جدید <strong style="color: #ff0000;">دانشگاه های فرهنگیان، انتخاب رشته این دانشگاه در اواخر دی ماه 1402 ، انجام می پذیرد.</strong> لذا جهت انجام انتخاب رشته و اطلاع از نحوه فرآیند ارزشیابی شایستگی معلمی و همچنین اطلاع از نحوه طراحی و سبک سوالات کنکور فرهنگیان از منابع جدید اعلامی از سوی <strong style="color: #ff0000;">سازمان سنجش آموزش کشور</strong>(کتاب مهارت های معلمی ، استعداد و هوش معلمی و دین و زندگی دوره دوم متوسطه ) و نیز آشنایی با سوالات گزینش و مصاحبه تخصصی دانشگاه های فرهنگیان فرم فوق را با دقت تکمیل نمایید.
                </p> -->
            </div>
        </div>
    </section>

    <section class="slider-area slider-three-area pt-110 pb-110">
        <div class="container" style="padding: 1px">
            <img loading="lazy"src="<?php echo e(asset('')); ?>/assets/img/warning.jpg" width="100%" alt="" class="pry-border1">

            <!-- <div class="text-center mt-20 mb-20">
                <h3>خدمات ویژه بنیاد سنجش ویژه آزمون اختصاصی فرهنگیان – 1403</h3>
            </div>
            <div class="row mb-30">
                <ul>
                    <li>
                        1) انجام انتخاب رشته اصولی دانشگاه فرهنگیان با بالاترین احتمال قبولی
                    </li>
                    <li>
                        2) ارائه کتاب اگر من طراح باشم ، جلد ویژه کنکور اختصاصی فرهنگیان شامل خلاصه منابع و سوالات شبیه ساز (مهارت های معلمی ، هوش و استعداد معلمی و دین و زندگی دوره دوم متوسطه)
                    </li>
                    <li>
                        3) ارائه کتاب اگر من طراح باشم، جلد ویژه آمادگی برای جلسه تخصصی مصاحبه و گزینش (شامل نمونه سوالات و مباحث جلسه مصاحبه و نحوه برخورد و رفتار های مناسب جلسه گزینش)
                    </li>
                    <li>
                        4) کتاب اگر من طراح باشم، ویژه مرور و جمع بندی (شامل مرور و جمع بندی کامل کنکور و امتحانات نهایی در سه رشته اصلی تجربی ، ریاضی و انسانی، همراه با سوالات شبیه ساز امتحانات نهایی)
                    </li>
                </ul>
            </div> -->
        </div>
    </section>

    <section class="shop-details-area pt-110">
        <div class="container" id="status">

            <?php
            if (isset($error) || isset($_SESSION['error'])) {
                if (isset($_SESSION['error'])) {
                    $error = $_SESSION['error'];
                }
                echo '<div class="alert alert-danger mg-b-10" role="alert">
                                <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <strong>' . $error . '</strong>';
                if (isset($_SESSION['validation'])) {
                    echo '<ul>';
                    foreach ($_SESSION['validation'] as $validation) {
                        echo '<li>' . $validation . '</li>';
                    }
                    echo '</ul>';
                }
                echo '</div>';
            }
            if (isset($success) || isset($_SESSION['success'])) {
                if (isset($_SESSION['success'])) {
                    $success = $_SESSION['success'];
                }
                echo '<div class="alert alert-success mg-b-10" role="alert">
                                <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <strong>' . $success . '</strong>
                            </div>';
            }
            if (isset($warning) || isset($_SESSION['warning'])) {
                if (isset($_SESSION['warning'])) {
                    $warning = $_SESSION['warning'];
                }
                echo '<div class="alert alert-warning mg-b-10" role="alert">
                                <button aria-label="بستن" class="close pull-left" data-dismiss="alert" type="button">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <strong>' . $warning . '</strong>
                            </div>';
            }
            ?>
        </div>
    </section>

    <!-- <section class="shop-details-area pb-80">
        <div class="container">
            <div class="text-center mt-20 mb-20">
                <h3 style="color: #ff0000;">ویژگی های بسته اگر من طراح باشم</h3>
            </div>

            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="">
                        ثبت نام در انتخاب رشته تخصصی دانشگاه های فرهنگیان و نیز دریافت کتاب اگر من طراح باشم ویژه کنکور اختصاصی فرهنگیان 1403 شامل دفترچه سوالات شبیه ساز منابع اعلامی از سوی سازمان سنجش آموزش کشور (شامل کتاب مهارت های معلمی ، هوش و استعداد معلمی و دین و زندگی دوره دوم متوسطه) و نیز سوالات شبیه ساز جهت جلسه تخصصی گزینش و مصاحبه و نحوه برخورد و پاسخگویی صحیح به سوالات جلسه گزینش و همچنین کتاب اگر من طراح باشم ویژه مرور و جمع بندی کامل کنکور و امتحانات نهایی همراه با نمونه سوالات پیشنهادی طراحان برای امتحانات نهایی.
                    </p>

                </div>
                <div class="col-md-6">
                    <div class="alert alert-danger mg-b-10" role="alert">
                        <strong> ظرفیت انتخاب رشته اصولی بنیاد سنجش و تیراژ چاپی کتاب های اگر من طراح باشم (دفترچه سوالات شبیه ساز آزمون تخصصی فرهنگیان و ...) صرفا 1000 نفر بوده و در صورت اتمام ظرفیت ، بنیاد سنجش هیچ گونه مسئولیتی در قبال افزایش ظرفیت نخواهد داشت.
                        </strong>
                    </div>

                </div>
            </div>
        </div>
    </section> -->

    <section class="shop-details-area pb-120">

        <?php
        foreach ($products as $product) {
        ?>
            <div class="container">
                <div class="row mb-80 mt-80">
                    <div class="col-md-5">
                        <div class="details-thumb-wrap mb-20">
                            <div class="tab-content" id="myTabContentS">
                                <?php
                                $aria_lableledby = ['first-img-thumb', 'second-img-thumb', 'third-img-thumb', 'fourth-img-thumb'];
                                $id = ['first-img', 'second-img', 'third-img', 'fourth-img']
                                ?>
                                <?php
                                try {
                                    $productimg = explode('/*', $product['ppic']);
                                
                                foreach ($productimg as $img => $proimg) {
                                    if  ($img == 0) {$active = 'show active';} else {$active = '';}
                                    $fdvc = `<div class="tab-pane fade {$active}" id="{$product['pid']}{$id[$img]}" role="tabpanel" aria-labelledby="{$product['pid']}{$id[$img]}-thumb"> <div class="single-d-thumb">
                                      <img loading="lazy" src="{{asset('')}}storage/assets/uploads/img/products/{$proimg}" width="50%" alt="" class="pry-border1">
                                            </div></div>`;
                                    echo $fdvc;
                                  
                                }
                                } catch (\Throwable $th) {
                                //     echo ($active);
                                //     echo ($product['pid']);
                                //     var_dump($img);
                                //     echo ($id[$img]);
                                //     dd($th);
                                //     throw $th;
                                }
                                ?>
                            </div>
                        </div>
                        <div class="product-thumbnail">
                            <ul class="nav nav-tabs" id="myTabS" role="tablist">
                                
                                <?php $productimgthmb = explode('/*', $product['ppicthumb']);  ?>
                                <?php $__currentLoopData = $productimgthmb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img => $proimgthmb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                 
                                    <?php if($img>3): ?> <?php break; ?>   <?php endif; ?>

                                    <?php
                                    if($img == 0)  
                                       {$active = 'active' ; $aria_selected = 'true' ;}
                                    else           
                                        {$active = '' ; $aria_selected = 'false';}
                                    ?>    

                                     <li class="nav-item">
                                            <a 
                                                class="nav-link <?php echo e($active); ?> " 
                                                id="<?php echo e($product['pid'].$id[$img]); ?>-thumb" 
                                                data-toggle="tab"
                                                href="#<?php echo e($product['pid'].$id[$img]); ?>" 
                                                role="tab" 
                                                aria-controls="<?php echo e($product['pid'].$id[$img]); ?>" 
                                                aria-selected="<?php echo e($aria_selected); ?>"
                                            > 
                                                <img loading="lazy"src="<?php echo e(asset('')); ?>storage/assets/uploads/img/products/<?php echo e($proimgthmb); ?>" alt="" class="pry-border1">
                                            </a>
                                     </li>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="shop-d-content">
                            <div class="product-details-t mb-25">
                                <h5><?php echo $product['pname']; ?></h5>
                            </div>
                            <div class="product-d-price mb-20">
                                <?php
                                if ($product['pdiscount'] > 0) {
                                    echo '<span>' . number_format($product["pprice"] - ($product["pprice"] * $product["pdiscount"] / 100)) . ' تومان</span>
                                            <br><span class="old-price" style="font-size:18px !important">' . number_format($product["pprice"]) . ' تومان</span>';
                                } else {
                                    echo '<span>' . number_format($product["pprice"]) . ' تومان</span>';
                                }
                                ?>
                            </div>
                            <div class="product-best-features mb-25">
                                <ul>
                                    <li>
                                        <span>کد محصول:</span>
                                        <?php echo $product['pcode']; ?>
                                    </li>
                                    <!-- <li>
                                        <span>وضعیت:</span>
                                        <?php if ($product["pcount"] > 0) {
                                            echo 'موجود در انبار';
                                        } else {
                                            echo 'اتمام موجودی';
                                        } ?>
                                    </li> -->
                                </ul>
                            </div>
                            <p>
                                <?php echo $product['pdescription']; ?>
                            </p>

                            <div class="d-cart-btn mt-30">
                                <?php
                                if (isset($_SESSION['cusername'])) {
                                ?>
                                    <?php
                                    if ($product["pcount"] > 0) {
                                    ?>

                                        <!-- <form action="./include/buyrequest" method="post"> -->
                                        <button class="btn btn-success" name="buy" value="<?php echo $product["pid"]; ?>">
                                            <!-- خرید و پرداخت -->
                                            ناموجود
                                        </button>
                                        <!-- </form> -->
                                    <?php
                                    } else {
                                        // echo '<a class="btn text-white" onclick="addtocart( ' . $product['pid'] . ')" class="btn">افزودن به سبد خرید</a>';
                                        echo '<button href="cart" class="btn"  class="btn" disabled>اتمام موجودی</button>';
                                    }
                                    ?>
                                <?php
                                } else {
                                ?>

                                    <!-- <button class="btn btn-success scrolldown" target="registerform">
                                        جهت خرید ابتدا ثبت نام کنید
                                    </button> -->
                                    <button class="btn btn-success" target="registerform">
                                        ناموجود
                                    </button>

                                <?php
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>


    </section>

    <?php if(0): ?>
    <?php
    if (!isset($_SESSION['cusername'])) {
    ?>

        <section class="slider-area slider-three-area pt-110 pb-110">
            <div class="container" style="padding: 1px">
                <div class="text-center mt-20 mb-20">
                    <h3 style="color: #ff0000;">ثبت نام در سایت بنیادسنجش</h3>
                </div>
                <div class="row align-items-center mb-30">
                    <div class="col-md-7">
                        <p>
                            داوطلبان گرامی کنکور فرهنگیان 1403، جهت دریافت خدمات ویژه بنیاد سنجش برای کنکور اختصاصی فرهنگیان 1403 (انجام انتخاب رشته اصولی فرهنگیان و دریافت مجموعه کتب اگر من طراح باشم شامل نمونه سوالات شبیه ساز دروس مهارت های معلمی، هوش و استعداد معلمی و دین و زندگی و همچنین دریافت تمامی موضوعات، مباحث و سوالات قابل طرح در جلسه تخصصی مصاحبه و گزینش فرهنگیان) و یا دریافت خدمات مشاوره رایگان کنکور 1403، ابتدا فرم فوق را پر کرده، ثبت نام و یا وارد سایت شوید.
                        </p>
                    </div>
                    <div class="col-md-5" id="registerform">

                        <?php
                        if (isset($_SESSION['counselorverify'])) {
                        ?>
                            <form action="include/registerrequest" method="post">
                                <div class="trial-form text-center">
                                    <input type="text" name="counselorverify" id="counselorverify" placeholder="کد تایید">
                                    <button type="submit" name="counselorverifybtn" class="btn btn-success btn-block">تایید</button>
                            </form>


                            <form action="include/registerrequest" method="post">
                                <button type="submit" name="counselorcancelbtn" class="btn btn-warning btn-block">اصلاح شماره و انصراف</button>
                            </form>

                        <?php
                        } else {
                        ?>
                            <form action="include/registerrequest" method="post">
                                <div class="trial-form text-center">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <input type="text" name="contactfname" id="contactfname" placeholder="نام" 
                                            value="<?php echo $_SESSION['contactfname']; ?>">
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" name="contactlname" id="contactlname" placeholder="نام خانوادگی" 
                                            value="<?php echo $_SESSION['contactlname']; ?>">
                                        </div>
                                    </div>
                                    <input type="number" name="contactmcode" id="contactmcode" placeholder="کد ملی" value="<?php echo $_SESSION['contactmcode']; ?>">
                                    <input type="text" name="contactphone" id="contactphone" placeholder="شماره تلفن همراه" value="<?php echo $_SESSION['contactphone']; ?>">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <select name="contactprovince" id="province" class="select-form-shop">
                                                <option label="استان خود را انتخاب کنید"></option>
                                                <?php
                                                $province = $contacts->GetProvinceList(NULL);
                                                foreach ($province as $ostan) {
                                                    echo '<option value="' . $ostan['province_id'] . '">' . $ostan['provincename'] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <select name="contactcity" id="city" class="select-form-shop">
                                                <option label="شهر خود را انتخاب کنید"></option>
                                                <?php
                                                $cities = $contacts->GetCityList(NULL);
                                                foreach ($cities as $city) {
                                                    echo '<option value="' . $city['id'] . '">' . $city['cityname'] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <select name="contactreshte" id="contactreshte" class="select-form-shop">
                                                <option label="رشته تحصیلی خود را انتخاب کنید"></option>
                                                <option value="تجربی">تجربی</option>
                                                <option value="انسانی">انسانی</option>
                                                <option value="ریاضی">ریاضی</option>
                                                <option value="هنر">هنر</option>
                                                <option value="زبان">زبان</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <select name="contactgender" id="contactgender" class="select-form-shop">
                                                <option label="جنسیت خود را انتخاب کنید"></option>
                                                <option value="دختر">دختر</option>
                                                <option value="پسر">پسر</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" name="counselorregisterbtn" class="btn btn-success btn-block">ثبت نام</button>
                                    </div>
                            </form>
                        <?php
                        }
                        ?>

                    </div>
                </div>
            </div>
        </section>
    <?php
    }
    ?>
    <?php endif; ?>

    <section class="shop-details-area pb-80">
        <div class="container">
            <div class="text-center mt-20 mb-20">
                <h3 style="color: #ff0000;">
                    پیش نمایش کتاب اگر من طراح باشم
                </h3>
            </div>
            <div class="row align-items-center">
                <div class="col-md-4">
                    <a href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهتجربی.pdf">
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/preview-t.jpg" width="100%" alt="بخشی از کتاب اگر من طراح باشم" class="pry-border1">
                    </a>
              
                        <a class="btn btn-warning" href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهتجربی.pdf">
                            جلد سه تجربی
                        </a>
                  
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهریاضی.pdf">
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/preview-r.jpg" width="100%" alt="بخشی از کتاب اگر من طراح باشم" class="pry-border1">
                    </a>
                  
                        <a class="btn btn-warning" href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهریاضی.pdf">
                            جلد سه ریاضی
                        </a>
                 
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهانسانی.pdf">
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/preview-e.jpg" width="100%" alt="بخشی از کتاب اگر من طراح باشم" class="pry-border1">
                    </a>
                  
                        <a class="btn btn-warning" href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهانسانی.pdf">
                            جلد سه انسانی
                        </a>
                   
                </div>
            </div>
            <div class="row align-items-center mt-50">
                <div class="col-md-4 offset-md-2">
                    <a href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهمصاحبه.pdf">
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/preview-f1.jpg" width="100%" alt="بخشی از کتاب اگر من طراح باشم" class="pry-border1">
                    </a>
                   
                        <a class="btn btn-warning" href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهمصاحبه.pdf">
                            اگر من طراح باشم فرهنگیان "مصاحبه"
                        </a>
                    
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهاستعداد.pdf">
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/preview-f2.jpg" width="100%" alt="بخشی از کتاب اگر من طراح باشم" class="pry-border1">
                    </a>
                     
                        <a class="btn btn-warning" href="<?php echo e(asset('')); ?>assets/uploads/file/نمونهاستعداد.pdf">
                            اگر من طراح باشم فرهنگیان "هوش و استعداد"
                        </a>
                     
                </div>

            </div>
        </div>
    </section>

    <section class="slider-area slider-three-area pt-110 pb-110">
        <div class="container" style="padding: 1px">
            <div class="text-center mt-20 mb-20">
                <h3 style="color: #ff0000;">مشاوره رایگان کنکور 1403</h3>
            </div>
            <div class="row align-items-center mb-30">
                <div class="col-md-5">
                    <h4>
                        مشاوره رایگان کنکور سراسری 1403 بنیاد سنجش ،شامل :
                    </h4>
                    <ul>
                        <li>
                            تماس تلفنی و صحبت های اولیه با دانش آموز و داوطلب
                        </li>
                        <li>
                            تشخیص نقاط ضعف و قوت دانش آموز
                        </li>
                        <li>
                            ارائه روش های صحیح مطالعه در دوران جمع بندی و مرور
                        </li>
                        <li>
                            ارائه روش های صحیح تست زنی
                        </li>
                        <li>
                            آموزش کامل نحوه صحیح تحلیل آزمون ها
                        </li>
                        <li>
                            آموزش کامل نحوه مطالعه اصولی دروس عمومی و اختصاصی
                        </li>
                        <li>
                            آموزش کامل نحوه اصولی مدیریت آزمون
                        </li>
                    </ul>
                </div>
                <div class="col-md-7 m-auto">
                    
                        <img loading="lazy"src="<?php echo e(asset('')); ?>assets/img/مشاورهرایگان.jpg" width="60%" alt="مشاوره رایگان کنکور 1403" class="pry-border1">
                    
                    <?php
                    if (isset($_SESSION['cusername'])) {
                    ?>
                        <form action="include/registerrequest" method="post">
                            <button class="btn btn-success btn-block" name="counselor">
                                جهت دریافت مشاوره رایگان کلیک کنید
                            </button>
                        </form>
                    <?php
                    } else {
                    ?>

                        <button class="btn btn-success btn-block scrolldown" target="registerform">
                            جهت دریافت مشاوره رایگان ابتدا در سایت بنیادسنجش ثبت نام کنید
                        </button>

                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </section> 
</main> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\farhangian\farhangian_II.blade.php ENDPATH**/ ?>