<?php if(session()->has('Sign_PageCurrent') && session('Sign_PageCurrent')[1] == 'farhangianInit'): ?>
<div id="GetField_Base" class="col-md-10">
    <div class="row my-1">
        <label for="field_Base" class="col  p-2 text-dark text-bold">پایه
            تحصیلی:</label>
        <select id="field_Base-select" name="field_Base" class="col-8 p-2 text-center  " required
            wire:model="field_Base"style="border:2px solid #ddd; border-radius:7px;">
            <option value="" hidden>پایه تحصیلی</option>
            <option value="نهم">نهم</option>
            <option value="دهم">دهم</option>
            <option value="یازدهم">یازدهم</option>
            <option value="دوازدهم">دوازدهم</option>
            <option value="فارغ التحصیل(پشت کنکور)">فارغ التحصیل(پشت کنکور)</option>
        </select>
        <?php echo $__env->make('livewire.error', ['e' => 'field_Base'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<div class="col-md-10 my-3 justify-content-center">
         <div class="form-row justify-content-center">
            <div class="col-12">
                <div class="form-row  my-1  justify-content-center  ">
                    <div class="col-10">
                        <div class=" form-check form-switch  ">
                            <label class=" form-check-label " for="WantKonkur1404Farhangiyan">آیا در کنکور فرهنگیان 1404 شرکت خواهید کرد؟</label>
                        </div>
                    </div>
                    <div class="col">
                        <div class=" form-check form-switch  ">
                            <input class=" form-check-input p-2 form-control " type="checkbox" id="WantKonkur1404Farhangiyan"
                                name="WantKonkur1404Farhangiyan"required
                                wire:model="WantKonkur1404Farhangiyan"style="border:2px solid #777; border-radius:7px;">
                        </div>
                    </div>
                </div>
            </div> 
            
            
        </div>
 </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\auth\studentFarhangian.blade.php ENDPATH**/ ?>