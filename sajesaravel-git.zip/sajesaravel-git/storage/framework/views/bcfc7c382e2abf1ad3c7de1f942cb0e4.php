
<script data-navigate-once>
    //document.addEventListener('livewire:navigated', function() {
    const skeletonHTML = `
        <div id="skeleton_blade">
            <div class="max-w-sm animate-pulse m-5 p-5 w-100">
                <div class="h-2.5 bg-gray-200 rounded-full dark:bg-gray-700 w-48 mb-4"></div>
                <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-400 max-w-[360px] mb-2.5"></div>
                <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-700 mb-2.5"></div>
                <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-400 max-w-[330px] mb-2.5"></div>
                <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-700 max-w-[300px] mb-2.5"></div>
                <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-400 max-w-[360px]"></div>
                <span class="sr-only">Loading...</span>
            </div>
        </div>`;
    // $('#skeleton_template').html();
    //document.addEventListener('DOMContentLoaded', () => {
    //    setTimeout(() => {
    //        //document.getElementById('skeleton_blade').style.display = 'none';
    //        //document.getElementById('main_content').style.display = 'block';
    //        $('.skeleton_blade').hide(); // Hide
    //        $('.main_content').show(); // Show
    //    }, 3000);
    //});

    document.addEventListener('livewire:navigated', () => {

        //$('.main_content').each(function() {
        //    const $original = $(this);
        //    // Replace with skeleton
        //    $original.html(skeletonHTML);
        //});
        //        $('.main_content').each(function() {
        //            const $original = $(this);
        //            const originalHTML = $original.html();
        //
        //            // Replace with skeleton
        //            $original.html(skeletonHTML);
        //
        //            // Restore original after delay
        //            setTimeout(() => {
        //                $original.html(originalHTML);
        //            }, 3000);
        //        });


    });
    //});
    //            document.getElementById('skeleton_blade').style.display = 'block';
    //            $('.skeleton_blade').show(); // Hide
    //            $('.main_content').hide(); // Show
    //
    //            setTimeout(() => {
    //                //document.getElementById('skeleton_blade').style.display = 'none';
    //                //document.getElementById('main_content').style.display = 'block';
    //                $('.skeleton_blade').hide(); // Hide
    //                $('.main_content').show(); // Show
    //            }, 3000);
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\layouts\skeleton.blade.php ENDPATH**/ ?>