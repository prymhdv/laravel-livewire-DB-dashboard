<div class="col-md-12 p-0 my-5">

    <div class="row align-items-top justify-content-center p-2 boxShadow1 "
        style="
                border-radius:7px;
                /*background:linear-gradient(90deg,#091506af 0,#0f1a0bcb 50%,#12180eb9 100%);*/
                background: linear-gradient(135deg, #f7a10158 0, #975e02c6 78%, #f7990179 100%);
                  
                ">
        <p class="text-light text-center fs-6 p-2 mt-4 mb-0"
            style="font-family: Lalezar, sans-serif;word-spacing: initial;">
            افتخار آفرینان بنیاد سنجش ایرانیان
        </p>
        <!----------SIDE--------------->
        <div class="col-md-12  p-1 p-lg-4">

            <img loading="lazy" class=" pry-border1 d-block w-100" style="border-radius:7px!important;"
                 src="<?php echo e(asset('storage/main/home/konkurTheBest.webp')); ?>" alt="konkurTheBest">
        </div>
    </div>

</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\konkurTheBest.blade.php ENDPATH**/ ?>