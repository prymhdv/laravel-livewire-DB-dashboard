 <!-----------MAIN------ajax= --$url =   ------>
 "<?php echo e($ooo = action([\App\Http\Controllers\HomeController::class, 'index'])); ?>"


asset($path, $secure = null)
asset doesn't accept extra query parameters
in case of relative URL asset checks for presence of index.php string and removes it because is not needed for assets
url/to($path, $extra = [], $secure = null)
to does accept extra parameters that are appended as path segments
to preservers query string<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\action.blade.php ENDPATH**/ ?>