  <!-- اسلایدر بالای صفحه -->
  
  <div class="content-wrapper p-0 d-none d-lg-block">
      <div class="slider-section p-lg-4 p-1">
          <div id="carouselTop" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                  <?php
                //   $numbers = range(1, 19);
                //   shuffle($numbers);
                //   $last = array_pop($numbers);
                //   $numbers[] = $last;
                //   foreach ($numbers as $index => $i) {
                //       $active = $index === 0 ? 'active' : '';
                //       echo '<div class="carousel-item ' .
                //           $active .
                //           '"> <img   fetchpriority="high" class="d-block w-100 " src="' .
                //           asset('storage/main/student/fieldSelection/banners/desktop/s') . $i . '.webp"  
                //           alt="' . $i . ' پشتیبانی انتخاب رشته بنیادسنجش"></div>';
                //   }
                  ?>
                    <div class="carousel-item active">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/01d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/02d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/03d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/04d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/05d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/06d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/07d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/08d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/09d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/10d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/11d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/12d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/13d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/14d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item  ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/15d.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
              </div>
              <!-- دکمه‌های قبلی و بعدی -->
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselTop" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselTop" data-bs-slide="next">
                  <span class="carousel-control-next-icon"></span>
              </button>
          </div>
      </div>
  </div>
  
  <div class="content-wrapper p-0 d-block d-lg-none">
      <div class="slider-section p-lg-4 p-1">
          <div id="carouselTopMobile" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                  <?php
                //   $numbers = range(1, 19);
                //   shuffle($numbers);
                //   $last = array_pop($numbers);
                //   $numbers[] = $last;
                //   foreach ($numbers as $index => $i) {
                //       $active = $index === 0 ? 'active' : '';
                //       echo '<div class="carousel-item ' .
                //           $active . '"> <img   fetchpriority="high" class="d-block w-100 " src="' .
                //           asset('storage/main/student/fieldSelection/banners/desktop/s') . $i . '.webp" 
                //           alt="' . $i . ' پشتیبانی انتخاب رشته بنیادسنجش"></div>';
                //   }
                  ?>
                  <div class="carousel-item active">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/01m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/02m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/03m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                   <div class="carousel-item ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/04m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/05m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item ">
                      <img src="<?php echo e(asset('storage/main/student/fieldSelection/banners/20250529/06m.webp')); ?>"
                          class="d-block w-100" alt="...">
                  </div>
              </div>
              <!-- دکمه‌های قبلی و بعدی -->
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselTopMobile" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselTopMobile" data-bs-slide="next">
                  <span class="carousel-control-next-icon"></span>
              </button>
          </div>
      </div>
  </div>















  
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\bannerHeadII.blade.php ENDPATH**/ ?>