<!--[if BLOCK]><![endif]--><?php if(request()->route()->getName() == 'panel.DashboardAdminLivewireRoute'): ?>
    <?php echo $__env->make('pages.home.adminInfoStatics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/panel/statics.blade.php ENDPATH**/ ?>