

<?php $__env->startSection('pageTitle', 'استخدام مشاور'); ?>
<?php $__env->startSection('content'); ?>

    <main class="container mt-5" style="
    /* margin-top:60px;  */
    ">
        <?php echo $__env->make('pages.employee.counsellor.rules', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="row justify-content-center f-900">

            
            <?php echo $__env->make('livewire.dashboard.employee.counsellor.links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php if(1 &&
                    null !== Auth::user() &&
                    Auth::user()->counsellor()->exists() &&
                    null !== Auth::user()->counsellor()->where('isCounsellor', true)->first()): ?>
            <?php else: ?>
                <section class=" col-12 p-0 mt-5">
                    <?php echo $__env->make('pages.employee.counsellor.carousel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </section>
            <?php endif; ?>
            <section class=" col-12 p-0 mt-2">
                <?php echo $__env->make('pages.employee.counsellor.desc', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </section>
        </div>

    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('headerSub'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\employee\counsellor\page.blade.php ENDPATH**/ ?>