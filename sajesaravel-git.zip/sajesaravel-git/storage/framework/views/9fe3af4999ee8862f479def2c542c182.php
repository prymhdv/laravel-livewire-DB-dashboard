<div id="formulaone" class="col-12   p-2 " >
    <div class="row pt-3" style="border:1px solid #eee; border-radius:7px; ">
        
     </div>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\panel\main.blade.php ENDPATH**/ ?>