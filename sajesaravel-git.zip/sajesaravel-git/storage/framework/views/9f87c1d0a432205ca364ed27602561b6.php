<?php if(request()->route()->getName() == 'formulaone.DashboardStudentLivewireRoute'): ?>
    <?php echo $__env->make('livewire.dashboard.student.formulaone.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div id="formulaone" class="col-12   p-2 ">
        <div class="row pt-3" style="border:1px solid #eee; border-radius:7px; ">

        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\formulaone\main.blade.php ENDPATH**/ ?>