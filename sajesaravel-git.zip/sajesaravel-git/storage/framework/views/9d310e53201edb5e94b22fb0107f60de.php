 
<div id="carouselExampleFade" class="carousel slide carousel-fade pry-border1 shadow1" data-bs-ride="carousel">
    <div class="carousel-inner">
      
      <div class="carousel-item active">
        <img loading="lazy"class="d-block w-100" src="<?php echo e(asset('storage/Pages/home/Banners/homeMojavez.webp')); ?>"
        alt=" ">
      </div>
      <div class="carousel-item">
        <img loading="lazy"class="d-block w-100" src="<?php echo e(asset('storage/Pages/home/Banners/homeAdresss.webp')); ?>"
        alt=" ">
      </div>
      <div class="carousel-item">
        <a href="https://instagram.com/sanjesh.b_org"target="_blank">
            <img loading="lazy"class="d-block w-100"
                src="<?php echo e(asset('storage/Pages/home/Banners/homeInstagram.webp')); ?>"alt=" ">
        </a>
      </div>
      
     
      
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

 
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\other\supportbanner.blade.php ENDPATH**/ ?>