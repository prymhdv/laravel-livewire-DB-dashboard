<div id="Banner-Booster" class="col-12 p-5   align-content-center   ">
    <div class="d-flex m-1 p-0 align-content-center justify-content-center" style=" border-radius:7px; ">
        <?php echo $__env->make('pages.student.formulaone.banner-bs5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\formulaone\banner.blade.php ENDPATH**/ ?>