<?php
 $product=[];
    $product = [
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/babak_khatibi.webp'),
            'body' => 'one of one',
            'title' => 'استاد بابک خطیبی',
            'href' => route('counsellor.employee.pages.home.Route'),
        ],
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/mehran_torkaman.webp'),
            'body' => 'one of one',
            'title' => 'استاد مهران ترکمان',
            'href' => route('counsellor.employee.pages.home.Route'),
        ],
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/morteza_zareie.webp'),
            'body' => 'one of one',
            'title' => 'استاد مرتضی زارعی',
            'href' => route('farhangian.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/ostad_adib_sheykh_bahaie.webp'),
            'body' => 'one of one',
            'title' => 'استاد ادیب شیخ بهایی',
            'href' => route('farhangian.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/reza_arbabian.webp'),
            'body' => 'one of one',
            'title' => 'استاد رضا اربابیان',
            'href' => route('farhangian.index.Route'),
        ],
        [
            'name' => 'one',
            'price' => '',
            'poster' => asset('storage/main/teacher/sorush_moiene.webp'),
            'body' => 'one of one',
            'title' => 'استاد سروش معینی',
            'href' => route('farhangian.index.Route'),
        ],
    ];

?>

<div id="loop5R3" class="owl-carousel owl-theme owl-loaded mt-2" style="direction:ltr;">
    <div class="owl-stage-outer">
        <div class="owl-stage d-flex flex-row justify-content-center align-content-center">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="owl-item p-2 " style="background-color: #7d7d7d00!important; border-radius:50%; max-width: 128px; ">
                    <a class="product98 text-center " style="color:white;max-width: 120px; " href="<?php echo e($item['href']); ?>">
                        <img src="<?php echo e($item['poster']); ?>" alt=""
                            style="max-width: 120px; border-radius:50%; justify-self: anchor-center;"
                            class="text-center">
                        <span class="fs-3"> <?php echo e($item['title']); ?> <?php echo e($item['price']); ?>

                        </span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
</div>
<style>
    .product98:hover {
        color: #4daf50 !important;
         transition: all 0.3s ease-in-out 0s;
    }
</style>

<script>
    $(document).ready(function() {
        var owl = $('#loop5R3');
        owl.owlCarousel({
            loop: true,
            margin: 10,
            dots: true,
            autoplay: true,
            autoplayTimeout: 3000, // Set autoplay timeout
            autoplayHoverPause: true,
            mouseDrag: true,
            touchDrag: true,
            responsive: {
                0: {
                    items: 1 // 1 item for screen width 0px and up
                },
                400: {
                    items: 2 // 2 items for screen width 400px and up
                },
                850: {
                    items: 3 // 3 items for screen width 850px and up
                },
                1300: {
                    items: 5 // 5 items for screen width 1300px and up
                },
            },
        });
        setTimeout(function() {}, 2000);
    });
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\prymhdv\partials\teachers.blade.php ENDPATH**/ ?>