 <!-- بخش نتایج -->
 <div class="section-title p-0 my-3">
     <div class="content-wrapper p-0">
         <h4 class="text-center text-primary fw-bold fs-5">نتایج و کارنامه‌ها</h4>
         <p class="text-center fs-4 fs-lg-6">سابقه درخشان در قبولی داوطلبان در رشته‌های تاپ با شرایط خاص در رشته‌ها
             و دانشگاه‌های
             معتبر
         </p>
         <div class="row row-cols-1 row-cols-md-2 g-5  mt-4">
             <?php
                 $items = [
                     [
                         'id' => 20860,
                         'title' => 'استعلام کارنامه رتبه 20860',
                         'subTitle' => 'قبولی از فناوری اطلاعات دانشگاه علوم پزشکی ارومیه',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/01.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/01.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/20860.webp',
                     ],
                     [
                         'id' => 18893,
                         'title' => 'استعلام کارنامه رتبه 18893',
                         'subTitle' => 'قبولی از مهندسی نفت دانشگاه صنعتی سهند',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/02.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/02.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/18893.webp',
                     ],

                     [
                         'id' => 16068,
                         'title' => 'استعلام کارنامه رتبه 16068',
                         'subTitle' => 'قبولی از حقوق دانشگاه اراک',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/10.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/10.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/16068.webp',
                     ],
                     [
                         'id' => 13075,
                         'title' => 'استعلام کارنامه رتبه 13075',
                         'subTitle' => 'قبولی از علوم کامپیوتر دانشگاه شاهد تهران',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/08.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/08.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/13075.webp',
                     ],

                     [
                         'id' => 11746,
                         'title' => 'استعلام کارنامه رتبه 11746',
                         'subTitle' => 'قبولی از پرتوشناسی دانشگاه علوم پزشکی بیرجند',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/07.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/07.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/11746.webp',
                     ],
                     [
                         'id' => 7118,
                         'title' => 'استعلام کارنامه رتبه 7118',
                         'subTitle' => 'قبولی از دامپزشکی دانشگاه آزاد ارومیه',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/05.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/05.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/7118.webp',
                     ],
                     [
                         'id' => 6559,
                         'title' => 'استعلام کارنامه رتبه 6559',
                         'subTitle' => 'قبولی از ساخت پروتز‌های دندانی دانشگاه علوم پزشکی سبزوار',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/09.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/09.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/6559.webp',
                     ],
                     [
                         'id' => 5844,
                         'title' => 'استعلام کارنامه رتبه 5844',
                         'subTitle' => 'قبولی از مهندسی کامپیوتر دانشگاه صنعتی شریف',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/06.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/06.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/5844.webp',
                     ],
                     [
                         'id' => 3198,
                         'title' => 'استعلام کارنامه رتبه 3198',
                         'subTitle' => 'قبولی از دندانپزشکی دانشگاه علوم پزشکی اراک',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/04.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/04.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/3198.webp',
                     ],
                     [
                         'id' => 328,
                         'title' => 'استعلام کارنامه رتبه 328',
                         'subTitle' => 'قبولی از دندانپزشکی دانشگاه علوم پزشکی اصفهان',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/03.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/03.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/328.webp',
                     ],

                     [
                         'id' => 3074,
                         'title' => 'استعلام کارنامه رتبه 3074',
                         'subTitle' => 'قبولی از داروسازی دانشگاه علوم پزشکی زنجان',
                         'poster' => 'storage/main/student/fieldSelection/KarnameVideo/II/3074_Daru_Zanjan/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/3074_Daru_Zanjan/estelam-farimah-asemani.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/II/3074_Daru_Zanjan/Slide16.webp',
                     ],
                     [
                         'id' => 4163,
                         'title' => 'استعلام کارنامه رتبه 4163',
                         'subTitle' => 'قبولی از پزشکی دانشگاه علوم پزشکی جهرم',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/4163_Pezeshki_jahrom/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/4163_Pezeshki_jahrom/estelam-dorsa-raisizade.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/4163_Pezeshki_jahrom/Slide11.webp',
                     ],
                     [
                         'id' => 6085,
                         'title' => 'استعلام کارنامه رتبه 6085',
                         'subTitle' => 'قبولی از پزشکی دانشگاه علوم پزشکی جهرم',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/6085_Pezeshki_Zahedan/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/6085_Pezeshki_Zahedan/22.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/6085_Pezeshki_Zahedan/Slide3.webp',
                     ],
                     [
                         'id' => 6654,
                         'title' => 'استعلام کارنامه رتبه 6654',
                         'subTitle' => 'قبولی از پزشکی دانشگاه علوم پزشکی کرمان',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/6654_Pezeshki_Kerman/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/6654_Pezeshki_Kerman/18.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/6654_Pezeshki_Kerman/Slide2.webp',
                     ],
                     [
                         'id' => 8499,
                         'title' => 'استعلام کارنامه رتبه 8499',
                         'subTitle' => 'قبولی از پزشکی دانشگاه علوم پزشکی مشهد',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/8499_Pezeshki_Mashhad/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/8499_Pezeshki_Mashhad/2.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/8499_Pezeshki_Mashhad/Slide1.webp',
                     ],
                     [
                         'id' => 10721,
                         'title' => 'استعلام کارنامه رتبه 10721',
                         'subTitle' => 'قبولی از پرتوشناسی دانشگاه علوم پزشکی اردبیل',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/10721_Parto_Ardebil/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/10721_Parto_Ardebil/estelam-farhad-fathalizadeh.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/10721_Parto_Ardebil/Slide16.webp',
                     ],
                     [
                         'id' => 11945,
                         'title' => 'استعلام کارنامه رتبه 11945',
                         'subTitle' => 'قبولی از حسابداری دانشگاه تهران',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/11945_HesabDari_Tehran/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/11945_HesabDari_Tehran/58.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/11945_HesabDari_Tehran/Slide39.webp',
                     ],
                     [
                         'id' => 12758,
                         'title' => 'استعلام کارنامه رتبه 12758',
                         'subTitle' => 'قبولی از مدیریت دولتی دانشگاه تهران',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/12758_ModiriyatMali_Tehran/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/12758_ModiriyatMali_Tehran/estelam-haniye-cheraghi.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/12758_ModiriyatMali_Tehran/Slide11.webp',
                     ],
                     [
                         'id' => 59272,
                         'title' => 'استعلام کارنامه رتبه 59272',
                         'subTitle' => 'قبولی از علوم کامپیوتر دانشگاه ملایر',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/59272_OlumComputer_Malayer/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/59272_OlumComputer_Malayer/estelam-pedram-zolgadr.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/59272_OlumComputer_Malayer/Slide66.webp',
                     ],
                     [
                         'id' => 74493,
                         'title' => 'استعلام کارنامه رتبه 74493',
                         'subTitle' => 'قبولی از پرستاری دانشگاه علوم پزشکی مراغه',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/74493_Parastati_Maraghe/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/74493_Parastati_Maraghe/59.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/74493_Parastati_Maraghe/Slide13.webp',
                     ],
                     [
                         'id' => 86673,
                         'title' => 'استعلام کارنامه رتبه 86673',
                         'subTitle' => 'قبولی از معماری دانشگاه تهران',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/86673_Memari_Tehran/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/86673_Memari_Tehran/video.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/86673_Memari_Tehran/Slide11.webp',
                     ],

                     [
                         'id' => 153755,
                         'title' => 'استعلام کارنامه رتبه 153755',
                         'subTitle' => 'قبولی از مهندسی ماشین های صنایع غذایی دانشگاه اردبیل',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/153755_SanayeGhazaee_ardebil/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/153755_SanayeGhazaee_ardebil/5.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/153755_SanayeGhazaee_ardebil/Slide9.webp',
                     ],

                     [
                         'id' => 173251,
                         'title' => 'استعلام کارنامه رتبه 173251',
                         'subTitle' => 'قبولی از زیست شناسی گیاهی دانشگاه شهید مدنی',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/173251_ZistGiyahi_ShahidMadani/poster.webp',
                         'video' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/173251_ZistGiyahi_ShahidMadani/1.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/173251_ZistGiyahi_ShahidMadani/Slide7.webp',
                     ],

                     [
                         'id' => 177332,
                         'title' => 'استعلام کارنامه رتبه 177332',
                         'subTitle' => 'قبولی از آموزش زبان انگلیسی دانشگاه بجنورد',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/177332_Zaban_Bojnurd/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/177332_Zaban_Bojnurd/30.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/177332_Zaban_Bojnurd/Slide8.webp',
                     ],
                     [
                         'id' => 42004,
                         'title' => 'استعلام کارنامه رتبه 42004',
                         'subTitle' => 'قبولی از مهندسی برق دانشگاه شیراز',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/42004_Bargh_Shiraz/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/42004_Bargh_Shiraz/6756.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/42004_Bargh_Shiraz/Slide61.webp',
                     ],

                     [
                         'id' => 6060,
                         'title' => 'استعلام کارنامه رتبه 6060',
                         'subTitle' => 'قبولی از مهندسی شیمی دانشگاه تهران',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/6060_Shimi_tehran/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/6060_Shimi_tehran/454.mp4',
                         'image' => 'storage/main/student/fieldSelection/KarnameVideo/II/6060_Shimi_tehran/Slide4.webp',
                     ],
                     [
                         'id' => 201349,
                         'title' => 'استعلام کارنامه رتبه 201349',
                         'subTitle' => 'قبولی از مهندسی صنایع دانشگاه بجنورد',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/201349_Sanay_Bojnurd/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/201349_Sanay_Bojnurd/5252.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/201349_Sanay_Bojnurd/Slide80.webp',
                     ],
                     [
                         'id' => 32634,
                         'title' => 'استعلام کارنامه رتبه 32634',
                         'subTitle' => 'قبولی از مهندسی عمران دانشگاه شریف',
                         'poster' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/32634_Omran_Sharif/poster.webp',
                         'video' => 'storage/main/student/fieldSelection/KarnameVideo/II/32634_Omran_Sharif/343.mp4',
                         'image' =>
                             'storage/main/student/fieldSelection/KarnameVideo/II/32634_Omran_Sharif/Slide55.webp',
                     ],
                      [
                         'id' => 8365,
                         'title' => 'استعلام کارنامه رتبه 8365',
                         'subTitle' => 'قبولی از پزشکی دانشگاه علوم پزشکی قم',
                         'poster'   =>'storage/main/student/fieldSelection/KarnameVideo/II/8365_Pezeshki_Ghom/poster.webp',
                         'video'    => 'storage/main/student/fieldSelection/KarnameVideo/II/8365_Pezeshki_Ghom/9595.mp4',
                         'image'    =>'storage/main/student/fieldSelection/KarnameVideo/II/8365_Pezeshki_Ghom/Slide500.webp',
                     ],
                 ];
                 //  $items = collect($items)->sortBy('id')->values()->all();
                 $items = collect($items)->sortByDesc('id')->values()->all();
             ?>

             <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                 <div class="col-md-12 p-2">
                     <div class="text-center rounded card shadow1 p-0">
                         <div class=" card-body p-0 ">
                             <div class="row">
                                 <div class="row p-2 " style="background-color: #eee;">
                                     <div class="card-text fw-bold">
                                         <?php echo e($item['title']); ?>

                                     </div>
                                     <div class="card-text">
                                         <?php echo e($item['subTitle']); ?>

                                     </div>
                                 </div>
                                 <div class="col">
                                     <img loading="lazy" class="d-block w-100 pry-border1"
                                         src="<?php echo e(asset($item['image'])); ?>" alt="انتخاب رشته">
                                 </div>
                                 <div class="col"> <video controls width="100%" preload="none"
                                         style="max-height: 380px; aspect-ratio: 1.5;"
                                         poster="<?php echo e(asset($item['poster'])); ?>">
                                         <source src="<?php echo e(asset($item['video'])); ?>">
                                     </video>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
         </div>
     </div>
 </div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/student/entekhabReshte/karnameVideo.blade.php ENDPATH**/ ?>