<div class="container my-3" style="direction: rtl;">  
<div class="d-xxl-flex flex-wrap   col-xxl-12 p-2 justify-content-around  text-nowrap  shadow1 position-relative  text-center boxShadow1_3d"
    style="background-color: #ddd0; border-radius:7px;   ">
    
 
     
    
    
    
    <div class="  px-2 justify-content-between   my-1    ">
        
        <a href="#" wire:navigate 
            class="card-userSection card card-body p-1 
             
            <?php if(Str::contains(request()->route()->getName(), 'kargah') ): ?> card-userSection-active <?php endif; ?>
             ">
            <div class=" container p-0 row row-cols-auto  justify-content-between position-relative">
                <div class=" position-absolute bandX" style="  "></div>
                <span class="col">
                    <i class=" 	fa fa-gears px-2" ></i>
                    کارگاه‌های عملی
                </span>
                <span class="col">
                    <?php if(isset(Auth::user()->employee) &&
                            isset(Auth::user()->employee->kargah) &&
                            Auth::user()->employee->kargah->IsKargah == true): ?>
                        <i class="fa fa-check-circle  text-sanjesh-green"></i>
                    <?php endif; ?>
                </span>
             
                
            </div>
        </a> 
    </div>
    <div class="  px-2 justify-content-between my-1   ">

     
        <a href="#" wire:navigate 
            class="card-userSection card card-body p-1 
            
              <?php if(Str::contains(request()->route()->getName(), 'etelaiye')): ?> card-userSection-active <?php endif; ?>
            ">
            <div class=" container p-0 row row-cols-auto  justify-content-between position-relative">
                <div class=" position-absolute bandX" style="  "></div>
                <span class="col">
                    <i class=" 		fa fa-qrcode px-2" ></i>
                    سفارشات
                </span>
                <span class="col">
                    <?php if(isset(Auth::user()->employee) &&
                            isset(Auth::user()->employee->etelaiye) &&
                            Auth::user()->employee->etelaiye->IsEtelaiye == true): ?>
                        <i class="fa fa-check-circle  text-sanjesh-green"></i>
                    <?php endif; ?>
                </span>
          
               
            </div>
        </a>
    </div>
    <div class="  px-2 justify-content-between   my-1  ">
        
        <a href="#" wire:navigate 
            class="card-userSection card card-body p-1 
            
            <?php if(Str::contains(request()->route()->getName(), 'scholarship')): ?> card-userSection-active <?php endif; ?>
 ">
            <div class=" container p-0 row row-cols-auto  justify-content-between position-relative">
                <div class=" position-absolute bandX" style="  "></div>
           
                <span class="col">
                    <i class=" fa fa-question-circle px-2" ></i>
                    پرسش و پاسخ
                </span>
                <span class="col">
                    <?php if(isset(Auth::user()->employee) &&
                            isset(Auth::user()->employee->questionAnswer) &&
                            Auth::user()->employee->questionAnswer->IsquestionAnswer == true): ?>
                        <i class="fa fa-check-circle  text-sanjesh-green"></i>
                    <?php endif; ?>
                </span>
            </div>
        </a>
    </div>
</div>
</div>
<style>
    .bandX {
        background-color: green;
        width: 15px;
        height: 139%;
        right: -19px;
        top: -4px;
        opacity: .8;
    }

    .card-userSection-active {
        background-color: darkslategrey !important;
        color: aliceblue !important;
        border: 0;
    }

    .card-userSection-active .bandX {
        background-color: #0080f7;
        width: 10px;
        height: 139%;
        right: -21px;
        top: -4px;
        opacity: .8;
    }

    .card-userSection-active .container .col svg {

        color: aliceblue !important;
    }

    .card-userSection {
        text-decoration: none;
        user-select: none;
        width: 100%;
        transition: all 0.3s ease-in-out 0s;
        overflow: hidden;
    }

    .card-userSection:hover {
        cursor: pointer;
        background-color: darkslategrey;
        color: aliceblue;
        border: 0;

    }

    .card-userSection:hover .container .col svg {

        color: aliceblue !important;
    }

    .card-userSection:active {
        /* cursor: pointer; */
        background-color: darkslategrey;
        color: aliceblue;
    }




    .card-userSection:hover .bandX {
        background-color: #0080f7;
        width: 10px;
        height: 139%;
        right: -21px;
        top: -4px;
    }
</style>

    

<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employeed\userSection.blade.php ENDPATH**/ ?>