<?php if(request()->route()->getName() == 'addNumber.counsellors.employee.adminPanelLivewireRoute'
//    || (session()->has('employeeCounsellorAddMobile') && session('employeeCounsellorAddMobile') == '1')
    ): ?>
    <div class="row p-1">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body col-md-12">
                    افزودن شماره

                    <hr>
                    <div class="container text-center">
                        <div class="row justify-content-center align-content-center">
                            <div id="GetLname" class="col-md-5 justify-content-center align-content-center">
                                <div class="row   justify-content-center align-content-center">
                                    <div class="input-group input-group-sm mb-1">
                                        <label class="col-3 input-group-text px-3" for="mobile">شماره موبایل</label>
                                        <input class=" text-center form-control" type="text" name="mobile" required id="mobile"
                                            
                                            style="border:2px solid #ddd; border-radius:7px;">
                                        <?php echo $__env->make('livewire.error', ['e' => 'lname'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <button id="regSet"
                                class="col-4 my-3 p-2 btn btn-info text-bold   text-white"
                                style="border: 1px solid #eee; cursor: pointer;" 
                                
                                >
                                تکمیل درخواست
                            </button>
                            
                                    
                             
                            <script>
                                // $(document).ready(function() {
                                document.addEventListener('livewire:navigated', () => {
                                    //    var regSms() = function() { 
                                    $('#regSet').click(function() {
                                        // console.log( $('#bodySet')[0],'------------',$('#titleSet')[0].value);
                                        $.ajax({
                                            method: 'post',
                                            url: "<?php echo e(route('add.addNumber.counsellors.employee.adminPanelLivewireRoute')); ?>",
                                            data: {
                                                mobile: $('#mobile')[0].value, 
                                                _token: '<?php echo e(csrf_token()); ?>',
                                            },
                                            success: function(msg) {
                                                $('#regSet').text('ثبت موفق');
                                                $('#regSet').removeClass('btn-danger');
                                                $('#regSet').addClass('btn-success');
                
                                            },
                                            error: function(msg) {
                                                $('#regSet').text('خطا در ثبت');
                                                $('#regSet').removeClass('btn-success');
                                                $('#regSet').addClass('btn-danger');
                                            },
                                        }).done(function() {
                                            $('#regSet').text('ثبت موفق');
                                            $('#regSet').removeClass('btn-info');
                                            $('#regSet').addClass('btn-success');
                                            window.location.reload();
                                        });
                                    });
                                });
                            </script>
                        </div>
                    </div>
                    <script>
                        //  alert('doneSD');
                        // Livewire.dispatch('event-DoneAddNum').then(() => {
                        //      alert('done');
                        // });
                    </script>
                    <?php
                    //   session()->forget(['employeeCounsellorAddMobile']);
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\employee\counsellor\addNumber.blade.php ENDPATH**/ ?>