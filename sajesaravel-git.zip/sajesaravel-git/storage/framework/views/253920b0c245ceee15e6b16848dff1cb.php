<div style=" " class=" p-0">
    <div wire:loading class="d-none">
        Saving post...
    </div>

    <?php $__env->startSection('header'); ?>
        <?php echo $__env->make('pages.prymhdv.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__env->stopSection(); ?>


    <?php echo $__env->make('livewire.dashboard.common.info', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\common\common-panel.blade.php ENDPATH**/ ?>