<div class="  px-2 justify-content-between   my-1   fontBold ">
    <div class="card p-1" style="background-color: #ddd; align-items: normal;">
        محتوا ، وبلاگ ، مجله
        
        <a href="<?php echo e(route('admin.dashboard.blog.Route')); ?>" target="_blank" class="card-userSection card card-body p-1  mt-2 ">
            <div class=" position-absolute bandX" style="  "></div>
            <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative">
                <span class="col">
                    <i class=" fas fa-address-card px-2"></i>
                    مدیریت
                </span>
                <span class="col">
                </span>
            </div>
        </a>
        
        <a href="<?php echo e(route('admin.show.blog.Route')); ?>" target="_blank"
            class="card-userSection card card-body p-1  mt-2  position-relative">
            <div class=" position-absolute bandX" style="  "></div>
            <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative">
                <span class="col">
                    <i class=" fas fa-address-card px-2"></i>
                    فعال سازی
                </span> 
            </div>
            <div class=" " style=" color:red; position: absolute; top:3px; left:3px;">
                <?php echo e(\App\Models\Blog\BlogPost::whereNotNull('title')->where(function ($query) {$query->where('active', '0')->orWhereNull('active');})->count()); ?>

             </div>
        </a>
        

        

        
        <a href="<?php echo e(route('show.blog.Route')); ?>"  class="card-userSection card card-body p-1 ">
            <div class=" position-absolute bandX" style="  "></div>
            <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative">
                <span class="col">
                    <i class=" fa fa-question-circle px-2"></i>
                    نمایش
                </span>

            </div>
        </a>
        
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/userSectionBlogs.blade.php ENDPATH**/ ?>