
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
<!-- Place favicon.ico in the root directory -->


<!--...............................................................................................................-->
<!-- Include jQuery ........................................................................... jQuery -->



<script src="<?php echo e(asset('storage/PrymhdvAssets/jq/jquery-3.7.1.min.js')); ?>"></script>


<!-- Include jQuery ........................................................................... jQuery -->

<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.3/themes/smoothness/jquery-ui.css">
<!-- Include bootstrap ...................bootstrap need jq..................................... jQuery -->


<!--...............................................................................................................-->
<link rel="stylesheet" href="<?php echo e(asset('storage/PrymhdvAssets/bootstrap-5.3.3-dist/css/bootstrap.min.css')); ?>">
<script src="<?php echo e(asset('storage/PrymhdvAssets/popper-2.11.8/popper.min.js')); ?>"></script>

<script src="<?php echo e(asset('storage/PrymhdvAssets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>  
<!--...............................................................................................................-->

<!--...............................................................................................................-->


<script src="<?php echo e(asset('storage/PrymhdvAssets/Selector/webroukCustomSelectIIABC.js')); ?>"></script>
<!--...............................................................................................................-->
<link rel="stylesheet" href="<?php echo e(asset('storage/PrymhdvAssets/fonts/fonts.css')); ?>">




<link rel="stylesheet" href="<?php echo e(asset('storage/PrymhdvAssets/owl/OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('storage/PrymhdvAssets/owl/OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css')); ?>">



<!-- fontawesome Solutions START------------------------------------------------------------------------------------------------------->
<script src="<?php echo e(asset('storage/PrymhdvAssets/fontawesome-free-6.7.1-web/js/all.min.js')); ?>"></script> 


<!-- fontawesome Solutions      ------------------------------------------------------------------------------------------------------->

<!-- fontawesome Solutions      ------------------------------------------------------------------------------------------------------->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- fontawesome Solutions END------------------------------------------------------------------------------------------------------->



<!--------------------------------------------------------------------------------------------------------->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/headLinkScripts.blade.php ENDPATH**/ ?>