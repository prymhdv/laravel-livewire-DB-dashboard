<a id="EmtehanatClick" class=" d-flex px-2 rotate-button2 shadow1 align-content-center  justify-content-center"
    wire:navigate href="<?php echo e(route('emtehanat_term_aval.index.Route')); ?>"
    style="color:white;cruser:pointer;font-weight:600;border-radius:12px;"><img
        src="<?php echo e(asset('storage/main/home/services/Icon-08.webp')); ?>" class=" p-1 px-2 " loading="lazy"
        style="width: 50px; ">
    <span class="align-content-center text-wrap text-center fs-4">
        دریافت جزوات و شبیه ترین سوالات امتحانات خرداد 1404
    </span>
    
    <span class=" align-content-center"><i class="fab fa-telegram fa-1x px-1 " style="color: #fff;"></i></span>
    
</a>

<style>
    #EmtehanatClick {
        transform: scale(1);
        transition: all 0.3s ease-in-out 0s;
        cursor: pointer;

        background-color: #013680 !important;
        border: 2px solid #003580 !important;
        ;
    }

    #EmtehanatClick:hover {
        transform: scale(1);
        background-color: #006aff !important;
        border: 2px solid #006aff !important;
        ;
    }

    .dvdvdvdv {
        box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset !important;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\emtehanat\boosterBTN.blade.php ENDPATH**/ ?>