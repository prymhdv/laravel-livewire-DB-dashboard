<a id="TakhminClick" class=" d-flex p-2 mt-1 rotate-button2 shadow1 align-content-center justify-content-center"
    
    
    href="https://formafzar.com/form/allqk"
    
    style="color:white;cruser:pointer;font-weight:600;border-radius:12px;">
    <span class="align-content-center text-wrap">
        
        سامانه جامع تخمین رتبه و اعلام رشته محل های قبولی
    </span>
</a>
<style>
    #TakhminClick {
        transform: scale(1);
        transition: all 0.3s ease-in-out 0s;
        cursor: pointer;

        background-color: #011f80 !important;
        border: 2px solid #011f80 !important;
    }


    #TakhminClick:hover {
        transform: scale(1);
        background-color: #0232d1 !important;
        border: 2px solid #0232d1 !important;
        ;
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\reserveBtn.blade.php ENDPATH**/ ?>