<div class=" px-2   justify-content-between  my-1   

">
    <div class="card p-1 fontBold " style="background-color: #ddd; align-items: normal;">
        کارمندان
        <div class="card-body p-0 mt-2">
            <a href="<?php echo e(route('main.counsellors.employee.adminPanelLivewireRoute')); ?>" wire:navigate 
                class="card-userSection card card-body p-1 
             
             
            <?php if(request()->route()->getName() == 'main.counsellors.employee.adminPanelLivewireRoute' || Str::contains(request()->route()->getName(), 'counsellors.employee')): ?> card-userSection-active <?php endif; ?>
             ">
                <div class=" position-absolute bandX" style="  "></div>
                <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative ">


                    <span class="col   ">
                        <i class="  fa fa-briefcase px-2 fa-1x"></i>
                        استخدام مشاور
                        <span style="color:green;">( <?php echo e(App\Models\UserEmployeeCounsellor::count()); ?> )</span>
                    </span>
                    <span class="col">
                        <!--[if BLOCK]><![endif]--><?php if(isset(Auth::user()->employee) &&
                                isset(Auth::user()->employee->counsellor) &&
                                Auth::user()->employee->counsellor->isCounsellor == 1): ?>
                            <i class="fa fa-check-circle  text-sanjesh-green"></i>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </span>
                </div>
            </a>
            <a href="<?php echo e(route('main.operators.employee.adminPanelLivewireRoute')); ?>" wire:navigate 
                class="card-userSection card card-body p-1 
         
        <?php if(request()->route()->getName() == 'main.operators.employee.adminPanelLivewireRoute'): ?> card-userSection-active <?php endif; ?>
         ">
                <div class=" position-absolute bandX" style="  "></div>
                <div class=" container-fluid p-0 row row-cols-auto  justify-content-between position-relative ">


                    <span class="col   ">
                        <i class="  fa fa-briefcase px-2 fa-1x"></i>
                        استخدام اپراتور
                         
                    </span>
                    <span class="col">
                        <?php if(isset(Auth::user()->employee) &&
                                isset(Auth::user()->employee->operator) &&
                                Auth::user()->employee->operator->isOperator == 1): ?>
                            <i class="fa fa-check-circle  text-sanjesh-green"></i>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </span>
                </div>
            </a>
        </div>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/userSectionEmployee.blade.php ENDPATH**/ ?>