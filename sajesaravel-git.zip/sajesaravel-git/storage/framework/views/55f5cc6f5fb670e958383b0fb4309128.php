<!--[if BLOCK]><![endif]--><?php if(request()->route()->getName() == 'login.users.adminPanelLivewireRoute'): ?>
    <div class="row p-1">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    ورود به حساب کاربری

                    <hr>
                    <div class="container text-center">
                        <div class="row justify-content-center align-content-center">
                            <div class="col-10 p-3 mt-5" style="border:1px solid #aaa; border-radius:7px;">
                                <form action="<?php echo e(route('sign.logInConfirm.Route')); ?>" method="POST" class="text-center">
                                    <?php echo csrf_field(); ?>
                                    <div class="row justify-content-center align-content-center   ">
                                        <div class="col-12">


                                            <div class="row mb-4">
                                                <webrouk-custom-select2 search-placeholder="جستجو..."
                                                    no-results="موردی یافت نشد...">
                                                    <select>  
                                                        <option value="" hidden>کاربر</option>
                                                        
                                                        
                                                        
                                                        
                                                    </select>
                                                </webrouk-custom-select2>
                                            </div>

                                            <div class="row">
                                                <label class="col-3 my-2" for="id">آیدی کاربر</label>
                                                <div class="col">
                                                    <input class="col my-2 text-center form-control" type="text"
                                                        name='id' placeholder="..UserId.." class="text-center">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger m-1"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                            <div class="row">
                                                <label class="col-3 my-2" for="userMobile">موبایل کاربر</label>
                                                <div class="col">
                                                    <input class="  my-2 text-center form-control" type="text"
                                                        name='userMobile' placeholder="..userMobile."
                                                        class="text-center">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['userMobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger m-1"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>


                                            <div class="row">
                                                <label class="col-3 my-2" for="passAdmin">رمز ادمین</label>
                                                <div class="col">
                                                    <input class=" my-2 text-center form-control" type="password"
                                                        name="passAdmin" placeholder="..AdminPass.."
                                                        class="text-center">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['passAdmin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger m-2"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 p-3 ">
                                            <button type="submit"
                                                class="btn btn-primary fs-3  mb-3 p-3 px-5">ورود</button>
                                        </div>
                                    </div>
                                </form>

                            </div>

                            <style>
                                .error-message {
                                    color: red;
                                    font-size: 14px;
                                    margin-top: 5px;
                                }
                            </style>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/dashboard/admin/user/login.blade.php ENDPATH**/ ?>