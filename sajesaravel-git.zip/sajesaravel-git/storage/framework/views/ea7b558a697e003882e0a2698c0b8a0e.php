<div id="carouselSelectedFadeC" class="carousel slide carousel-fade p-0 pry-border4 shadow1" data-bs-ride="carousel">
    <div class="carousel-inner">
      
      <?php
      for ($i = 1; $i <= 22; $i++) {
          $dontshow = [14, 30, 34];
          if (!in_array($i, $dontshow)) {
              if ($i == 1) {$active = 'active';} else {$active = '';}
              $p = asset("storage/assets/img/ser/IMG ($i).jpg");
              echo "<div class=\"carousel-item $active\">
                  <img loading=\"__eager__\" class=\"d-block w-100 pry-border1\" src=\"$p\" alt=\"انتخاب رشته\"></div>";
          }
      }
      ?>
      
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselSelectedFadeC" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselSelectedFadeC" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\student\entekhabReshte\BannerIII.blade.php ENDPATH**/ ?>