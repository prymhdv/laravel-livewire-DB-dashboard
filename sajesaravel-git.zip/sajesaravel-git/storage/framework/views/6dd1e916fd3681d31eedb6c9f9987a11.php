<!-- header -->
<header class="sticky-menuu shadow1 scrollFade">
    <div id="VimaPry" class="" style="overflow: hidden!important; height:initial;">
        <div class="areaX2" style=" height: 100%;">
            <ul class="circlesX2">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
        <div class="contextX2"></div>
    </div>
    <div class="main-header-area five-main-header-area pryh1" style="padding: 2px!important; padding-bottom: 0px;">
        <div class="container ">

            <div class="row justify-content-center align-content-center ">
                <div class="col-12 p-0">
                    <div id="mobile" class="  ">
                        <div class="row align-content-center">
                            <div class="col-6 col-lg-3 col-md-4 align-content-center p-1">
                                <div class="logo  ">
                                    <a href="<?php echo e(route('home.index.Route')); ?>">
                                        <img loading="lazy"
                                            src="<?php echo e(asset('storage/main/logo/bonyadlogo.svg')); ?>"
                                            class="" sizes="max-height:50px;" width="100%" alt="logo"></a>
                                </div>
                            </div>
                            <div class="col-lg-9 text-left d-none d-lg-block mt-3 ">
                                <?php echo $__env->make('pages.partials_menuI', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                            
                            <div class="col-12" style="  ">
                                <div class="mobile-menu" style="border-radius: 3px;"></div>
                            </div>
                            
                        </div>
                    </div>

                    <script>
                        function ShowDivMobile() {
                            var x = document.getElementById("myLinks");
                            if (x.style.display === "block") {
                                x.style.display = "none";
                            } else {
                                x.style.display = "block";
                            }
                        }
                    </script>
                    <style>
                        /* for browsers larger than 1200px width */
                        @media only screen and (max-width: 1200px) {
                            /* .pryh1{
                                max-height:70px!importan;
                                overflow:hidden!importan;
                           } */
                        }

                        @media (min-width: 768px) and (max-width: 991px) {
                            .main-header-area {
                                padding-top: 10px !important;
                                padding-bottom: 10px !important;
                            }
                        }
                    </style>
                    <div id="desktop" class="dpt-area d-none d-lg-block mt-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="dpt-menu s-dpt-menu text-center shadow1 "
                                    style="margin-top: -15px!important;">
                                    <?php echo $__env->make('pages.partials_menuDesktop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="headofset" style="width: 100%;" class="scrollFade2 mb-3
    
    "> 
</div>

<script>
    $(document).ready(function() {
        // Function to update the height of 'headofset'
        //console.log('header:',$('header').height());
        function updateHeight() {
            //console.log('header:',$('header').height(),$('#headofset').height());
            $('#headofset').height($('header').height() + $('header').height()*0.4);
        }

        // Initial height update
        updateHeight();

        // Update height on window resize
        $(window).resize(function() {

            updateHeight();
        });
    });
</script>





<!-- HockeyTeamListItem.vue -->




<style>
    @media (min-width: 1200px) {
        .container {
            max-width: 1170px;
        }
    }

    @media (min-width: 1400px) {
        .container {
            max-width: 1370px;
        }
    }
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\partialsIII\header.blade.php ENDPATH**/ ?>