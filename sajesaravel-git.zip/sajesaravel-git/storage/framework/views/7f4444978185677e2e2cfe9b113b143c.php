 <!DOCTYPE html>
 <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class=""
     style="width: 100%!important; max-width: 100%!important; min-width: 100%!important; overflow-x:hidden;">

 <head>
     <meta http-equiv="Cache-Control" content="max-age=1, public ,no-cache, no-store, must-revalidate">
     <meta http-equiv="Pragma" content="cache">
     <meta http-equiv="Expires" content="1">  
     
     <?php $__env->startSection('head'); ?>
         <?php echo $__env->make('components.layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->yieldSection(); ?>
     <?php echo $__env->make('components.layouts.bodyScripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.btn', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.text', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('components.prymhdvAssets.css.btnII', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('pages.layouts.TagAll', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

 </head>
 <?php $__env->startSection('home'); ?>
     <?php echo $__env->make('components.layouts.body', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 <?php echo $__env->yieldSection(); ?>
 <?php $__env->startSection('Dashboard'); ?>
     
 <?php echo $__env->yieldSection(); ?>


 </html>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>