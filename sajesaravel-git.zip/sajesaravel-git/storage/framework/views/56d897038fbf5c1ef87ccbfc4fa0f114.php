<style>
    .boxShadow1 {
        box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset;

    }

    .boxShadow1_3d {
        box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset;
        background: linear-gradient(135deg, #684c4c17 0, #62756b32 78%, #7a7a7b1d 100%);
    }

    .boxShadow1_3d_X {
        box-shadow: rgba(0, 0, 0, .4) 0 2px 4px, rgba(0, 0, 0, .3) 0 7px 13px -3px, rgba(0, 0, 0, .2) 0 -3px 0 inset;
        background: linear-gradient(135deg, #9b2f2f17 0, #28764c32 78%, #3131781d 100%);
    }

    .carousel img {
        border-radius: 7px;
    }
    /* //----------------- */
    /* ::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        border-radius: 8px;
        background-color: #F5F5F5;
    }
    ::-webkit-scrollbar {
        width: 12px;
        background-color: #F5F5F5;
    }
    ::-webkit-scrollbar-thumb {
        border-radius: 8px;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, .3);
        background-color: #555;
    } */
    /* //----------------- */
    ::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
        background-color: #F5F5F5;
        border-radius: 10px;
    }
    ::-webkit-scrollbar {
        width: 8px;
       
        background-color: #F5F5F5;
    }
       ::-webkit-scrollbar-thumb {
        border-radius: 10px;  
        background-color: #aaa;
         z-index:1001;
         height:200px;
    }
    ::-webkit-scrollbar-thumb:hover {
        border-radius: 10px;
        background-color: #FFF;
        background-image: -webkit-linear-gradient(top,
                #6e6e6e 100%,
                #bfe8f9 50%,
                #9fd8ef 51%,
                #535353 100%);
                
    }
    /* ------------- */
</style>

<script data-navigate-once>
    document.addEventListener("livewire:navigated", () => {
        //Livewire.hook('message.processed', (message, component) => {
        //    // Re-init Bootstrap carousel after Livewire update
        //    const carouselEl = document.querySelector('#carouselExampleFade');
        //    if (carouselEl) {
        //        const carousel = new bootstrap.Carousel(carouselEl, {
        //            interval: 5000, // or your custom value
        //            ride: 'carousel'
        //        });
        //    }
        //});
        $('.carousel img').each(function() {
            const img = $(this);
            //img.css('border-radius', '7px');
            const preloadImg = new Image();
            preloadImg.src = img.attr('src');
        });
        //const carouselEl = document.querySelector('#carouselExampleFade');
        $('.carousel').each(function() {
            const carouselEl = this; // Native DOM element
            const existing = bootstrap.Carousel.getInstance(carouselEl);
            if (existing) existing.dispose();
            new bootstrap.Carousel(carouselEl, {
                interval: 2500,
                ride: 'carousel'
            });
        });
    });
</script>

<script src="<?php echo e(asset('storage/asset/persian-tools/persian-tools.umd.js')); ?>"></script>
<script >
    // document.addEventListener("livewire:navigated", () => {
    //     (function() {
    //         $(".ValueFormater").on("change paste keyup", function() {
    //             /*console.log(PersianTools.digitsEnToFa(this.value),'---------');*/
    //             this.value = PersianTools.digitsEnToFa(PersianTools.digitsFaToEn(this.value));
    //         });
    //     }):
    // });

    "use strict";
    $(".ValueFormater").on("change paste keyup", function() {
        console.log(Comma(PersianTools.digitsEnToFa(this.value)),'---------'); 
        this.value = PersianTools.digitsEnToFa(Comma(PersianTools.digitsFaToEn(this.value)));
    });

    function Comma(Num) {
        Num += '';
        Num = Num.replace(',', '');
        Num = Num.replace(',', '');
        Num = Num.replace(',', '');
        Num = Num.replace(',', '');
        Num = Num.replace(',', '');
        Num = Num.replace(',', '');
        var x = Num.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1))
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        return x1 + x2;
    }

    function toFarsiNumber(n) {
        var o = "";
        n = n.toString();
        var farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        for (var i = 0; i < n.length; i++) {
            for (var j = 0; j < englishDigits.length; j++) {
                if (n.substr(i, 1) == englishDigits[j]) {
                    o = o + farsiDigits[j];
                }
            }
        }
        return o;
    }
</script>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/share.blade.php ENDPATH**/ ?>