<div id="Banner-Booster" class="col-md-6   align-content-center   ">
    <div class="d-none d-flex m-1 p-0 align-content-center justify-content-center" style=" border-radius:7px; ">
        
        <img loading="lazy"
        class="pry-border1 d-block w-100"
        src="<?php echo e(asset('storage/Pages/home/Banners/homeEmployeeCounsellor.webp')); ?>"
        alt="employment07">
    </div>
    
    <div id="Banner-Booster" class="col-12   align-content-center   ">
        <div class="d-flex m-1 p-0 align-content-center justify-content-center" style=" border-radius:7px; ">
            <div id="carouselExampleControlsNoTouching" class="carousel slide  p-1 m-auto " data-bs-touch="false">
                <div class="carousel-inner pry-border1 shadow1">
                    <div class="carousel-item active">
                        <img loading="lazy" class=" d-block w-100 " style="height:100%;width:auto;"
                        src="<?php echo e(asset('storage/main/employee/counsellor/main_employee_counsellor_I.webp')); ?>"
                        alt="">
                    </div>
                    <div class="carousel-item">
                        <img loading="lazy" class=" d-block w-100 " style="height:100%;width:auto;"
                            src="<?php echo e(asset('storage/main/employee/counsellor/main_employee_counsellor_II.webp')); ?>"
                            alt="">
                    </div>
                    <div class="carousel-item">
                        <img loading="lazy" class=" d-block w-100 " style="height:100%;width:auto;"
                            src="<?php echo e(asset('storage/main/employee/counsellor/main_employee_counsellor_III.webp')); ?>"
                            alt="">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\employee\counsellor\banner.blade.php ENDPATH**/ ?>