<div class=" ">
    <?php if(!isset(Auth::user()->student->booster->Isbooster)): ?>
        <script>
            document.addEventListener('livewire:navigated',
                () => {  Livewire.dispatchTo('sign-info-complete', 'switchModal1');   });
        </script>
    <?php endif; ?>
    <div class="row align-content-center  py-2 " style="   ">
        <div class="col-12  p-0  align-content-center   ">
            <div class="m-1 p-2 shadow1   text-end boxShadow1_3d" style="  border-radius:7px; ">
                <img <?php if(Auth::user()->personal && Auth::user()->personal->userPhotoPath): ?> src="<?php echo e(asset(Auth::user()->personal->userPhotoPath)); ?>"
                <?php else: ?>
                
                 src="<?php echo e(asset('storage/PrymhdvAssets/Logo/user.webp')); ?>" <?php endif; ?>
                    alt="" class=" text-start p-2" style=" width:80px; scale:1.2;  border-radius:50%; aspect-ratio: 1;">
                پرتال کاربری:
                <?php switch(Auth::user()->role):
                    case ('admins'): ?>
                        <span class="mx-1">ادمین</span>
                    <?php break; ?>

                    <?php case ('operators'): ?>
                        <span class="mx-1">اوپراتور</span>
                    <?php break; ?>

                    <?php case ('teachers'): ?>
                        <span class="mx-1">معلم</span>
                    <?php break; ?>

                    <?php case ('customers'): ?>
                        <span class="mx-1">مشتری</span>
                    <?php break; ?>

                    <?php case ('counselors'): ?>
                        <span class="mx-1">مشاور</span>
                    <?php break; ?>

                    <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                        <span class="mx-1">دانش آموز</span>
                    <?php break; ?>

                    <?php default: ?>
                        <span><?php dd('با شماره زیر تماس بگیرید.. tell:+989907428464'); ?></span>
                <?php endswitch; ?>
                <div class="col-12 position-relative" style="height: 20px;">

                    <div style=" left:0;" class=" position-absolute bottom-0  p-0">
                        <a class=" btn btn-outline-dark fs-3 "  
                            onclick="Livewire.dispatchTo('auth.sign-info-complete','switchModal')">تکمیل اطلاعات شخصی
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col p-0">
            <div class="m-1 p-2 boxShadow1_3d" style="background-color: #ddd0; border-radius:7px; ">
                <div class="d-flex">
                    <div class="col text-end">نام:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->nameFirst); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col text-end">نام خانوادگی:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->nameLast); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col text-end">کدملی:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->codeMeli ?? ''); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col text-end">موبایل:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->mobile); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col text-end">رشته تحصیلی:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->student->field ?? ''); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col text-end">پایه تحصیلی:</div>
                    <div class="col text-end"><?php echo e(Auth::user()->student->field_Base ?? ''); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\student\userInfo.blade.php ENDPATH**/ ?>