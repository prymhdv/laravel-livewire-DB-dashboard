
<div class=" position-relative d-none ">
    <div class="areaX2">
        <ul class="circlesX2">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <div class="contextX2"></div>
</div>

<div id="menu_bottom_container0" class="container-fluid fixed-bottom shadow1 efect1-off p-0 "
    style="  height: 80px;  z-index:101!important; background-color: var(--color_sanjesh_blue);">
    <div class=" position-relative w-100">
        <div class="areaX2">
            <ul class="circlesX2">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
        <div class="contextX2"></div>
    </div>
</div>
<div id="menu_bottom_container" class="container-fluid fixed-bottom shadow1   "
    style="  height: 50px;  direction:ltr!important; z-index:102!important; ">
    <div id="menu_bottom" class="container     ">
        <div class=" row  bg-opacity-100 menuBox position-relative">
            
            <div class="col  position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1 ">
                <a  aria-label="home" data-path="main.Route" class="HomeMenuIcone" style=""
                    href="<?php echo e(route('home.index.Route')); ?>" >
                    <i class="  fas fa-home fa-2x icons <?php if(Request::is('/')): ?> selected-page <?php endif; ?> "></i>
                </a>
                <p class="   font-peyda  mt-3  ">خانه</p>
            </div>
            

            <div class="col  position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1 ">
                <a wire:navigate aria-label="home" data-path="main.Route" class="HomeMenuIcone" style=""
                    >
                    <i
                        class=" fa-solid fa-store  fa-2x icons  <?php if(Request::is('*confrence*')): ?> selected-page <?php endif; ?> "></i>
                </a>
                <p class="   font-peyda  mt-3  ">فروشگاه</p>
            </div>
            
            <div class="col   position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1"
                style="height: 25px; visibility: show;">
                <a wire:navigate data-path="adver.searcher.Route" class="HomeMenuIcone "
                    aria-label="adver searcher" >
                    <i class=" fas fa-book fa-2x  icons <?php if(Request::is('*entekhabReshte*')): ?> selected-page <?php endif; ?>"></i>

                </a>
                <p class=" font-peyda  mt-3 ">جزوات</p>
            </div>

            
            <div class="col   position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1"
                style="height: 25px; visibility: show;">
                <a wire:navigate data-path="adver.searcher.Route" class="HomeMenuIcone "
                    aria-label="adver searcher" >
                    <i
                        class=" fas fa-chalkboard-teacher fa-2x icons <?php if(Request::is('*entekhabReshte*')): ?> selected-page <?php endif; ?>"></i>

                </a>
                <p class=" font-peyda  mt-3 ">کلاس ها</p>
            </div>

            
            <?php if(!Auth::check()): ?>
                <div class="col   position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1 text-decoration-none "
                    style="height: 25px; ">
                    <a class="HomeMenuIcone" >
                        <i
                            class="  fas fa-user-graduate  fa-2x  icons 
                        <?php if(Request::is('*Dashboard*')): ?> selected-page <?php endif; ?>"></i>

                    </a>
                    <p class=" font-peyda  mt-3 ">داشبورد</p>
                </div>
            <?php else: ?>
                <div class="col  position-relative  bg-gray-500  align-middle text-center p-2  mb-auto1 ">
                    <a class="HomeMenuIcone " wire:navigate
                        <?php switch(Auth::user()->role): 
                                        case ('admins'): ?>
                                            href="<?php echo e(route('panel.DashboardAdminLivewireRoute')); ?>" 
                                        <?php break; ?>

                                        <?php case ('operators'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('teachers'): ?>
                                            href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('customers'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('counselors'): ?>
                                                href="<?php echo e(route('home.index.Route')); ?>" 
                                        <?php break; ?>

                                        <?php case ('normal' || 'معمولی' || 'دانش آموز بوستر'): ?>
                                            href="<?php echo e(route('panel.DashboardStudentLivewireRoute')); ?>" 
                                        <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?>>
                        <i
                            class=" fa-solid fa-user-graduate  fa-2x icons text-decoration-none
                         <?php if(Request::is('*dashboard*')): ?> selected-page <?php endif; ?>">
                        </i>
                    </a>
                    <p class=" font-peyda mt-3">داشبورد</p>
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</div>

<style>
    /*   background-color: #4daf50;  color: var(--color_sanjesh_blue); */
    #menu_bottom_container {

        color: #ffffff !important;
        /* background-color: var(--color_sanjesh_blue); */
        background-color: initial;
    }


    #menu_bottom_container p {

        color: #ffffff !important;
        /* background-color: var(--color_sanjesh_blue); */
        transition: 0.25s;
        background-color: initial;
    }



    .icons {
        cursor: pointer;
        transition: ease-in-out all 0.3s !important;
        color: var(--color_sanjesh_green);
        /* text-shadow: 3px 1px 8px rgba(1, 0, 6, 0.98)!important; */
        /* background: initial; */
        /* background-color: initial; */
        text-shadow: 0 1px 0 #CCCCCC, 0 2px 0 #c9c9c9, 0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0, 0, 0, .1), 0 0 5px rgba(0, 0, 0, .1), 0 1px 3px rgba(0, 0, 0, .3), 0 3px 5px rgba(0, 0, 0, .2), 0 5px 10px rgba(0, 0, 0, .25), 0 10px 10px rgba(0, 0, 0, .2), 0 20px 20px rgba(0, 0, 0, .15) !important;
        background: radial-gradient(circle farthest-corner at center center, var(--color_sanjesh_green) 9%, #e4e4ea 97%) !important;
        -webkit-background-clip: text !important;
    }

    .icons:hover {
        color: var(--color_sanjesh_green) !important;
    }

    /* #menu_bottom_container:has(i) { */
    /* #menu_bottom_container>i { */
    /* Apply styles to #menu_bottom_container when it contains an <i> element */
    /* color: var(--color_sanjesh_green) !important; */
    /* Example: change background color */
    /* } */

    #menu_bottom_container i:hover {
        color: var(--color_sanjesh_green);

    }

    .HomeMenuIcone {
        position: absolute;
        left: 0;
        right: 0;
        top: -15px;
        cursor: default;
    }

    .mb-auto1 {
        margin-bottom: 2.2rem;
    }

    .selected-page {
        color: var(--color_sanjesh_green) !important;
    }



    /* .selected-page::after {
          border-radius:50%!important;;
         border:4px solid var(--color_yellow) !important;
        content: "";
        border-bottom: 4px solid var(--color_yellow) !important;;
       
        display: inline-block;
      
        width: 100%;
         
    } */
</style>
<script>
    // $('#menu_bottom_container').has('i').css('color', '#f0f0f0');
</script>


<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\partials\Menu.blade.php ENDPATH**/ ?>