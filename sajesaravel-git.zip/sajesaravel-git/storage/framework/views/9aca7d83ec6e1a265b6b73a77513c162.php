<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>بنیاد سنجش | <?php echo $__env->yieldContent('pageTitle'); ?></title>
<!-- Fonts -->


<meta name="csrf_token" value="<?php echo e(csrf_token()); ?>"/>

<meta name="description"
    content="بزرگترين موسسهٔ آموزشی کشور؛ پیشرو در ارایهٔ آموزش‌های حضوری و آنلاین، جلسات مشاوره و برنامه‌ریزی، با ۱۰ سال سابقهٔ فعالیت آموزشی و کسب رتبه‌های برتر و تک‌رقمی در سال‌های اخیر.">
<meta name="enamad" content="143392" />
<meta name="author" content="SanjeshBonyad.org">
<meta name="keywords"
    content="همایش بزرگ, بنیاد سنجش, بورسیه تحصیلی, اساتید کنکور, کلاس کنکور, مشاوره تحصیلی, آزمون هفتگی, برنامه‌ریزی درسی, پایه نهم, پایه دهم, پایه یازدهم, پایه دوازدهم, پشت کنکوری, آموزش, استاد آریان حیدری, استاد محمد همدانی, کتب کمک آموزشی, مشاوران تحصیلی برتر, بنیاد سنجش ایران">

<?php
// Set the cache to expire 3 days from today
// $expireDate = gmdate('D, d M Y H:i:s', time() + 259200) . ' GMT';
// // $expireDate = gmdate('D, d M Y H:i:s', 0 + 0) . ' GMT';
// // Send the appropriate cache headers
// header('Cache-Control: max-age=3,600, public');
// //86400 seconds (= 24 hours). 86400
// header("Cache-Control: max-age=$expireDate+, public");
// header("Expires: $expireDate");

?>



 
 
 
 <meta name="referrer" content="origin-when-cross-origin" />

 
 
 <?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\layouts\headMeta.blade.php ENDPATH**/ ?>