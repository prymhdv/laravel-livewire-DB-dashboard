<style>
    /* --------------------------------------------------s (mediatype: print, screen, or speech).-- (orientation: landscape) ------ */
    /* html {
    font-size: 16px !important;
} */
    /* body { */
    /* margin: 0px !important;
    padding: 0px !important; */
    /*word-spacing: -3.5px;*/
    /* word-spacing: normal !important;
    overflow-x: hidden !important;
    font-size: 1rem !important; */
    /* } */

    /* @media only screen and (max-width: 800px) {
    html {
        font-size: 8px !important;
    }
} */

    /* .container-fluid {
    width: 100%;
    padding-right: 0px !important;
    padding-left: 0px !important;
    margin-right: auto;
    margin-left: auto;
} */

    /* .row { */
    /* align-items: stretch !important;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding-right: 0px !important;
    padding-left: 0px !important;
    margin-right: 0px !important;
    margin-left: 0px !important; */
    /* width: 100%!important;;
    max-width: 100%!important;;
    height: 100%!important;;
    max-height: 100%!important;; */
    /* } */
    /* .row > * { */
    /* width: inherit!important;;
    max-width: inherit!important;;
    height: inherit!important;;
    max-height: inherit!important;; */
    /*=====================================*/
    .bg-violate {
        background-color: var(--color_blue) !important;
    }

    .text-violate {
        color: var(--color_blue) !important;
    }

    .bg-sanjesh-blue {
        background-color: var(--color_sanjesh_blue) !important;
    }

    .text-sanjesh-blue {
        color: var(--color_sanjesh_blue) !important;
    }

    .bg-sanjesh-green {
        background-color: var(--color_sanjesh_green) !important;
    }

    .text-sanjesh-green {
        color: var(--color_sanjesh_green) !important;
    }

    .bg-sanjesh-orange {
        background-color: orange !important;
    }

    /* ===================================== */
   

    /* ===================================== */

    .s-dpt-menu {
        margin-top: -30px;
        background: #fff;
        border-radius: 7px;
        padding: 0 0px !important;
        margin-bottom: -30px;
    }

    /* ---------------------------------------------------------- */
    input::placeholder {
        font-weight: bold;
        opacity: 0.5;
        color: green;
    }

    .font-sans {
        font-family: "iransans" !important;
        font-size: 16px !important;
    }

    .shadow1 {
        box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 1px,
            rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;
    }

    .shadow1-light {
        box-shadow: rgba(60, 64, 67, 0.1) 0px 1px 2px 1px,
            rgba(60, 64, 67, 0.05) 0px 1px 3px 1px;
    }

    .shadow-up {
        box-shadow: rgba(60, 64, 67, 0.3) 0px -1px 2px 0px,
            rgba(60, 64, 67, 0.15) 0px -1px 3px 1px;
    }

    .borderSet1 {
        /* border: 1px solid #eee; */
        border-radius: 12px;
        overflow: hidden;
    }


    .pry-video1 {
        border: 10px solid #333;
        border-radius: 31px;
        overflow: hidden;
        padding: 0px;
        /* aspect-ratio: 16 / 9; */
    }

    /* -------------------------------------------------- */

    .fsr-00 {
        font-size: 0rem !important;
    }

    .fsr-02 {
        font-size: 0.2rem !important;
    }

    .fsr-04 {
        font-size: 0.4rem !important;
    }

    .fsr-06 {
        font-size: 0.6rem !important;
    }

    .fsr-08 {
        font-size: 0.8rem !important;
    }

    .fsr-10 {
        font-size: 1rem !important;
    }

    .fsr-12 {
        font-size: 1.2rem !important;
    }

    .fsr-14 {
        font-size: 1.41rem !important;
    }

    .fsr-16 {
        font-size: 1.6rem !important;
    }

    .fsr-18 {
        font-size: 1.8rem !important;
    }

    .fsr-20 {
        font-size: 2rem !important;
    }

    .fsr-22 {
        font-size: 2.2rem !important;
    }

    .fsr-24 {
        font-size: 2.4rem !important;
    }

    .fsr-26 {
        font-size: 2.6rem !important;
    }

    .fsr-28 {
        font-size: 2.8rem !important;
    }

    .fsr-30 {
        font-size: 3rem !important;
    }

    .btn-Sanjesh1 {
        border-radius: 7px !important;
        border: 3px solid #eeeeee99 !important;
        background-color: #48a04b !important;
        /* width: 200px; */
        /* padding: 0.15rem 0.75rem!important; */
        /* margin: 30px auto !important; */
        /* color: #000!important; */
        font-weight: 400;
        /* border-color: rgba(255, 255, 255, 0);
            background: #f1da36;
            background: -moz-linear-gradient(left, #f1da36 0%, #fca86c 99%);
            background: -webkit-linear-gradient(left, #f1da36 0%, #fca86c 99%);
            background: linear-gradient(to right, #f1da36 0%, #fca86c 99%); */
        direction: rtl !important;
        transition: all;
    }

    .btn-Sanjesh1:hover {
        color: #eee !important;
        background-color: #48a04b !important;
        transform: scale(1.05);
        transition: all 0.3s ease-in-out 0s;
        cursor: pointer;
    }

    /* -------------------------------------------------- */

    .hideMe {
        -moz-animation: cssAnimation 0s ease-in 7s forwards;
        /* Firefox */
        -webkit-animation: cssAnimation 0s ease-in 7s forwards;
        /* Safari and Chrome */
        -o-animation: cssAnimation 0s ease-in 7s forwards;
        /* Opera */
        animation: cssAnimation 0s ease-in 7s forwards;
        -webkit-animation-fill-mode: forwards;
        animation-fill-mode: forwards;
    }

    /* -------------------------------------------------- */

    /* -------------------------------------------------- */

    /* ---------------------------- */
    .efect1 {
        display: flex;
        justify-content: center;
        align-items: center;
        /* background-color: #007bff; */
        border-radius: 7px;
        transition: background-color 0.3s ease;
        color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        /* position: relative; */
        overflow: hidden !important;
    }

    .efect1::after {
        content: "";
        position: absolute;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: rgba(39, 38, 38, 0.755);
        top: -1%;
        left: -50%;
        animation: inner_left 2s infinite;
        z-index: 2030 !important;
        /* z-index cant lowerthan parent but transparent color zero before */
    }

    @keyframes ripple {
        to {
            transform: scale(3);
            opacity: 0;
        }

        50% {
            left: 300px;
        }
    }

    @keyframes inner_left {
        0% {
            transform: skewX(-90deg);
        }

        25% {
            transform: skewX(-90deg);
        }

        50% {
            transform: skewX(86.4deg);
        }

        75% {
            transform: skewX(86.4deg);
        }

        100% {
            transform: skewX(-90deg);
        }
    }

    /*-------------------------------------------------- */
    /* <div class="area">
  <ul class="circles">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
</div>
<div class="context">
  <h1>Texto centrado</h1>
</div> */
    /* ----------------------------------------------- */

    /* * {
  margin: 0px;
  padding: 0px;
}  */
    /* body {
  font-family: "Exo", sans-serif;
} */
    .contextX2 {
        font-family: "Exo", sans-serif;
        width: 100%;
        position: absolute;
        top: 50vh;
    }

    .contextX2 h1 {
        text-align: center;
        color: #fff;
        font-size: 50px;
    }

    .areaX2 {
        font-family: "Exo", sans-serif;
        /* background: #4e54c8; */
        background: -webkit-linear-gradient(to left, #8f94fb, #4e54c8);
        width: 100%;
        height: 100vh;
    }

    .circlesX2 {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
    }

    .circlesX2 li {
        position: absolute;
        display: block;
        list-style: none;
        width: 20px;
        height: 20px;
        background: rgba(255, 255, 255, 0.2);
        animation: animate 12s linear infinite;
        bottom: -150px;
    }

    .circlesX2 li:nth-child(1) {
        left: 25%;
        width: 80px;
        height: 80px;
        animation-delay: 0s;
    }

    .circlesX2 li:nth-child(2) {
        left: 10%;
        width: 20px;
        height: 20px;
        animation-delay: 1s;
        animation-duration: 6s;
    }

    .circlesX2 li:nth-child(3) {
        left: 70%;
        width: 20px;
        height: 20px;
        animation-delay: 2s;
    }

    .circlesX2 li:nth-child(4) {
        left: 40%;
        width: 60px;
        height: 60px;
        animation-delay: 0s;
        animation-duration: 9s;
    }

    .circlesX2 li:nth-child(5) {
        left: 65%;
        width: 20px;
        height: 20px;
        animation-delay: 0s;
    }

    .circlesX2 li:nth-child(6) {
        left: 75%;
        width: 110px;
        height: 110px;
        animation-delay: 1500ms;
    }

    .circlesX2 li:nth-child(7) {
        left: 35%;
        width: 150px;
        height: 150px;
        animation-delay: 3500ms;
    }

    .circlesX2 li:nth-child(8) {
        left: 50%;
        width: 25px;
        height: 25px;
        animation-delay: 7500ms;
        animation-duration: 24500ms;
    }

    .circlesX2 li:nth-child(9) {
        left: 20%;
        width: 15px;
        height: 15px;
        animation-delay: 1s;
        animation-duration: 17500ms;
    }

    .circlesX2 li:nth-child(10) {
        left: 85%;
        width: 150px;
        height: 150px;
        animation-delay: 0s;
        animation-duration: 5500ms;
    }

    @keyframes animate {
        0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
            border-radius: 0;
        }

        100% {
            transform: translateY(-1000px) rotate(720deg);
            opacity: 0;
            border-radius: 50%;
        }
    }

    /* ----------------------------------------------- */
    .bubbles {
        /* position: relative; */
        width: 100%;
        height: 100vh;
        /* overflow: hidden; */
    }

    .bubble {
        position: absolute;
        left: var(--bubble-left-offset);
        bottom: -75%;
        display: block;
        width: var(--bubble-radius);
        height: var(--bubble-radius);
        border-radius: 50%;
        animation: float-up var(--bubble-float-duration) var(--bubble-float-delay) ease-in infinite;
    }

    .bubble::before {
        position: absolute;
        content: "";
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(136, 146, 251, 0.3);

        border-radius: inherit;
        animation: var(--bubble-sway-type) var(--bubble-sway-duration) var(--bubble-sway-delay) ease-in-out alternate infinite;
    }

    .bubble:nth-child(0) {
        --bubble-left-offset: 93vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(1) {
        --bubble-left-offset: 57vw;
        --bubble-radius: 4vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(2) {
        --bubble-left-offset: 41vw;
        --bubble-radius: 7vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(3) {
        --bubble-left-offset: 60vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(4) {
        --bubble-left-offset: 16vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(5) {
        --bubble-left-offset: 37vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(6) {
        --bubble-left-offset: 80vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(7) {
        --bubble-left-offset: 37vw;
        --bubble-radius: 6vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(8) {
        --bubble-left-offset: 14vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(9) {
        --bubble-left-offset: 46vw;
        --bubble-radius: 3vw;
        --bubble-float-duration: 6s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(10) {
        --bubble-left-offset: 49vw;
        --bubble-radius: 4vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(11) {
        --bubble-left-offset: 10vw;
        --bubble-radius: 4vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(12) {
        --bubble-left-offset: 11vw;
        --bubble-radius: 7vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(13) {
        --bubble-left-offset: 58vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(14) {
        --bubble-left-offset: 79vw;
        --bubble-radius: 3vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(15) {
        --bubble-left-offset: 49vw;
        --bubble-radius: 4vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(16) {
        --bubble-left-offset: 29vw;
        --bubble-radius: 8vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(17) {
        --bubble-left-offset: 2vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(18) {
        --bubble-left-offset: 93vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(19) {
        --bubble-left-offset: 48vw;
        --bubble-radius: 1vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(20) {
        --bubble-left-offset: 89vw;
        --bubble-radius: 6vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(21) {
        --bubble-left-offset: 8vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(22) {
        --bubble-left-offset: 64vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(23) {
        --bubble-left-offset: 31vw;
        --bubble-radius: 7vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(24) {
        --bubble-left-offset: 23vw;
        --bubble-radius: 2vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(25) {
        --bubble-left-offset: 62vw;
        --bubble-radius: 6vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(26) {
        --bubble-left-offset: 70vw;
        --bubble-radius: 3vw;
        --bubble-float-duration: 6s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(27) {
        --bubble-left-offset: 82vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(28) {
        --bubble-left-offset: 41vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(29) {
        --bubble-left-offset: 36vw;
        --bubble-radius: 2vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(30) {
        --bubble-left-offset: 63vw;
        --bubble-radius: 2vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(31) {
        --bubble-left-offset: 93vw;
        --bubble-radius: 7vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(32) {
        --bubble-left-offset: 20vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(33) {
        --bubble-left-offset: 89vw;
        --bubble-radius: 1vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(34) {
        --bubble-left-offset: 96vw;
        --bubble-radius: 10vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(35) {
        --bubble-left-offset: 42vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(36) {
        --bubble-left-offset: 42vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 7s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(37) {
        --bubble-left-offset: 59vw;
        --bubble-radius: 10vw;
        --bubble-float-duration: 12s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(38) {
        --bubble-left-offset: 90vw;
        --bubble-radius: 8vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(39) {
        --bubble-left-offset: 66vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 3s;
        --bubble-sway-delay: 3s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(40) {
        --bubble-left-offset: 69vw;
        --bubble-radius: 2vw;
        --bubble-float-duration: 9s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(41) {
        --bubble-left-offset: 21vw;
        --bubble-radius: 1vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 4s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(42) {
        --bubble-left-offset: 12vw;
        --bubble-radius: 2vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(43) {
        --bubble-left-offset: 46vw;
        --bubble-radius: 3vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(44) {
        --bubble-left-offset: 45vw;
        --bubble-radius: 3vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 2s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(45) {
        --bubble-left-offset: 98vw;
        --bubble-radius: 8vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 1s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(46) {
        --bubble-left-offset: 50vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 4s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(47) {
        --bubble-left-offset: 47vw;
        --bubble-radius: 6vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 0s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-left-to-right;
    }

    .bubble:nth-child(48) {
        --bubble-left-offset: 26vw;
        --bubble-radius: 5vw;
        --bubble-float-duration: 11s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 4s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(49) {
        --bubble-left-offset: 44vw;
        --bubble-radius: 9vw;
        --bubble-float-duration: 10s;
        --bubble-sway-duration: 6s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 0s;
        --bubble-sway-type: sway-right-to-left;
    }

    .bubble:nth-child(50) {
        --bubble-left-offset: 68vw;
        --bubble-radius: 4vw;
        --bubble-float-duration: 8s;
        --bubble-sway-duration: 5s;
        --bubble-float-delay: 2s;
        --bubble-sway-delay: 1s;
        --bubble-sway-type: sway-right-to-left;
    }

    @keyframes float-up {
        to {
            transform: translateY(-175vh);
        }
    }

    @keyframes sway-left-to-right {
        from {
            transform: translateX(-100%);
        }

        to {
            transform: translateX(100%);
        }
    }

    @keyframes sway-right-to-left {
        from {
            transform: translateX(100%);
        }

        to {
            transform: translateX(-100%);
        }
    }

    /* ----------------------------------------------- */

    /* <!-- HTML !-->
<button class="button-82-pushable" role="button">
  <span class="button-82-shadow"></span>
  <span class="button-82-edge"></span>
  <span class="button-82-front text">
    Button 82
  </span>
</button> */

    /* CSS */
    .button-82-pushable {
        position: relative;
        border: none;
        background: transparent;
        padding: 0;
        cursor: pointer;
        outline-offset: 4px;
        transition: filter 250ms;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
    }

    .button-82-shadow {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 12px;
        background: hsl(0deg 0% 0% / 0.25);
        will-change: transform;
        transform: translateY(2px);
        transition: transform 600ms cubic-bezier(0.3, 0.7, 0.4, 1);
    }

    .button-82-edge {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 12px;
        background: linear-gradient(to left,
                hsl(340deg 100% 16%) 0%,
                hsl(340deg 100% 32%) 8%,
                hsl(340deg 100% 32%) 92%,
                hsl(340deg 100% 16%) 100%);
    }

    .button-82-front {
        display: block;
        position: relative;
        padding: 6px 13px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-size: 11px;
        color: white;
        background: hsl(345deg 100% 47%);
        will-change: transform;
        transform: translateY(-4px);
        transition: transform 600ms cubic-bezier(0.3, 0.7, 0.4, 1);
    }

    .button-82-edge_green {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 12px;
        background: linear-gradient(to left,
                #105200 0%,
                hsl(120, 100%, 32%) 8%,
                hsl(125, 100%, 32%) 92%,
                hsl(110, 100%, 16%) 100%);
    }


    .button-82-front_green {
        display: block;
        position: relative;
        padding: 6px 13px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-size: 11px;
        color: white;
        background: hsl(123, 100%, 47%);
        will-change: transform;
        transform: translateY(-4px);
        transition: transform 600ms cubic-bezier(0.3, 0.7, 0.4, 1);
    }

    @media (min-width: 768px) {

        .button-82-front,
        .button-82-sky {
            font-size: 1.25rem;
            /* font-size: 12px; */
            padding: 12px 42px;
        }
    }

    .button-82-pushable:hover {
        filter: brightness(110%);
        -webkit-filter: brightness(110%);
    }

    .button-82-pushable:hover .button-82-front,
    .button-82-sky {
        transform: translateY(-6px);
        transition: transform 250ms cubic-bezier(0.3, 0.7, 0.4, 1.5);
    }

    .button-82-pushable:active .button-82-front,
    .button-82-sky {
        transform: translateY(-2px);
        transition: transform 34ms;
    }

    .button-82-pushable:hover .button-82-shadow {
        transform: translateY(4px);
        transition: transform 250ms cubic-bezier(0.3, 0.7, 0.4, 1.5);
    }

    .button-82-pushable:active .button-82-shadow {
        transform: translateY(1px);
        transition: transform 34ms;
    }

    .button-82-pushable:focus:not(:focus-visible) {
        outline: none;
    }

    /* --------------------------------------------------------------- */
    /* Define basic button style */
    .rotate-btn {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border: 2px solid #007bff;
        background-color: #007bff;
        color: white;
        border-radius: 5px;
        transition: transform 0.5s ease;
    }

    /* Rotation animation */
    @keyframes rotateAnimation {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }

    /* Class to trigger the animation */
    .rotating {
        animation: rotateAnimation 1s linear;
    }

    /* --------------------------------------------------------------- */
</style>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/prymhdvAssets/css/btnII.blade.php ENDPATH**/ ?>