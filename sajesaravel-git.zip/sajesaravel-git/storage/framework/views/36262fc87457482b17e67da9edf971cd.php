<?php if(request()->route()->getName() == 'main.counsellors.fieldSelection.student.adminPanelLivewireRoute' ||
        request()->route()->getName() == 'manage.counsellors.fieldSelection.student.adminPanelLivewireRoute' ||
        request()->route()->getName() == 'info.counsellors.fieldSelection.student.adminPanelLivewireRoute' ||
        request()->route()->getName() == 'allotment.counsellors.fieldSelection.student.adminPanelLivewireRoute'): ?>
    <?php
        if (!Str::contains($this?->pageState??'', 'admin.student.fieldSelection.counsellor.main')) {
            $this->pageState = 'admin.student.fieldSelection.counsellor.main';
        }
    ?>
    
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-4">
                <a class="hover4 d-block justify-items-center align-content-center  flex-nowrap" wire:navigate
                    href="<?php echo e(route('manage.counsellors.fieldSelection.student.adminPanelLivewireRoute')); ?>"
                    style=" ">
                    حذف ، اضافه مشاوران
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" wire:navigate
                    href="<?php echo e(route('allotment.counsellors.fieldSelection.student.adminPanelLivewireRoute')); ?>"
                    style=" ">
                    تخصیص ، استرداد دانش‌آموزان
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    تغییر مشاور
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center" style=" ">
                    XXXX-XX-XXX
                </a>
            </div>
            <hr class="m-0">

        </div>
        <?php if(request()->route()->getName() == 'main.counsellors.fieldSelection.student.adminPanelLivewireRoute'): ?>
            <div class="col-md-8 mt-2 p-2" style="background-color: #ffffff; border-radius:8px;">

                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد مشاوران</div>
                    <div class="col-md-6">
                        <span
                            style="color:rgb(0, 0, 0);"><?php echo e(App\Models\UserEmployeeCounsellorFieldSelection::count()); ?></span>
                        /
                        <span
                            class=""style="color:#04ff04;"><?php echo e(App\Models\UserEmployeeCounsellorFieldSelection::where('status', 'active')->count()); ?></span>


                    </div>
                </div>
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد مشاوران تخصیص گرفته</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>
                <hr class="m-0">
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>
                <hr class="m-0">
                <div class="row justify-content-between  ">
                    <div class="col-md-6 text-end">تعداد دانش‌آموزان تخصیص داده شده</div>
                    <div class="col-md-6">XXXX-XX-XXX</div>
                </div>

            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\student\fieldSelection\counsellor\main.blade.php ENDPATH**/ ?>