<style>
    a:hover {
        cursor: pointer;
    }
</style><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\dashboard\layouts\headStyle.blade.php ENDPATH**/ ?>