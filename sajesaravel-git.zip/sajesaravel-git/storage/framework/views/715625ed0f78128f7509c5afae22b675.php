<svg style="vertical-align: middle;"
    <?php echo e($attributes->merge(['class' => 'inline-block'])); ?> 
    xmlns="http://www.w3.org/2000/svg"
    fill="<?php echo e($fill ?? 'currentColor'); ?>"  
    width="<?php echo e($width ?? '24'); ?>" 
    height="<?php echo e($height ?? '24'); ?>" 
    >
    <?php echo file_get_contents(public_path("storage/assets/svg/$icon.svg")); ?>

</svg>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\components\solids\svg-icon.blade.php ENDPATH**/ ?>