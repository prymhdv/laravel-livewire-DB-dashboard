<div class="row justify-content-center">
    <span class="col-md-10">
        <ul class="list-group my-2">
            <li class="text-center  list-group-item">
                    قوانین شرکت در آزمون
            </li>
            <li class="text-end list-group-item list-group-item-secondary  ">
                ✅ فرآیند آزمون از ساعت 10:00 تاریخ 22 فروردین 1404 آغاز خواهد شد.
            </li>
            <li class="text-end  list-group-item">
                ✅ مدت زمان آزمون 100 دقیقه می‌باشد و علاوه بر آن 20 دقیقه زمان اضافی
                برای
                متقاضیان در نظر گرفته شده است.
            </li>
            <li class="text-end list-group-item list-group-item-secondary"> ✅ آزمون شامل 100 سوال چهارگزینه‌ای می‌باشد و پس از پاسخ به سوال
                امکان بازگشت به
                سوالات قبلی و تغییر گزینه وجود ندارد ؛ بنابراین در انتخاب گزینه دقت
                فرمایید.
            </li>
            <li class="text-end list-group-item">
                ✅ شرکت در آزمون برای هر داوطلب، تنها یک بار ممکن است و امکان شرکت
                مجدد در آزمون
                فراهم نیست.
            </li>
            <li class="text-end list-group-item list-group-item-secondary">
                ✅ حد نصاب قبولی کسب نمره 70 از 100 می‌باشد و آزمون نمره منفی ندارد.
            </li>
        </ul>
    </span>
</div><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\employee\counsellor\rules.blade.php ENDPATH**/ ?>