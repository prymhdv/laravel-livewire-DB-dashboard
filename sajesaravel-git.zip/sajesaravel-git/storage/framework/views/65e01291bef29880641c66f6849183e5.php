 
 <div class="row">
     <div class="div-12 text-center">
         <!--[if BLOCK]><![endif]--><?php if(Session::has('info')): ?>
             
             <div class="row  " id="hideMe">
                 <div class="col-md-12 col-sm-12 text-center font-peyda m-3" style="direction: rtl">

                     <p class="alert alert-info shadow1 p-2" role="alert"><?php echo e(Session::get('info')); ?></p>
                 </div>
             </div>
         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <!--[if BLOCK]><![endif]--><?php if(Session::has('danger')): ?>
             
             <div class="row " id="hideMe">
                 <div class="col-md-12 col-sm-12 text-center font-peyda m-3 " style="direction: rtl">
                     <p class="alert alert-danger shadow1 p-2" role="alert"><?php echo e(Session::get('danger')); ?></p>
                 </div>
             </div>
         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
             
             <div class="row " id="hideMe">
                 <div class="col-md-12 col-sm-12 text-center font-peyda m-3 " style="direction: rtl">
                     <p class="alert alert-success shadow1 p-2" role="alert"><?php echo e(Session::get('success')); ?></p>
                 </div>
             </div>
         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
     </div>
 </div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/pages/layouts/alerts.blade.php ENDPATH**/ ?>