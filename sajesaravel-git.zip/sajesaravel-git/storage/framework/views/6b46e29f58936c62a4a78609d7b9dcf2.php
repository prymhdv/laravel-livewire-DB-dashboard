<?php if(request()->route()->getName()=='main.users.adminPanelLivewireRoute' 
     || request()->route()->getName()=='edit.users.adminPanelLivewireRoute'
       || request()->route()->getName()=='login.users.adminPanelLivewireRoute'): ?>
    <div class="row">
        <div class="col-md-12">

            <div class="d-flex flex-wrap justify-content-center align-content-center p-2 pt-3 fs-3">
                <a href="<?php echo e(route('login.users.adminPanelLivewireRoute')); ?>" wire:navigate   class="hover4 d-block justify-items-center align-content-center  "
                style=" <?php if( request()->route()->getName()=='login.users.adminPanelLivewireRoute'): ?>  background-color:green; <?php endif; ?> ">
                    ورود به حساب کاربری
                </a>
                <a href="<?php echo e(route('edit.users.adminPanelLivewireRoute')); ?>" wire:navigate class="hover4 d-block justify-items-center align-content-center"
                    style=" <?php if( request()->route()->getName()=='edit.users.adminPanelLivewireRoute'): ?>  background-color:green; <?php endif; ?> ">
                    ویرایش حساب کاربری
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                >
                    XXXX-XXX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
                <a class="hover4 d-block justify-items-center align-content-center"
                    style=" ">
                    XXXX-XXX-XXX
                </a>
              
            </div>
            <hr class="m-0">
            <?php echo $__env->make('livewire.dashboard.admin.user.login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('livewire.dashboard.admin.user.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php endif; ?>

<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\dashboard\admin\user\main.blade.php ENDPATH**/ ?>