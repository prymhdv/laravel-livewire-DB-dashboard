<!--[if BLOCK]><![endif]--><?php $__errorArgs = [$e];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  
        <div class="col-12 alert alert-danger text-center p-0 m-0">
            <span class="text-danger p-0 " style="font-size: 12px;">
                <?php echo e($message); ?></span>
        </div>
    
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/livewire/error.blade.php ENDPATH**/ ?>