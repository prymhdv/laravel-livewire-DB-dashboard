<?php $__env->startSection('pageTitle', 'صفحه نخست'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('pages.home.adminInfoStatics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    
    
    
    <main class="container p-0">
        <div class="row justify-content-center mb-3 ">
            <?php echo $__env->make('pages.home.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('pages.home.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php echo $__env->make('pages.home.news', ['$Feeddata' => $Feeddata ?? false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            
            
            
            
            
            <?php echo $__env->make('blog.showContentBlogLoop', [
                'isAdmin' => false,
                //--------------'posts'=>\App\Models\Blog\BlogPost::whereNotNull('title')->where('active', '1')->orderBy('created_at', 'desc')->get()
                //--------------------------
                'posts' => \App\Models\Blog\BlogPost::whereNotNull('title')->where('active', '1')->inRandomOrder()->take(3)->get(),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            


        </div>

    </main>
    <style>
        .card2 {
            align-items: center;
            padding: 1rem;
            background-color: rgb(255, 255, 255);
            border: 2px solid #ddd;
            border-radius: 7px;
            box-shadow: 1px 3px 20px 5px rgba(151, 151, 151, 0.35);
            overflow: hidden;
            margin 0 auto;
            /* background: #ebedff; */
            /* aspect-ratio: 1/0.3; */
        }
    </style>
    
    <?php echo $__env->make('pages.home.newStyle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.html', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\pages\home\home.blade.php ENDPATH**/ ?>