<link rel="stylesheet" href="<?php echo e(asset('storage/PrymhdvAssets/persian-datepicker@1.2.0/dist/css/persian-datepicker.css')); ?>" />
<script src="<?php echo e(asset('storage/PrymhdvAssets/persian-date@1.1.0/dist/persian-date.js')); ?>"></script>
<script src="<?php echo e(asset('storage/PrymhdvAssets/persian-datepicker@1.2.0/dist/js/persian-datepicker.js')); ?>"></script>





<script language="javascript" src="<?php echo e(asset('storage/assets/js/FarsiType.js')); ?>" type="text/javascript"></script>
<meta name="google-site-verification" content="Rot8OEEJPPzbKkX6y1O_FlRvDrgvaBk_SU9t7MqGocw" />
<!-- JS here -->









<script src="<?php echo e(asset('storage/assets/plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('storage/assets/switcher/js/switcher-rtl.js')); ?>"></script>







<!--Body Include jQuery -->


<!--Body Include jQuery UI -->


<!-- Body Include Livewire Scripts -->

<script>
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    document.querySelectorAll('img:not([loading])').forEach(img => {
  img.loading = 'lazy';
});
</script><?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views/components/layouts/bodyScripts.blade.php ENDPATH**/ ?>