<div style="min-height: 1000px; margin-bottom:150px;" class="flex flex-grow-1  container py-4">
    <div class="container">
  
        <div class="row justify-content-center align-content-center">
            <div class="col-md-12">
                <?php echo $__env->make('pages.student.entekhabReshte.operator.registerStudentContent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
           <div class="row justify-content-center align-content-center">
            <div wire:loading
                class=" alert alert-danger px-5 m-0 w-75 text-center justify-content-center align-content-center">
                بارگذاری اطلاعات...
            </div>
        </div>
        <div class="row">

            <div class="col-md-12">
                <?php echo $__env->make('livewire.Pages.student.fieldSelection.tableStudent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\DeveloperSanjeshBonyad\Dev_SanjeshBonyad\sanjeshbonyadGit\sanjeshbonyad.org\sanjeshbonyad-laravel-git\resources\views\livewire\Pages\student\fieldSelection\page-student-field-selection-operator.blade.php ENDPATH**/ ?>