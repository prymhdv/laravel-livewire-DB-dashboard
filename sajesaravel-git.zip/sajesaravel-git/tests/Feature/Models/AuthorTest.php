<?php

declare(strict_types=1);

namespace Tests\Feature\Models;

use App\Models\Author;
use App\Models\Post;
use Illuminate\Foundation\Testing\LazilyRefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AuthorTest extends TestCase
{
    use LazilyRefreshDatabase;

    #[Test]
    public function author_can_be_soft_deleted(): void
    {
        // Create our author and post.
        $author = Author::factory()->create();

        $post = Post::factory()->for($author)->create();

        // Delete the author.
        $author->delete();

        // Assert the author and their associated post
        // is soft-deleted.
        $this->assertSoftDeleted($author);
        $this->assertSoftDeleted($post);
    }
}
